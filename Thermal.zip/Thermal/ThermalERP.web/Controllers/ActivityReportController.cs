﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
   
    public class ActivityReportController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();
        // GET: Demo
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetEmployees()
        {
           
                var employees = db.Activity_Report.OrderBy(a => a.Activity_Code).ToList();
                return Json(new { data = employees }, JsonRequestBehavior.AllowGet);
          
        }
        [HttpGet]
        public ActionResult Save(int id)
        {
            
                var v = db.Activity_Report.Where(a => a.id == id).FirstOrDefault();
                return View(v);
            
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var v = db.Activity_Report.Where(a => a.id == id).FirstOrDefault();
            return View(v);
        }

        public ActionResult Create()
        {
            return View("Partial_Create");
        }

        [HttpPost]
        public ActionResult Save(Activity_Report emp)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
              
                    if (emp.id > 0)
                    {
                        //Edit 
                        var v = db.Activity_Report.Where(a => a.id == emp.id).FirstOrDefault();
                        if (v != null)
                        {
                            v.Activity_Code = emp.Activity_Code;
                            v.Activity_Description = emp.Activity_Description;

                        }
                    }
                    else
                    {
                        //Save
                        db.Activity_Report.Add(emp);
                    }
                    db.SaveChanges();
                    status = true;
                
            }
            return RedirectToAction("Index" , "ActivityReport");
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {
           
                var v = db.Activity_Report.Where(a => a.id == id).FirstOrDefault();
                if (v != null)
                {
                    return View(v);
                }
                else
                {
                    return HttpNotFound();
                }
            
        }
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteEmployee(int id)
        {
            bool status = false;
           
                var v = db.Activity_Report.Where(a => a.id == id).FirstOrDefault();
                if (v != null)
                {
                    db.Activity_Report.Remove(v);
                    db.SaveChanges();
                    status = true;
                }
            
            return RedirectToAction("Index");
        }
    }
}