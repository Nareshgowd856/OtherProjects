﻿//using System;
//using System.Collections.Generic;
//using System.Data;
//using System.Data.Entity;
//using System.Linq;
//using System.Net;
//using System.Web;
//using System.Web.Mvc;
//using ThermalERP.web.Models;
//using System.Linq.Dynamic;

//namespace ThermalERP.web.Controllers
//{
//    public class MaterialGradesController : Controller
//    {
//        private Thermal_PMSEntities db = new Thermal_PMSEntities();

//       [HttpPost]
//        public ActionResult Index()
//        {
//            return View(db.Material_Grades.ToList());
//        }

//        [HttpGet]
//        public ActionResult Index(int page = 1, string sort = "Material_Group", string sortdir = "asc", string search = "")
//        {
//            int pagesize = 10;
//            int totalRecord = 0;
//            if (page < 1) page = 1;
//            int skip = (page * pagesize) - pagesize;
//            var data = GetList(search, sort, sortdir, skip, pagesize, out totalRecord);
//            ViewBag.TotalRows = totalRecord;
//            return View(data);
//        }
//        public List<Material_Grades> GetList(string Search, string sort, string sortdir, int skip, int pageSize, out int TotalRecord)
//        {
//            using (Thermal_PMSEntities db = new Thermal_PMSEntities())
//            {
//                var v = (from a in db.Material_Grades
//                         where
//                         a.Material_Group.Contains(Search) ||
//                         a.Material_Grad.Contains(Search) 

//                         select a
//                         );
//                TotalRecord = v.Count();
//                v = v.OrderBy(sort + " " + sortdir);
//                if (pageSize > 0)
//                {
//                    v = v.Skip(skip).Take(pageSize);
//                }
//                return v.ToList();
//            }
//        }

//        // GET: MaterialGrades/Details/5
//        public ActionResult Details(int? id)
//        {
//            if (id == null)
//            {
//                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
//            }
//            Material_Grades material_Grades = db.Material_Grades.Find(id);
//            if (material_Grades == null)
//            {
//                return HttpNotFound();
//            }
//            return View(material_Grades);
//        }

//        // GET: MaterialGrades/Create
//        public ActionResult Create()
//        {
//            ViewBag.Id = new SelectList(db.Material_Grades, "Id", "MaterialGroup");
//            return PartialView("Partial_Create");
//        }

//        // POST: MaterialGrades/Create
//        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
//        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
//        //[HttpPost]
//        //[ValidateAntiForgeryToken]
//        //public ActionResult Create([Bind(Include = "Material_Group,Material_Grad,Material_Color,Material_Density,CompID,Spec_Code,id")] Material_Grades material_Grades)
//        //{
//        //    if (ModelState.IsValid)
//        //    {
//        //        db.Material_Grades.Add(material_Grades);
//        //        db.SaveChanges();
//        //        return RedirectToAction("Index");
//        //    }
//        //    ViewBag.Id = new SelectList(db.Maker_Master, "Id", "MakerNo", material_Grades.Material_Group);
//        //    return View(material_Grades);
//        //}

//        // GET: MaterialGrades/Edit/5
//        public ActionResult Edit(int? id)
//        {
//            if (id == null)
//            {
//                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
//            }
//            Material_Grades material_Grades = db.Material_Grades.Find(id);
//            if (material_Grades == null)
//            {
//                return HttpNotFound();
//            }
//            return View(material_Grades);
//        }

//        //public ActionResult Editdata()
//        //{
//        //    List<Material_Grades> Material = Material_Grades.GetList();
//        //    return View(material_Grades);
//        //}

//        //public JsonResult Editable(Material model)
//        //{
//        //    // Update model to your db  
//        //    string message = "Success";
//        //    return Json(message, JsonRequestBehavior.AllowGet);
//        //}


//        // POST: MaterialGrades/Edit/5
//        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
//        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public ActionResult Edit([Bind(Include = "Material_Group,Material_Grad,Material_Color,Material_Density,CompID,Spec_Code,id")] Material_Grades material_Grades)
//        {
//            if (ModelState.IsValid)
//            {
//                db.Entry(material_Grades).State = System.Data.Entity.EntityState.Modified;
//                db.SaveChanges();
//                return RedirectToAction("Index");
//            }
//            return View(material_Grades);
//        }

//        // GET: MaterialGrades/Delete/5
//        public ActionResult Delete(int? id)
//        {
//            if (id == null)
//            {
//                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
//            }
//            Material_Grades material_Grades = db.Material_Grades.Find(id);
//            if (material_Grades == null)
//            {
//                return HttpNotFound();
//            }
//            return View(material_Grades);
//        }
//        public ActionResult Partial_Create()
//        {
//            return PartialView();
//        }
//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public ActionResult PartialCreate([Bind(Include = "Material_Group,Material_Grad,Material_Color,Material_Density,CompID,Spec_Code,id")] Material_Grades material_Grades)
//        {
//            if (ModelState.IsValid)
//            {
//                db.Material_Grades.Add(material_Grades);
//                db.SaveChanges();
//                return RedirectToAction("Index");
//            }
//            ViewBag.Id = new SelectList(db.Material_Grades, "Id", "Material_Group", material_Grades);
//            return PartialView(material_Grades);
//        }
//        // POST: MaterialGrades/Delete/5
//        [HttpPost, ActionName("Delete")]
//        [ValidateAntiForgeryToken]
//        public ActionResult DeleteConfirmed(int id)
//        {
//            Material_Grades material_Grades = db.Material_Grades.Find(id);
//            db.Material_Grades.Remove(material_Grades);
//            db.SaveChanges();
//            return RedirectToAction("Index");
//        }

//        protected override void Dispose(bool disposing)
//        {
//            if (disposing)
//            {
//                db.Dispose();
//            }
//            base.Dispose(disposing);
//        }
//    }
//}






using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{

    public class MaterialGradesController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();
        // GET: Demo
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetEmployees()
        {

            var employees = db.Material_Grades.OrderBy(a => a.id).ToList();
            return Json(new { data = employees }, JsonRequestBehavior.AllowGet);

        }
        [HttpGet]
        public ActionResult Save(int id)
        {

            var v = db.Material_Grades.Where(a => a.id == id).FirstOrDefault();
            return View(v);

        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var v = db.Material_Grades.Where(a => a.id == id).FirstOrDefault();
            return View(v);
        }

        public ActionResult Create()
        {
            return View("Partial_Create");
        }


        [HttpPost]
        public ActionResult Save(Material_Grades emp)
        {
            bool status = false;
            if (ModelState.IsValid)
            {

                if (emp.id > 0)
                {
                    //Edit 
                    var v = db.Material_Grades.Where(a => a.id == emp.id).FirstOrDefault();
                    if (v != null)
                    {
                        v.Material_Group = emp.Material_Group;
                        v.Material_Grad = emp.Material_Grad;
                        v.Spec_Code = emp.Spec_Code;
                    }
                }
                else
                {
                    //Save
                    db.Material_Grades.Add(emp);
                }
                db.SaveChanges();
                status = true;

            }
            return RedirectToAction("Index", "MaterialGrades");
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {

            var v = db.Material_Grades.Where(a => a.id == id).FirstOrDefault();
            if (v != null)
            {
                return View(v);
            }
            else
            {
                return HttpNotFound();
            }

        }
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteEmployee(int id)
        {
            bool status = false;

            var v = db.Material_Grades.Where(a => a.id == id).FirstOrDefault();
            if (v != null)
            {
                db.Material_Grades.Remove(v);
                db.SaveChanges();
                status = true;
            }

            return RedirectToAction("Index");
        }
    }
}