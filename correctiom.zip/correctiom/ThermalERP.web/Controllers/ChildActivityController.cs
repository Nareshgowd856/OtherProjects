﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
    public class ChildActivityController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();

        // GET: ChildActivity
        public ActionResult Index()
        {
            return View(db.Child_Activity.ToList());
        }

        // GET: ChildActivity/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Child_Activity child_Activity = db.Child_Activity.Find(id);
            if (child_Activity == null)
            {
                return HttpNotFound();
            }
            return View(child_Activity);
        }

        // GET: ChildActivity/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: ChildActivity/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,ActivityCode,Description,Execution_Duration_Date,Execution_Duration_Time,Applicable_No,CompID,Created_By,Created_On,Modified_On,Modified_By")] Child_Activity child_Activity)
        {
            if (ModelState.IsValid)
            {
                db.Child_Activity.Add(child_Activity);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(child_Activity);
        }

        // GET: ChildActivity/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Child_Activity child_Activity = db.Child_Activity.Find(id);
            if (child_Activity == null)
            {
                return HttpNotFound();
            }
            return View(child_Activity);
        }

        // POST: ChildActivity/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,ActivityCode,Description,Execution_Duration_Date,Execution_Duration_Time,Applicable_No,CompID,Created_By,Created_On,Modified_On,Modified_By")] Child_Activity child_Activity)
        {
            if (ModelState.IsValid)
            {
                db.Entry(child_Activity).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(child_Activity);
        }

        // GET: ChildActivity/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Child_Activity child_Activity = db.Child_Activity.Find(id);
            if (child_Activity == null)
            {
                return HttpNotFound();
            }
            return View(child_Activity);
        }

        // POST: ChildActivity/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Child_Activity child_Activity = db.Child_Activity.Find(id);
            db.Child_Activity.Remove(child_Activity);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
