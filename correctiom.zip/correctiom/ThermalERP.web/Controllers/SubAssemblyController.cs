﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;
using System.Web.UI;

namespace ThermalERP.web.Controllers
{
    public class SubAssemblyController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();
        const int pageSize = 10;
        // GET: SubAssembly
        public ActionResult Index(/*int page = 1, int sortBy = 1, bool isAsc = true*/)
        {
            //{
            //    IEnumerable<SubAssembly_Master> sub;

            //    #region Sorting
            //    switch (sortBy)
            //    {
            //        case 1:
            //            sub = isAsc ? db.SubAssembly_Master.OrderBy(p => p.Sub_Assembly_ID) : db.SubAssembly_Master.OrderByDescending(p => p.Sub_Assembly_ID);
            //            break;

            //        case 2:
            //            sub = isAsc ? db.SubAssembly_Master.OrderBy(p => p.Sub_Assembly_Name) : db.SubAssembly_Master.OrderByDescending(p => p.Sub_Assembly_ID);
            //            break;

            //        case 3:
            //            sub = isAsc ? db.SubAssembly_Master.OrderBy(p => p.CompID) : db.SubAssembly_Master.OrderByDescending(p => p.CompID);
            //            break;

            //        case 4:
            //            sub = isAsc ? db.SubAssembly_Master.OrderBy(p => p.Created_By) : db.SubAssembly_Master.OrderByDescending(p => p.Created_By);
            //            break;

            //        case 5:
            //            sub = isAsc ? db.SubAssembly_Master.OrderBy(p => p.Created_On) : db.SubAssembly_Master.OrderByDescending(p => p.Created_By);
                       
            //            break;

            //        case 6:

            //            sub = isAsc ? db.SubAssembly_Master.OrderBy(p => p.Modified_By) : db.SubAssembly_Master.OrderByDescending(p => p.Modified_By);
            //            break;

            //        case 7:
            //            sub = isAsc ? db.SubAssembly_Master.OrderBy(p => p.Modified_On) : db.SubAssembly_Master.OrderByDescending(p => p.Modified_On);
            //            break;

            //        default:
            //            sub = isAsc ? db.SubAssembly_Master.OrderBy(p => p.GroupName) : db.SubAssembly_Master.OrderByDescending(p => p.GroupName);
            //            break;
            //    }
            //    #endregion
                var Index = db.SubAssembly_Master
                .OrderBy(p => p.Sub_Assembly_ID)
                .Skip((pageSize - 1) * pageSize)
                .Take(pageSize)
                .ToList();

            ViewBag.CurrentPage = pageSize;
            ViewBag.PageSize = pageSize;
            ViewBag.TotalPages = Math.Ceiling((double)db.SubAssembly_Master.Count() / pageSize);

            return View(db.SubAssembly_Master.ToList());
        }

        // GET: SubAssembly/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SubAssembly_Master subAssembly_Master = db.SubAssembly_Master.Find(id);
            if (subAssembly_Master == null)
            {
                return HttpNotFound();
            }
            return View(subAssembly_Master);
        }

        // GET: SubAssembly/Create
        public ActionResult Create()
        {
            ViewBag.Id = new SelectList(db.SubAssembly_Master, "ID", "Sub_Assembly_ID");
            return PartialView("Partial_Create");
        }

        
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create([Bind(Include = "Sub_Assembly_ID,Sub_Assembly_Name,CompID,Created_By,Created_On,Modified_By,Modified_On,id,GroupName")] SubAssembly_Master subAssembly_Master)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.SubAssembly_Master.Add(subAssembly_Master);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    ViewBag.Id = new SelectList(db.SubAssembly_Master, "Id", "Sub_Assembly_ID", subAssembly_Master);
        //    return View(subAssembly_Master);
        //}

        // GET: SubAssembly/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SubAssembly_Master subAssembly_Master = db.SubAssembly_Master.Find(id);
            if (subAssembly_Master == null)
            {
                return HttpNotFound();
            }
            return View(subAssembly_Master);
        }

        // POST: SubAssembly/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Sub_Assembly_ID,Sub_Assembly_Name,CompID,Created_By,Created_On,Modified_By,Modified_On,id,GroupName")] SubAssembly_Master subAssembly_Master)
        {
            if (ModelState.IsValid)
            {
                db.Entry(subAssembly_Master).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(subAssembly_Master);
        }

        // GET: SubAssembly/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SubAssembly_Master subAssembly_Master = db.SubAssembly_Master.Find(id);
            if (subAssembly_Master == null)
            {
                return HttpNotFound();
            }
            return View(subAssembly_Master);
        }
        public ActionResult Partial_Create()
        {
            return PartialView();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Partial_Create([Bind(Include = "Sub_Assembly_ID,Sub_Assembly_Name,CompID,Created_By,Created_On,Modified_By,Modified_On,id,GroupName")] SubAssembly_Master subAssembly_Master)
        {
            if (ModelState.IsValid)
            {
                db.SubAssembly_Master.Add(subAssembly_Master);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id = new SelectList(db.SubAssembly_Master, "Id", "Sub_Assembly_ID", subAssembly_Master);
            return PartialView(subAssembly_Master);
        }


        // POST: SubAssembly/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            SubAssembly_Master subAssembly_Master = db.SubAssembly_Master.Find(id);
            db.SubAssembly_Master.Remove(subAssembly_Master);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
