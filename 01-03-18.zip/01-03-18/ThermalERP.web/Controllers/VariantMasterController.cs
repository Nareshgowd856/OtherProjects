﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
    public class VariantMasterController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();

        // GET: VariantMaster
        public ActionResult Index()
        {
            return View(db.Variant_Master.ToList());
        }

        // GET: VariantMaster/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Variant_Master variant_Master = db.Variant_Master.Find(id);
            if (variant_Master == null)
            {
                return HttpNotFound();
            }
            return View(variant_Master);
        }

        // GET: VariantMaster/Create
        public ActionResult Create()
        {
            ViewBag.Id = new SelectList(db.Variant_Master, "Id", "Variant_ID");
            return PartialView("Partial_Create");
        }

        // POST: VariantMaster/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create([Bind(Include = "Variant_ID,Variant_Name,Sub_Assembly_Name,CompID,Created_By,Created_On,Modified_By,Modifed_On,id")] Variant_Master variant_Master)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Variant_Master.Add(variant_Master);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    ViewBag.Id = new SelectList(db.Variant_Master, "Id", "Variant_ID", variant_Master.Variant_ID);
        //    return View(variant_Master);
        //}

        // GET: VariantMaster/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Variant_Master variant_Master = db.Variant_Master.Find(id);
            if (variant_Master == null)
            {
                return HttpNotFound();
            }
            
            return View(variant_Master);
        }

        // POST: VariantMaster/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Variant_ID,Variant_Name,Sub_Assembly_Name,CompID,Created_By,Created_On,Modified_By,Modifed_On,id")] Variant_Master variant_Master)
        {
            if (ModelState.IsValid)
            {
                db.Entry(variant_Master).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(variant_Master);
        }

        // GET: VariantMaster/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Variant_Master variant_Master = db.Variant_Master.Find(id);
            if (variant_Master == null)
            {
                return HttpNotFound();
            }
            return View(variant_Master);
        }
        public ActionResult Partial_Create()
        {
           return PartialView();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Partial_Create([Bind(Include = "Variant_ID,Variant_Name,Sub_Assembly_Name,CompID,Created_By,Created_On,Modified_By,Modifed_On,id")] Variant_Master variant_Master)
        {
            if (ModelState.IsValid)
            {
                db.Variant_Master.Add(variant_Master);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id = new SelectList(db.Variant_Master, "Id", "Variant_ID", variant_Master.Variant_ID);
            return PartialView(variant_Master);
        }

        // POST: VariantMaster/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Variant_Master variant_Master = db.Variant_Master.Find(id);
            db.Variant_Master.Remove(variant_Master);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
