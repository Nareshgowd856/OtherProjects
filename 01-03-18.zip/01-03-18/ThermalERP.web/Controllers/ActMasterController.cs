﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
    public class ActMasterController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();

        // GET: ActMaster
        public ActionResult Index()
        {
            return View(db.Activity_Master.ToList());
        }

        public ActionResult Add()
        {
            return View(db.Child_Activity.ToList());
        }


        // GET: ActMaster/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Activity_Master activity_Master = db.Activity_Master.Find(id);
            if (activity_Master == null)
            {
                return HttpNotFound();
            }
            return View(activity_Master);
        }

        // GET: ActMaster/Create
        public ActionResult Create()
        {
            var MA_list = db.Activity_Master.Select(s => new SelectListItem() { Text = s.Activity_Description, Value = s.Activity_Code }).ToList();
            ViewBag.MasterActivityList = new SelectList(MA_list, "Value", "text");
            var data = db.Activity_Master.ToList();
            ViewBag.MasterActivity = data;
            return View();

        }

        // POST: ActMaster/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Activity_Code,Activity_Description,Activity_Group,Activity_Document,Activity_Type,Activity_Predessor,Activity_Exe_Time,CompID,Created_By,Created_On,Modified_By,Modified_on,id,Activity_Level,Time_Unit,Resp_Dept,Applicable_Equipments")] Activity_Master activity_Master)
        {
            if (ModelState.IsValid)
            {
                db.Activity_Master.Add(activity_Master);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(activity_Master);
        }
        public ActionResult Created()
        {
            //ViewBag.Id = new SelectList(db.Child_Activity, "Id", "ActivityCode");
            return View();
        }

        // POST: ChildActivity/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Created([Bind(Include = "Id,ActivityCode,Description,Execution_Duration_Date,Execution_Duration_Time,Applicable_No,CompID,Created_By,Created_On,Modified_On,Modified_By")] Child_Activity child_Activity)
        {
            if (ModelState.IsValid)
            {
                db.Child_Activity.Add(child_Activity);
                db.SaveChanges();
                return RedirectToAction("Add");
            }

            return View(child_Activity);
        }

       

        public ActionResult Edited(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Child_Activity child_Activity = db.Child_Activity.Find(id);
            if (child_Activity == null)
            {
                return HttpNotFound();
            }
            return View(child_Activity);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edited([Bind(Include = "Id,ActivityCode,Description,Execution_Duration_Date,Execution_Duration_Time,Applicable_No,CompID,Created_By,Created_On,Modified_On,Modified_By")] Child_Activity child_Activity)
        {
            if (ModelState.IsValid)
            {
                db.Entry(child_Activity).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(child_Activity);
        }

        // GET: ActMaster/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Activity_Master activity_Master = db.Activity_Master.Find(id);
            if (activity_Master == null)
            {
                return HttpNotFound();
            }
            return View(activity_Master);
        }

        // POST: ActMaster/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Activity_Code,Activity_Description,Activity_Group,Activity_Document,Activity_Type,Activity_Predessor,Activity_Exe_Time,CompID,Created_By,Created_On,Modified_By,Modified_on,id,Activity_Level,Time_Unit,Resp_Dept,Applicable_Equipments")] Activity_Master activity_Master)
        {
            if (ModelState.IsValid)
            {
                db.Entry(activity_Master).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(activity_Master);
        }

        // GET: ActMaster/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Activity_Master activity_Master = db.Activity_Master.Find(id);
            if (activity_Master == null)
            {
                return HttpNotFound();
            }
            return View(activity_Master);
        }

        // POST: ActMaster/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Activity_Master activity_Master = db.Activity_Master.Find(id);
            db.Activity_Master.Remove(activity_Master);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        //public ActionResult Partial_Add()
        //{
           
        //    return PartialView();
        //}
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Partial_Add([Bind(Include = "Id,ActivityCode,Description,Execution_Duration_Date,Execution_Duration_Time,Applicable_No,CompID,Created_By,Created_On,Modified_On,Modified_By")] Child_Activity child_Activity)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Child_Activity.Add(child_Activity);
        //        db.SaveChanges();
        //        return RedirectToAction("Add");
        //    }

        //    return View(child_Activity);
        //}

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
