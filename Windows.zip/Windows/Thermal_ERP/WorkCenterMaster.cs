﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Thermal_ERP
{
    public partial class WorkCenterMaster : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        public WorkCenterMaster()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void WorkCenterMaster_Load(object sender, EventArgs e)
        {
           
            BindGrid();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void BindGrid()
        {
            var sa = (from k in db.WorkCenters orderby k.Work_Center_id where k.CompID == "0001" select new { k.Work_Center_id, k.Work_Center }).ToList();
            if(sa.Count>0)
            {
                dataGridView1.DataSource = sa;
            }
            else
            {

            }
        }
        private void button3_Click(object sender, EventArgs e)
        {
            txtUOMid.Text = "";
            txtUOMName.Text = "";
            BindGrid();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if((from k in db.WorkCenters where k.CompID=="0001"&& k.Work_Center_id==txtUOMid.Text.Trim() select k).Count()>0)
                {
                    db.Sp_Delete_WorkCenter("0001", txtUOMid.Text.Trim());
                    WorkCenter w = new WorkCenter();
                    w.Work_Center = (txtUOMName.Text == "") ? "" : txtUOMName.Text;
                    w.Work_Center_id = txtUOMid.Text;
                    w.CompID = "0001";
                    w.Created_By = "";
                    w.Created_On = DateTime.Now;
                    w.modified_On = DateTime.Now;
                    w.Modified_By = "";
                    db.WorkCenters.InsertOnSubmit(w);
                    db.SubmitChanges();
                    MessageBox.Show("Recored Updated Successfully");
                    txtUOMid.Text = "";
                    txtUOMName.Text = "";
                    BindGrid();
                    return;
                }
                else
                {
                    WorkCenter w = new WorkCenter();
                    w.Work_Center = (txtUOMName.Text == "") ? "" : txtUOMName.Text;
                  //  w.Work_Center_id = txtUOMid.Text;
                    w.CompID = "0001";
                    w.Created_By = "";
                    w.Created_On = DateTime.Now;
                    w.modified_On = DateTime.Now;
                    w.Modified_By = "";
                    var sa=  db.Sp_autoincrement_WorkCenter("0001").FirstOrDefault();
                    w.Work_Center_id = sa.Work_Center_id;
                    db.WorkCenters.InsertOnSubmit(w);
                    db.SubmitChanges();
                    MessageBox.Show("Recored Saved Successfully");
                    txtUOMid.Text = "";
                    txtUOMName.Text = "";
                    BindGrid();
                    return;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if(e.RowIndex>=0)
                {
                    string id = (dataGridView1.Rows[e.RowIndex].Cells["Work_Center_id"].Value.ToString());
                    var sa = (from k in db.WorkCenters where k.CompID == "0001" && k.Work_Center_id == id select new { k.Work_Center, k.Work_Center_id }).ToList();
                    if(sa.Count>0)
                    {
                        txtUOMid.Text = sa[0].Work_Center_id;
                        txtUOMName.Text = sa[0].Work_Center;
                    }
                    else
                    {
                        MessageBox.Show("Please select valid Recored");
                        return;
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
