﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
namespace Thermal_ERP
{
    
    public partial class ProjectStructure : Form
    {
        DataTable dtr;
        public static DataTable dt;
        
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Thermal_ERP.Properties.Settings.Thermal_PMSConnectionString"].ConnectionString);
        public ProjectStructure()
        {
            InitializeComponent();
        }
        public void BindProjectNames()
        {
            var data = db.Project_Masters.Select(c => c.Project_Code).Distinct().ToArray();
            AutoCompleteStringCollection instcol = new AutoCompleteStringCollection();
            instcol.AddRange(data);
            txtProjectCode.AutoCompleteCustomSource = instcol;
        }


        private void ProjectStructure_Load(object sender, EventArgs e)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("select distinct(Maker_No+'-'+Maker_Description) as Maker_Name from Maker_Master", con))
                {
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        using (DataTable dt = new DataTable())
                        {
                            da.Fill(dt);
                            for(int i=0;i<dt.Rows.Count;i++)
                            {
                                checkedListBox1.Items.Add(dt.Rows[i]["Maker_Name"].ToString());
                            }
                        }
                    }
                }
                using (SqlCommand cmd = new SqlCommand("select APG_No+' ('+APG_Description+')' as ApgName from APG_Master", con))
                {
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        using (DataTable dt = new DataTable())
                        {
                            da.Fill(dt);
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                checkedListBox2.Items.Add(dt.Rows[i]["ApgName"].ToString());
                            }
                        }
                    }
                }
                using (SqlCommand cmd = new SqlCommand("select (Activity_Code+' '+Activity_Description) as ActivityName from Activity_Master", con))
                {
                    cmd.CommandType = CommandType.Text;
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        using (DataTable dt = new DataTable())
                        {
                            da.Fill(dt);
                            for (int i = 0; i < dt.Rows.Count; i++)
                            {
                                checkedListBox3.Items.Add(dt.Rows[i]["ActivityName"].ToString());
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            // TODO: This line of code loads data into the 'thermal_PMSDataSet.Activity_Master' table. You can move, or remove it, as needed.
            this.activity_MasterTableAdapter.Fill(this.thermal_PMSDataSet.Activity_Master);
            // TODO: This line of code loads data into the 'thermal_PMSDataSet.APG_Master' table. You can move, or remove it, as needed.
            this.aPG_MasterTableAdapter.Fill(this.thermal_PMSDataSet.APG_Master);
            // TODO: This line of code loads data into the 'thermal_PMSDataSet.Maker_Master' table. You can move, or remove it, as needed.
            this.maker_MasterTableAdapter.Fill(this.thermal_PMSDataSet.Maker_Master);
            BindProjectNames();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            grbMakers.Visible = true;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            grbMakers.Visible = false;
        }
    
        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < dataGridView2.Rows.Count - 1; i = i + 1)
                {
                    if (dataGridView2.Rows[i].Cells["Column2"].Value != null)
                    {
                        if (dataGridView2.Rows[i].Cells["Column2"].Value.ToString().Equals("True"))
                        {
                            dataGridView1.Rows.Add();
                            dataGridView1.Rows[i].Cells[0].Value = dataGridView2.Rows[i].Cells[1].Value + "-" + dataGridView2.Rows[i].Cells[2].Value;
                            dataGridView1.Rows[i].Cells[0].Style.BackColor = Color.Azure;
                        }
                    }
                }
                grbMakers.Visible = false;
            }
            catch (Exception ex)
            {

                throw;
            }
            ////try
            ////{

            ////    int columnIndex = dataGridView2.CurrentCell.ColumnIndex;
            ////    string columnName = dataGridView2.Columns[columnIndex].HeaderText;
            ////    if (columnName == "Select")
            ////    {
            ////            dataGridView2.EndEdit();
            ////       DataTable  dtw = new DataTable();
            ////        dtw.Columns.Add("Column1", typeof(string));              
            ////        dtw.Columns.Add("Column3", typeof(string));
            ////        dtw.Columns.Add("Column4", typeof(string));
            ////        dtw.Columns.Add("Column5", typeof(string));
            ////        dtw.Columns.Add("Column6", typeof(string));
            ////        dtw.Columns.Add("Column7", typeof(string));
            ////       for(int g=0;g<dataGridView2.Rows.Count-1;g++)
            ////        {

            ////                bool isSelected = Convert.ToBoolean(dataGridView2.Rows[g].Cells["Column2"].Value);
            ////            if (isSelected)
            ////            {
            ////                string makerno = dataGridView2.Rows[g].Cells["Maker_No"].Value.ToString();
            ////                string makerdescrption = dataGridView2.Rows[g].Cells["Maker_Description"].Value.ToString();
            ////                string mak = makerno + "-" + makerdescrption;
            ////                dtw.Rows.Add(mak, null, null, null, null, null);
            ////            }
            ////        }
            ////        dataGridView1.DataSource = dtw;

            ////        db.Sp_Delete_tepmtabledata("0001", txtProjectCode.Text, "Admin");
            ////        for(int i=0;i<dataGridView1.Rows.Count-1;i++)
            ////        {
            ////            Temptable tb = new Temptable();
            ////            tb.CompID = "0001";
            ////            tb.Created_By = "Admin";
            ////            tb.Maker_No = dataGridView1.Rows[i].Cells["Column1"].Value.ToString();
            ////            tb.Project_Code = txtProjectCode.Text;
            ////            tb.no = i + 1;
            ////            db.Temptables.InsertOnSubmit(tb);
            ////        }
            ////        db.SubmitChanges();

            ////    }
            //////        for (int i = 0; i < dataGridView2.Rows.Count - 1; i = i + 1)
            //////{
            //////    if (dataGridView2.Rows[i].Cells["Column2"].Value != null)
            //////    {
            //////        if (dataGridView2.Rows[i].Cells["Column2"].Value.ToString().Equals("True"))
            //////        {
            //////            dataGridView1.Rows.Add();
            //////                string name = dataGridView2.Rows[i].Cells[1].Value.ToString() + "-" + dataGridView2.Rows[i].Cells[2].Value.ToString();
            //////            dataGridView1.Rows[i].Cells["Column1"].Value = name;
            //////            dataGridView1.Rows[i].Cells["Column1"].Style.BackColor = Color.Azure;
            //////        }
            //////    }
            //////}
            //////    grbMakers.Visible = false;
            ////}
            ////catch (Exception ex)
            ////{

            ////    throw;
            ////}


        }
        public int countno = 0;
        public int va;
        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < dataGridView3.Rows.Count - 1; i = i + 1)
                {
                    if (dataGridView3.Rows[i].Cells["ColSelect"].Value != null)
                    {
                        if (dataGridView3.Rows[i].Cells["ColSelect"].Value.ToString().Equals("True"))
                        {
                            DataGridViewRow dgwr = new DataGridViewRow();
                            dataGridView1.Rows.Insert(i + 1, dgwr);
                            dataGridView1.Rows[i + 1].Cells[0].Value = txtProjectCode.Text + dataGridView1.Rows[i].Cells[1].Value + "." + dataGridView3.Rows[i].Cells[1].Value;
                            dataGridView1.Rows[i + 1].Cells[0].Style.BackColor = Color.Coral;
                        }
                    }
                }
                groupBox1.Visible = false;
            }
            catch (Exception ex)
            {

                throw;
            }
            ////try
            ////{

            ////    for (int g = 0; g < dataGridView2.Rows.Count - 1; g++)
            ////    {
            ////        bool isSelected = Convert.ToBoolean(dataGridView2.Rows[g].Cells["Column2"].Value);
            ////        if (isSelected)
            ////        {
            ////            int nocount = 1;
            ////            countno += nocount;                       
            ////        }
            ////    }
            ////    dataGridView2.EndEdit();

            ////    //DataTable dtw = new DataTable();
            ////    //dtw.Columns.Add("Column1", typeof(string));
            ////    //dtw.Columns.Add("Column3", typeof(string));
            ////    //dtw.Columns.Add("Column4", typeof(string));
            ////    //dtw.Columns.Add("Column5", typeof(string));
            ////    //dtw.Columns.Add("Column6", typeof(string));
            ////    //dtw.Columns.Add("Column7", typeof(string));
            ////    //for(int j=0;j<dataGridView1.Rows.Count-1;j++)
            ////    //{
            ////    //    string Col = dataGridView2.Rows[j].Cells["Column1"].Value.ToString();
            ////    //    dtw.Rows.Add(Col, null, null, null, null, null);
            ////    //}

            ////    int grid1count = dataGridView1.Rows.Count -1;
            ////    for (va = 0; va < dataGridView3.Rows.Count - 1; va = va + 1)
            ////    {
            ////        if (dataGridView3.Rows[va].Cells["ColSelect"].Value != null)
            ////        {                      

            ////            if (dataGridView3.Rows[va].Cells["ColSelect"].Value.ToString().Equals("True"))
            ////            {
            ////                DataGridViewRow dgwr = new DataGridViewRow();
            ////                //     dataGridView1.Rows.Add(va + 1, dgwr);
            ////                int h = va + 1;
            ////                string colvalue = (dataGridView1.Rows[h].Cells["Column1"].Value == "" || dataGridView1.Rows[h].Cells["Column1"].Value == null) ? "" : dataGridView1.Rows[h].Cells["Column1"].Value.ToString();
            ////               if (""==colvalue)
            ////                {
            ////                    dataGridView1.Rows[h].Cells["Column1"].Value = txtProjectCode.Text + dataGridView1.Rows[va].Cells[1].Value + "." + dataGridView3.Rows[va].Cells[1].Value;
            ////                    dataGridView1.Rows[h].Cells["Column1"].Style.BackColor = Color.Coral;
            ////                }
            ////               else
            ////                {
            ////                    string mnb = txtProjectCode.Text + dataGridView1.Rows[va].Cells[1].Value + "." + dataGridView3.Rows[va].Cells[1].Value;
            ////                    dataGridView1.Rows[h].Cells["Column1"].Value = mnb;

            ////                    dataGridView1.Rows[h].Cells["Column1"].Style.BackColor = Color.Coral;                              

            ////                }

            ////            }
            ////        }

            ////    }
            ////    int uu = va;
            ////        var sa = (from k in db.Temptables where k.CompID == "0001" && k.Created_By == "Admin" && k.Project_Code == txtProjectCode.Text  select new { Column1= k.Maker_No }).ToList();
            ////        if(sa.Count>0)
            ////        {

            ////            dataGridView1.DataSource = sa;
            ////        }

            ////    groupBox1.Visible = false;
            ////}
            ////catch (Exception ex)
            ////{
            ////    throw;
            ////}

        }

        private void mapAPGToolStripMenuItem_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                for (int i = 0; i < dataGridView4.Rows.Count - 1; i = i + 1)
                {
                    if (dataGridView4.Rows[i].Cells["ColSelect1"].Value != null)
                    {
                        if (dataGridView4.Rows[i].Cells["ColSelect1"].Value.ToString().Equals("True"))
                        {
                            DataGridViewRow dgwr = new DataGridViewRow();
                            dataGridView1.Rows.Insert(i + 2, dgwr);
                            dataGridView1.Rows[i + 2].Cells[0].Value = dataGridView1.Rows[i + 1].Cells[0].Value + "." + (i + 1);

                            dataGridView1.Rows[i + 2].Cells[1].Value = dataGridView4.Rows[i].Cells[1].Value + "." + dataGridView4.Rows[i].Cells[2].Value;
                            dataGridView1.Rows[i + 2].Cells[2].Value = dataGridView4.Rows[i].Cells[3].Value;
                            dataGridView1.Rows[i + 2].Cells[0].Style.BackColor = Color.Gold;
                        }
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            ////try
            ////{
            ////    for (int i = 0; i < dataGridView4.Rows.Count - 1; i = i + 1)
            ////    {
            ////        if (dataGridView4.Rows[i].Cells["ColSelect1"].Value != null)
            ////        {
            ////            if (dataGridView4.Rows[i].Cells["ColSelect1"].Value.ToString().Equals("True"))
            ////            {
            ////                DataGridViewRow dgwr = new DataGridViewRow();
            ////           //     dataGridView1.Rows.Insert(i + 2, dgwr);
            ////                dataGridView1.Rows[i + 2].Cells[0].Value = dataGridView1.Rows[i + 1].Cells[0].Value + "." + (i + 1);

            ////                dataGridView1.Rows[i + 2].Cells[1].Value = dataGridView4.Rows[i].Cells[1].Value + "." + dataGridView4.Rows[i].Cells[2].Value;
            ////                dataGridView1.Rows[i + 2].Cells[2].Value = dataGridView4.Rows[i].Cells[3].Value;
            ////                dataGridView1.Rows[i + 2].Cells[0].Style.BackColor = Color.Gold;
            ////            }
            ////        }
            ////    }
            ////}
            ////catch (Exception ex)
            ////{

            ////    throw;
            ////}

        }

        private void mapActivityToolStripMenuItem_Click(object sender, EventArgs e)
        {
            groupBox2.Visible = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            groupBox2.Visible = false;
        }
        public static string na, ko;
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {     

                for (int i=0;i<dataGridView1.Rows.Count-1;i++)
                {
                    Project_Structure p = new Project_Structure();
                   // p.Project_Code = txtProjectCode.Text;
                    string name = (dataGridView1.Rows[i].Cells["Column1"].Value.ToString());
                    Char delimiter = '-';
                    String[] substrings = name.Split(delimiter);
                    int gg = substrings.Length;
                    int code = Convert.ToInt32(txtProjectCode.Text.Length.ToString());
                    int len = name.Length;
                    if (gg>1)
                    {
                        for (int R = 0; R < substrings.Length - 1; R++)
                        {
                           
                            string kq = substrings[R].ToString();
                            string oo = substrings[R + 1].ToString();
                            p.Project_Code = kq;
                            p.Name = oo;
                            p.Type = "Maker";
                            p.Parent = txtProjectCode.Text;
                            p.Main = txtProjectCode.Text;
                            na = substrings[R].ToString();
                        }
                    }
                   
                    
                    else if (code<len&& (dataGridView1.Rows[i].Cells["Column3"].Value==""|| dataGridView1.Rows[i].Cells["Column3"].Value==null))
                    {
                        string name1 = (dataGridView1.Rows[i].Cells["Column1"].Value.ToString());
                        Char delimiter1 = '.';
                        String[] substrings1 = name.Split(delimiter1);
                        for (int R = 0; R < substrings1.Length - 2; R++)
                        {
                            string kq = substrings1[R].ToString();
                            string oo = substrings1[R + 1].ToString();
                            string oow = substrings1[R + 2].ToString();
                            p.Project_Code = oo+"."+oow;
                            p.Name = oow;
                            p.Type = "APG";
                            p.Parent = na;
                            p.Main = txtProjectCode.Text;
                        }
                    }
                    else if (code < len && (dataGridView1.Rows[i].Cells["Column3"].Value != "" || dataGridView1.Rows[i].Cells["Column3"].Value != null))
                    {
                        string name1 = (dataGridView1.Rows[i].Cells["Column1"].Value.ToString());
                        Char delimiter1 = '.';
                        String[] substrings1 = name.Split(delimiter1);
                        for (int R = 0; R < substrings1.Length - 3; R++)
                        {
                            string kq = substrings1[R].ToString();

                            string oo = substrings1[R + 1].ToString();
                            string oon = substrings1[R + 2].ToString();
                            string oonQ = substrings1[R + 3].ToString();
                            p.Project_Code = oo+"."+oon+"."+oonQ;
                            p.Name = oon;
                            p.Type = "Activity";
                            p.Parent = oo+"."+oon;
                            p.Main = txtProjectCode.Text;
                        }
                    }
                    p.CompID = "0001";
                    db.Project_Structures.InsertOnSubmit(p);
                   
                }
                db.SubmitChanges();
                MessageBox.Show("Recored Saved Successfully");
                return;


            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
