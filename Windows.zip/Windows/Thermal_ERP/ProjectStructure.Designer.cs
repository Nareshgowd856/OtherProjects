﻿namespace Thermal_ERP
{
    partial class ProjectStructure
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtProjectCode = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.mapAPGToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mapActivityToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.button1 = new System.Windows.Forms.Button();
            this.grbMakers = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Column2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.Maker_No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Maker_Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.makerMasterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.thermal_PMSDataSet = new Thermal_ERP.Thermal_PMSDataSet();
            this.maker_MasterTableAdapter = new Thermal_ERP.Thermal_PMSDataSetTableAdapters.Maker_MasterTableAdapter();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.ColSelect = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.aPGNoDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aPGDescriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aPGMasterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.aPG_MasterTableAdapter = new Thermal_ERP.Thermal_PMSDataSetTableAdapters.APG_MasterTableAdapter();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.ColSelect1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.activityCodeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activityDescriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Activity_Document = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.activityMasterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.activity_MasterTableAdapter = new Thermal_ERP.Thermal_PMSDataSetTableAdapters.Activity_MasterTableAdapter();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.dataGridView5 = new System.Windows.Forms.DataGridView();
            this.Maker_No1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.checkedListBox2 = new System.Windows.Forms.CheckedListBox();
            this.checkedListBox3 = new System.Windows.Forms.CheckedListBox();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.grbMakers.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.makerMasterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thermal_PMSDataSet)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.aPGMasterBindingSource)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.activityMasterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).BeginInit();
            this.SuspendLayout();
            // 
            // txtProjectCode
            // 
            this.txtProjectCode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.txtProjectCode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource;
            this.txtProjectCode.Location = new System.Drawing.Point(92, 25);
            this.txtProjectCode.Name = "txtProjectCode";
            this.txtProjectCode.Size = new System.Drawing.Size(100, 20);
            this.txtProjectCode.TabIndex = 13;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 25);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "Project Code";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column3,
            this.Column4,
            this.Column5,
            this.Column6,
            this.Column7});
            this.dataGridView1.ContextMenuStrip = this.contextMenuStrip1;
            this.dataGridView1.Location = new System.Drawing.Point(17, 63);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(895, 370);
            this.dataGridView1.TabIndex = 14;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "Column1";
            this.Column1.HeaderText = "Project Structure";
            this.Column1.Name = "Column1";
            this.Column1.Width = 200;
            // 
            // Column3
            // 
            this.Column3.HeaderText = "Activity";
            this.Column3.Name = "Column3";
            this.Column3.Width = 200;
            // 
            // Column4
            // 
            this.Column4.HeaderText = "Document";
            this.Column4.Name = "Column4";
            // 
            // Column5
            // 
            this.Column5.HeaderText = "Start Time";
            this.Column5.Name = "Column5";
            // 
            // Column6
            // 
            this.Column6.HeaderText = "End Time";
            this.Column6.Name = "Column6";
            // 
            // Column7
            // 
            this.Column7.HeaderText = "Status";
            this.Column7.Name = "Column7";
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mapAPGToolStripMenuItem,
            this.mapActivityToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(142, 48);
            // 
            // mapAPGToolStripMenuItem
            // 
            this.mapAPGToolStripMenuItem.Name = "mapAPGToolStripMenuItem";
            this.mapAPGToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.mapAPGToolStripMenuItem.Text = "Map APG";
            this.mapAPGToolStripMenuItem.Click += new System.EventHandler(this.mapAPGToolStripMenuItem_Click);
            // 
            // mapActivityToolStripMenuItem
            // 
            this.mapActivityToolStripMenuItem.Name = "mapActivityToolStripMenuItem";
            this.mapActivityToolStripMenuItem.Size = new System.Drawing.Size(141, 22);
            this.mapActivityToolStripMenuItem.Text = "Map Activity";
            this.mapActivityToolStripMenuItem.Click += new System.EventHandler(this.mapActivityToolStripMenuItem_Click);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.button1.ForeColor = System.Drawing.Color.Red;
            this.button1.Location = new System.Drawing.Point(17, 439);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(90, 25);
            this.button1.TabIndex = 15;
            this.button1.Text = "Add Makers";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // grbMakers
            // 
            this.grbMakers.Controls.Add(this.button3);
            this.grbMakers.Controls.Add(this.button2);
            this.grbMakers.Controls.Add(this.dataGridView2);
            this.grbMakers.Location = new System.Drawing.Point(374, 35);
            this.grbMakers.Name = "grbMakers";
            this.grbMakers.Size = new System.Drawing.Size(360, 377);
            this.grbMakers.TabIndex = 17;
            this.grbMakers.TabStop = false;
            this.grbMakers.Text = "Makers";
            this.grbMakers.Visible = false;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(243, 348);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(80, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "Cancel";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(157, 348);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(80, 23);
            this.button2.TabIndex = 1;
            this.button2.Text = "Select";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column2,
            this.Maker_No,
            this.Maker_Description});
            this.dataGridView2.DataSource = this.makerMasterBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(20, 26);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(334, 301);
            this.dataGridView2.TabIndex = 0;
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Select";
            this.Column2.Name = "Column2";
            this.Column2.Width = 50;
            // 
            // Maker_No
            // 
            this.Maker_No.DataPropertyName = "Maker_No";
            this.Maker_No.HeaderText = "Maker_No";
            this.Maker_No.Name = "Maker_No";
            // 
            // Maker_Description
            // 
            this.Maker_Description.DataPropertyName = "Maker_Description";
            this.Maker_Description.HeaderText = "Maker_Description";
            this.Maker_Description.Name = "Maker_Description";
            this.Maker_Description.Width = 200;
            // 
            // makerMasterBindingSource
            // 
            this.makerMasterBindingSource.DataMember = "Maker_Master";
            this.makerMasterBindingSource.DataSource = this.thermal_PMSDataSet;
            // 
            // thermal_PMSDataSet
            // 
            this.thermal_PMSDataSet.DataSetName = "Thermal_PMSDataSet";
            this.thermal_PMSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // maker_MasterTableAdapter
            // 
            this.maker_MasterTableAdapter.ClearBeforeFill = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button4);
            this.groupBox1.Controls.Add(this.button5);
            this.groupBox1.Controls.Add(this.dataGridView3);
            this.groupBox1.Location = new System.Drawing.Point(415, 35);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(360, 377);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "APG";
            this.groupBox1.Visible = false;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(243, 348);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(80, 23);
            this.button4.TabIndex = 2;
            this.button4.Text = "Cancel";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(157, 348);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(80, 23);
            this.button5.TabIndex = 1;
            this.button5.Text = "Select";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColSelect,
            this.aPGNoDataGridViewTextBoxColumn,
            this.aPGDescriptionDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.aPGMasterBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(20, 26);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(334, 301);
            this.dataGridView3.TabIndex = 0;
            // 
            // ColSelect
            // 
            this.ColSelect.HeaderText = "Select";
            this.ColSelect.Name = "ColSelect";
            this.ColSelect.Width = 50;
            // 
            // aPGNoDataGridViewTextBoxColumn
            // 
            this.aPGNoDataGridViewTextBoxColumn.DataPropertyName = "APG_No";
            this.aPGNoDataGridViewTextBoxColumn.HeaderText = "APG_No";
            this.aPGNoDataGridViewTextBoxColumn.Name = "aPGNoDataGridViewTextBoxColumn";
            this.aPGNoDataGridViewTextBoxColumn.Width = 50;
            // 
            // aPGDescriptionDataGridViewTextBoxColumn
            // 
            this.aPGDescriptionDataGridViewTextBoxColumn.DataPropertyName = "APG_Description";
            this.aPGDescriptionDataGridViewTextBoxColumn.HeaderText = "APG_Description";
            this.aPGDescriptionDataGridViewTextBoxColumn.Name = "aPGDescriptionDataGridViewTextBoxColumn";
            this.aPGDescriptionDataGridViewTextBoxColumn.Width = 200;
            // 
            // aPGMasterBindingSource
            // 
            this.aPGMasterBindingSource.DataMember = "APG_Master";
            this.aPGMasterBindingSource.DataSource = this.thermal_PMSDataSet;
            // 
            // aPG_MasterTableAdapter
            // 
            this.aPG_MasterTableAdapter.ClearBeforeFill = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button6);
            this.groupBox2.Controls.Add(this.button7);
            this.groupBox2.Controls.Add(this.dataGridView4);
            this.groupBox2.Location = new System.Drawing.Point(466, 35);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(360, 377);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "APG";
            this.groupBox2.Visible = false;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(243, 348);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(80, 23);
            this.button6.TabIndex = 2;
            this.button6.Text = "Cancel";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(157, 348);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(80, 23);
            this.button7.TabIndex = 1;
            this.button7.Text = "Select";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ColSelect1,
            this.activityCodeDataGridViewTextBoxColumn,
            this.activityDescriptionDataGridViewTextBoxColumn,
            this.Activity_Document});
            this.dataGridView4.DataSource = this.activityMasterBindingSource;
            this.dataGridView4.Location = new System.Drawing.Point(20, 26);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.Size = new System.Drawing.Size(334, 301);
            this.dataGridView4.TabIndex = 0;
            // 
            // ColSelect1
            // 
            this.ColSelect1.HeaderText = "Select";
            this.ColSelect1.Name = "ColSelect1";
            this.ColSelect1.Width = 50;
            // 
            // activityCodeDataGridViewTextBoxColumn
            // 
            this.activityCodeDataGridViewTextBoxColumn.DataPropertyName = "Activity_Code";
            this.activityCodeDataGridViewTextBoxColumn.HeaderText = "Activity_Code";
            this.activityCodeDataGridViewTextBoxColumn.Name = "activityCodeDataGridViewTextBoxColumn";
            // 
            // activityDescriptionDataGridViewTextBoxColumn
            // 
            this.activityDescriptionDataGridViewTextBoxColumn.DataPropertyName = "Activity_Description";
            this.activityDescriptionDataGridViewTextBoxColumn.HeaderText = "Activity_Description";
            this.activityDescriptionDataGridViewTextBoxColumn.Name = "activityDescriptionDataGridViewTextBoxColumn";
            // 
            // Activity_Document
            // 
            this.Activity_Document.DataPropertyName = "Activity_Document";
            this.Activity_Document.HeaderText = "Activity_Document";
            this.Activity_Document.Name = "Activity_Document";
            // 
            // activityMasterBindingSource
            // 
            this.activityMasterBindingSource.DataMember = "Activity_Master";
            this.activityMasterBindingSource.DataSource = this.thermal_PMSDataSet;
            // 
            // activity_MasterTableAdapter
            // 
            this.activity_MasterTableAdapter.ClearBeforeFill = true;
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.Color.White;
            this.btnSubmit.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.ForeColor = System.Drawing.Color.Red;
            this.btnSubmit.Location = new System.Drawing.Point(113, 439);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(65, 25);
            this.btnSubmit.TabIndex = 20;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.Red;
            this.btnClose.Location = new System.Drawing.Point(184, 439);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(65, 25);
            this.btnClose.TabIndex = 21;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dataGridView5
            // 
            this.dataGridView5.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView5.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Maker_No1});
            this.dataGridView5.Location = new System.Drawing.Point(252, 357);
            this.dataGridView5.Name = "dataGridView5";
            this.dataGridView5.Size = new System.Drawing.Size(237, 107);
            this.dataGridView5.TabIndex = 22;
            this.dataGridView5.Visible = false;
            // 
            // Maker_No1
            // 
            this.Maker_No1.DataPropertyName = "Maker_No";
            this.Maker_No1.HeaderText = "Column8";
            this.Maker_No1.Name = "Maker_No1";
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Location = new System.Drawing.Point(700, 12);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(120, 94);
            this.checkedListBox1.TabIndex = 23;
            this.checkedListBox1.Visible = false;
            // 
            // checkedListBox2
            // 
            this.checkedListBox2.FormattingEnabled = true;
            this.checkedListBox2.Location = new System.Drawing.Point(781, 206);
            this.checkedListBox2.Name = "checkedListBox2";
            this.checkedListBox2.Size = new System.Drawing.Size(120, 94);
            this.checkedListBox2.TabIndex = 24;
            this.checkedListBox2.Visible = false;
            // 
            // checkedListBox3
            // 
            this.checkedListBox3.FormattingEnabled = true;
            this.checkedListBox3.Location = new System.Drawing.Point(792, 306);
            this.checkedListBox3.Name = "checkedListBox3";
            this.checkedListBox3.Size = new System.Drawing.Size(120, 94);
            this.checkedListBox3.TabIndex = 25;
            this.checkedListBox3.Visible = false;
            // 
            // ProjectStructure
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(924, 471);
            this.Controls.Add(this.checkedListBox3);
            this.Controls.Add(this.checkedListBox2);
            this.Controls.Add(this.checkedListBox1);
            this.Controls.Add(this.dataGridView5);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.grbMakers);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.txtProjectCode);
            this.Controls.Add(this.label6);
            this.Name = "ProjectStructure";
            this.Text = "ProjectStructure";
            this.Load += new System.EventHandler(this.ProjectStructure_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.grbMakers.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.makerMasterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thermal_PMSDataSet)).EndInit();
            this.groupBox1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.aPGMasterBindingSource)).EndInit();
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.activityMasterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtProjectCode;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mapAPGToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mapActivityToolStripMenuItem;
        private System.Windows.Forms.GroupBox grbMakers;
        private System.Windows.Forms.DataGridView dataGridView2;
        private Thermal_PMSDataSet thermal_PMSDataSet;
        private System.Windows.Forms.BindingSource makerMasterBindingSource;
        private Thermal_PMSDataSetTableAdapters.Maker_MasterTableAdapter maker_MasterTableAdapter;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.BindingSource aPGMasterBindingSource;
        private Thermal_PMSDataSetTableAdapters.APG_MasterTableAdapter aPG_MasterTableAdapter;
        private System.Windows.Forms.DataGridViewCheckBoxColumn ColSelect;
        private System.Windows.Forms.DataGridViewTextBoxColumn aPGNoDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn aPGDescriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.BindingSource activityMasterBindingSource;
        private Thermal_PMSDataSetTableAdapters.Activity_MasterTableAdapter activity_MasterTableAdapter;
        private System.Windows.Forms.DataGridViewCheckBoxColumn ColSelect1;
        private System.Windows.Forms.DataGridViewTextBoxColumn activityCodeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn activityDescriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Activity_Document;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Maker_No;
        private System.Windows.Forms.DataGridViewTextBoxColumn Maker_Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column3;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column6;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridView dataGridView5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Maker_No1;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.CheckedListBox checkedListBox2;
        private System.Windows.Forms.CheckedListBox checkedListBox3;
    }
}