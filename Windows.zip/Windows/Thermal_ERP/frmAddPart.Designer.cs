﻿namespace Thermal_ERP
{
    partial class frmAddPart
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtRevStatus = new System.Windows.Forms.TextBox();
            this.txtApgname = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtapgno = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtplno = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtmarkerno = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.txtprojectcode = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.dpdate = new System.Windows.Forms.DateTimePicker();
            this.txtverno = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.chkIbr = new System.Windows.Forms.CheckBox();
            this.chkEn = new System.Windows.Forms.CheckBox();
            this.chkMtc = new System.Windows.Forms.CheckBox();
            this.label51 = new System.Windows.Forms.Label();
            this.txtDwt = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.label16 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label39 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label38 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.label9 = new System.Windows.Forms.Label();
            this.txtDia = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtW2 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtThickness = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtlength = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.txtod = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.txtrmwt = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel4 = new System.Windows.Forms.TableLayoutPanel();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.txtfgwt = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbRmtype = new System.Windows.Forms.ComboBox();
            this.label34 = new System.Windows.Forms.Label();
            this.cmbptsno = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.txtMMitem = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtdescription = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.cmbSpecification = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbThickNo = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.txtDensity = new System.Windows.Forms.TextBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Version_No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Version_Date = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.DocumentNo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Version_Change = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Creted_By = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Modified_By = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Reviewd_By = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.button2 = new System.Windows.Forms.Button();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.label26 = new System.Windows.Forms.Label();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label25 = new System.Windows.Forms.Label();
            this.txtEqpName = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.button8 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.materialGradesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.thermal_PMSDataSet = new Thermal_ERP.Thermal_PMSDataSet();
            this.material_GradesTableAdapter = new Thermal_ERP.Thermal_PMSDataSetTableAdapters.Material_GradesTableAdapter();
            this.materialGradesBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.cmbUom = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.cmbvariant = new System.Windows.Forms.ComboBox();
            this.txtdrawingno = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtmaindrawingno = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.cmbPartGroup = new System.Windows.Forms.ComboBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbPartname = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.txtpartno = new System.Windows.Forms.TextBox();
            this.groupBox1.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel4.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialGradesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.thermal_PMSDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialGradesBindingSource1)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(823, 8);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(175, 17);
            this.label10.TabIndex = 7;
            this.label10.Text = "ADD /MODIFY PART DATA";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtRevStatus);
            this.groupBox1.Controls.Add(this.txtApgname);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.txtapgno);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.txtplno);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.txtmarkerno);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.txtprojectcode);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Enabled = false;
            this.groupBox1.Location = new System.Drawing.Point(14, 29);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(985, 48);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // txtRevStatus
            // 
            this.txtRevStatus.Location = new System.Drawing.Point(872, 12);
            this.txtRevStatus.Name = "txtRevStatus";
            this.txtRevStatus.ReadOnly = true;
            this.txtRevStatus.Size = new System.Drawing.Size(100, 23);
            this.txtRevStatus.TabIndex = 10;
            // 
            // txtApgname
            // 
            this.txtApgname.Location = new System.Drawing.Point(558, 15);
            this.txtApgname.Name = "txtApgname";
            this.txtApgname.Size = new System.Drawing.Size(126, 23);
            this.txtApgname.TabIndex = 7;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(449, 15);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(103, 15);
            this.label27.TabIndex = 6;
            this.label27.Text = "Equipment  Name";
            // 
            // txtapgno
            // 
            this.txtapgno.Location = new System.Drawing.Point(368, 15);
            this.txtapgno.Name = "txtapgno";
            this.txtapgno.Size = new System.Drawing.Size(75, 23);
            this.txtapgno.TabIndex = 5;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(316, 18);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(49, 15);
            this.label28.TabIndex = 4;
            this.label28.Text = "APG No";
            // 
            // txtplno
            // 
            this.txtplno.Location = new System.Drawing.Point(761, 12);
            this.txtplno.Name = "txtplno";
            this.txtplno.Size = new System.Drawing.Size(81, 23);
            this.txtplno.TabIndex = 9;
            this.txtplno.TextChanged += new System.EventHandler(this.txtplno_TextChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(687, 15);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(68, 15);
            this.label19.TabIndex = 8;
            this.label19.Text = "Part List No";
            // 
            // txtmarkerno
            // 
            this.txtmarkerno.Location = new System.Drawing.Point(233, 15);
            this.txtmarkerno.Name = "txtmarkerno";
            this.txtmarkerno.Size = new System.Drawing.Size(77, 23);
            this.txtmarkerno.TabIndex = 3;
            this.txtmarkerno.TextChanged += new System.EventHandler(this.txtmarkerno_TextChanged);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(172, 18);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(59, 15);
            this.label18.TabIndex = 2;
            this.label18.Text = "Maker No";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // txtprojectcode
            // 
            this.txtprojectcode.Location = new System.Drawing.Point(80, 15);
            this.txtprojectcode.Name = "txtprojectcode";
            this.txtprojectcode.Size = new System.Drawing.Size(86, 23);
            this.txtprojectcode.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(3, 18);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(75, 15);
            this.label17.TabIndex = 0;
            this.label17.Text = "Project Code";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(619, 379);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(31, 15);
            this.label22.TabIndex = 9;
            this.label22.Text = "Date";
            // 
            // dpdate
            // 
            this.dpdate.Enabled = false;
            this.dpdate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dpdate.Location = new System.Drawing.Point(664, 376);
            this.dpdate.Name = "dpdate";
            this.dpdate.Size = new System.Drawing.Size(101, 23);
            this.dpdate.TabIndex = 8;
            // 
            // txtverno
            // 
            this.txtverno.Enabled = false;
            this.txtverno.Location = new System.Drawing.Point(528, 374);
            this.txtverno.Name = "txtverno";
            this.txtverno.ReadOnly = true;
            this.txtverno.Size = new System.Drawing.Size(67, 23);
            this.txtverno.TabIndex = 7;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(479, 377);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(43, 15);
            this.label21.TabIndex = 6;
            this.label21.Text = "Ver No";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(14, 198);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(979, 314);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.chkIbr);
            this.tabPage1.Controls.Add(this.chkEn);
            this.tabPage1.Controls.Add(this.chkMtc);
            this.tabPage1.Controls.Add(this.label51);
            this.tabPage1.Controls.Add(this.txtDwt);
            this.tabPage1.Controls.Add(this.pictureBox2);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.comboBox3);
            this.tabPage1.Controls.Add(this.label39);
            this.tabPage1.Controls.Add(this.pictureBox1);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.comboBox2);
            this.tabPage1.Controls.Add(this.label38);
            this.tabPage1.Controls.Add(this.tableLayoutPanel2);
            this.tabPage1.Controls.Add(this.tableLayoutPanel4);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Controls.Add(this.label22);
            this.tabPage1.Controls.Add(this.label33);
            this.tabPage1.Controls.Add(this.dpdate);
            this.tabPage1.Controls.Add(this.txtverno);
            this.tabPage1.Controls.Add(this.label21);
            this.tabPage1.Controls.Add(this.tableLayoutPanel1);
            this.tabPage1.Location = new System.Drawing.Point(4, 24);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(971, 286);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Tech Data";
            this.tabPage1.UseVisualStyleBackColor = true;
            this.tabPage1.Click += new System.EventHandler(this.tabPage1_Click);
            // 
            // chkIbr
            // 
            this.chkIbr.AutoSize = true;
            this.chkIbr.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkIbr.ForeColor = System.Drawing.Color.Red;
            this.chkIbr.Location = new System.Drawing.Point(742, 157);
            this.chkIbr.Name = "chkIbr";
            this.chkIbr.Size = new System.Drawing.Size(67, 19);
            this.chkIbr.TabIndex = 61;
            this.chkIbr.Text = "IBR Cert";
            this.chkIbr.UseVisualStyleBackColor = true;
            // 
            // chkEn
            // 
            this.chkEn.AutoSize = true;
            this.chkEn.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkEn.ForeColor = System.Drawing.Color.Red;
            this.chkEn.Location = new System.Drawing.Point(742, 177);
            this.chkEn.Name = "chkEn";
            this.chkEn.Size = new System.Drawing.Size(65, 19);
            this.chkEn.TabIndex = 63;
            this.chkEn.Text = "EN Cert";
            this.chkEn.UseVisualStyleBackColor = true;
            // 
            // chkMtc
            // 
            this.chkMtc.AutoSize = true;
            this.chkMtc.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkMtc.ForeColor = System.Drawing.Color.Red;
            this.chkMtc.Location = new System.Drawing.Point(742, 195);
            this.chkMtc.Name = "chkMtc";
            this.chkMtc.Size = new System.Drawing.Size(75, 19);
            this.chkMtc.TabIndex = 62;
            this.chkMtc.Text = "MTC Cert";
            this.chkMtc.UseVisualStyleBackColor = true;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(696, 241);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(35, 15);
            this.label51.TabIndex = 60;
            this.label51.Text = "D Wt";
            // 
            // txtDwt
            // 
            this.txtDwt.Location = new System.Drawing.Point(749, 238);
            this.txtDwt.Name = "txtDwt";
            this.txtDwt.Size = new System.Drawing.Size(51, 23);
            this.txtDwt.TabIndex = 59;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Location = new System.Drawing.Point(129, 197);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(111, 67);
            this.pictureBox2.TabIndex = 58;
            this.pictureBox2.TabStop = false;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(12, 217);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(98, 17);
            this.label16.TabIndex = 57;
            this.label16.Text = "Material Shape";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Nos",
            "Kgs",
            "MT",
            "Mtrs",
            "Packs"});
            this.comboBox3.Location = new System.Drawing.Point(11, 239);
            this.comboBox3.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(100, 23);
            this.comboBox3.TabIndex = 56;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label39.Location = new System.Drawing.Point(10, 198);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(108, 15);
            this.label39.TabIndex = 55;
            this.label39.Text = "Size - Raw Material";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Location = new System.Drawing.Point(129, 126);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(111, 65);
            this.pictureBox1.TabIndex = 53;
            this.pictureBox1.TabStop = false;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(8, 137);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(98, 17);
            this.label14.TabIndex = 52;
            this.label14.Text = "Material Shape";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Nos",
            "Kgs",
            "MT",
            "Mtrs",
            "Packs"});
            this.comboBox2.Location = new System.Drawing.Point(12, 157);
            this.comboBox2.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(100, 23);
            this.comboBox2.TabIndex = 51;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.label38.Location = new System.Drawing.Point(10, 122);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(81, 15);
            this.label38.TabIndex = 50;
            this.label38.Text = "Size - Finshed";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel2.ColumnCount = 8;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 63F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 79F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 183F));
            this.tableLayoutPanel2.Controls.Add(this.label9, 2, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtDia, 3, 0);
            this.tableLayoutPanel2.Controls.Add(this.label11, 4, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtW2, 5, 0);
            this.tableLayoutPanel2.Controls.Add(this.label12, 2, 1);
            this.tableLayoutPanel2.Controls.Add(this.txtThickness, 3, 1);
            this.tableLayoutPanel2.Controls.Add(this.label13, 4, 1);
            this.tableLayoutPanel2.Controls.Add(this.txtlength, 5, 1);
            this.tableLayoutPanel2.Controls.Add(this.label36, 6, 0);
            this.tableLayoutPanel2.Controls.Add(this.txtod, 7, 0);
            this.tableLayoutPanel2.Controls.Add(this.label15, 6, 1);
            this.tableLayoutPanel2.Controls.Add(this.txtrmwt, 7, 1);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(246, 198);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 2;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(444, 66);
            this.tableLayoutPanel2.TabIndex = 22;
            // 
            // label9
            // 
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(6, 1);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 35);
            this.label9.TabIndex = 0;
            this.label9.Text = "Dia / W1";
            // 
            // txtDia
            // 
            this.txtDia.Location = new System.Drawing.Point(93, 4);
            this.txtDia.Name = "txtDia";
            this.txtDia.Size = new System.Drawing.Size(51, 23);
            this.txtDia.TabIndex = 0;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(157, 1);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(26, 15);
            this.label11.TabIndex = 2;
            this.label11.Text = "W2";
            // 
            // txtW2
            // 
            this.txtW2.Location = new System.Drawing.Point(215, 4);
            this.txtW2.Name = "txtW2";
            this.txtW2.Size = new System.Drawing.Size(61, 23);
            this.txtW2.TabIndex = 1;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(6, 37);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(59, 15);
            this.label12.TabIndex = 4;
            this.label12.Text = "Thickness";
            // 
            // txtThickness
            // 
            this.txtThickness.Location = new System.Drawing.Point(93, 40);
            this.txtThickness.Name = "txtThickness";
            this.txtThickness.Size = new System.Drawing.Size(51, 23);
            this.txtThickness.TabIndex = 2;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(157, 37);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 15);
            this.label13.TabIndex = 6;
            this.label13.Text = "Length";
            // 
            // txtlength
            // 
            this.txtlength.Location = new System.Drawing.Point(215, 40);
            this.txtlength.Name = "txtlength";
            this.txtlength.Size = new System.Drawing.Size(67, 23);
            this.txtlength.TabIndex = 3;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.label36.Location = new System.Drawing.Point(295, 1);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(25, 15);
            this.label36.TabIndex = 14;
            this.label36.Text = "OD";
            // 
            // txtod
            // 
            this.txtod.Location = new System.Drawing.Point(366, 4);
            this.txtod.Name = "txtod";
            this.txtod.Size = new System.Drawing.Size(68, 23);
            this.txtod.TabIndex = 13;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(295, 37);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 15);
            this.label15.TabIndex = 10;
            this.label15.Text = "RM Wt";
            // 
            // txtrmwt
            // 
            this.txtrmwt.Location = new System.Drawing.Point(366, 40);
            this.txtrmwt.Name = "txtrmwt";
            this.txtrmwt.Size = new System.Drawing.Size(68, 23);
            this.txtrmwt.TabIndex = 5;
            // 
            // tableLayoutPanel4
            // 
            this.tableLayoutPanel4.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel4.ColumnCount = 8;
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 86F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 62F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 57F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 80F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 70F));
            this.tableLayoutPanel4.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 183F));
            this.tableLayoutPanel4.Controls.Add(this.label40, 2, 0);
            this.tableLayoutPanel4.Controls.Add(this.textBox3, 3, 0);
            this.tableLayoutPanel4.Controls.Add(this.label41, 4, 0);
            this.tableLayoutPanel4.Controls.Add(this.textBox4, 5, 0);
            this.tableLayoutPanel4.Controls.Add(this.label42, 2, 1);
            this.tableLayoutPanel4.Controls.Add(this.textBox5, 3, 1);
            this.tableLayoutPanel4.Controls.Add(this.label43, 4, 1);
            this.tableLayoutPanel4.Controls.Add(this.textBox6, 5, 1);
            this.tableLayoutPanel4.Controls.Add(this.label44, 6, 1);
            this.tableLayoutPanel4.Controls.Add(this.txtfgwt, 7, 1);
            this.tableLayoutPanel4.Controls.Add(this.label47, 6, 0);
            this.tableLayoutPanel4.Controls.Add(this.textBox10, 7, 0);
            this.tableLayoutPanel4.Location = new System.Drawing.Point(246, 126);
            this.tableLayoutPanel4.Name = "tableLayoutPanel4";
            this.tableLayoutPanel4.RowCount = 2;
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel4.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel4.Size = new System.Drawing.Size(444, 65);
            this.tableLayoutPanel4.TabIndex = 21;
            // 
            // label40
            // 
            this.label40.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.Location = new System.Drawing.Point(6, 1);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(79, 35);
            this.label40.TabIndex = 0;
            this.label40.Text = "Dia / W1";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(93, 4);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(51, 23);
            this.textBox3.TabIndex = 0;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.Location = new System.Drawing.Point(156, 1);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(26, 15);
            this.label41.TabIndex = 2;
            this.label41.Text = "W2";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(214, 4);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(61, 23);
            this.textBox4.TabIndex = 1;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.Location = new System.Drawing.Point(6, 37);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(59, 15);
            this.label42.TabIndex = 4;
            this.label42.Text = "Thickness";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(93, 40);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(51, 23);
            this.textBox5.TabIndex = 2;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(156, 37);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(44, 15);
            this.label43.TabIndex = 6;
            this.label43.Text = "Length";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(214, 40);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(67, 23);
            this.textBox6.TabIndex = 3;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(295, 37);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(40, 15);
            this.label44.TabIndex = 8;
            this.label44.Text = "FG Wt";
            // 
            // txtfgwt
            // 
            this.txtfgwt.Location = new System.Drawing.Point(366, 40);
            this.txtfgwt.Name = "txtfgwt";
            this.txtfgwt.Size = new System.Drawing.Size(68, 23);
            this.txtfgwt.TabIndex = 4;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.label47.Location = new System.Drawing.Point(295, 1);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(25, 15);
            this.label47.TabIndex = 14;
            this.label47.Text = "OD";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(366, 4);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(68, 23);
            this.textBox10.TabIndex = 13;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.textBox1.Location = new System.Drawing.Point(67, 373);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(391, 23);
            this.textBox1.TabIndex = 20;
            this.textBox1.Visible = false;
            this.textBox1.Leave += new System.EventHandler(this.textBox1_Leave);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.label33.Location = new System.Drawing.Point(9, 377);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(52, 15);
            this.label33.TabIndex = 19;
            this.label33.Text = "Remarks";
            this.label33.Visible = false;
            this.label33.Click += new System.EventHandler(this.label33_Click);
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset;
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.cmbRmtype, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.label34, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.cmbptsno, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBox2, 1, 6);
            this.tableLayoutPanel1.Controls.Add(this.label35, 0, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtMMitem, 5, 6);
            this.tableLayoutPanel1.Controls.Add(this.label24, 4, 6);
            this.tableLayoutPanel1.Controls.Add(this.label3, 2, 6);
            this.tableLayoutPanel1.Controls.Add(this.txtdescription, 3, 6);
            this.tableLayoutPanel1.Controls.Add(this.label5, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.cmbSpecification, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.label8, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.cmbThickNo, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.label23, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.txtDensity, 5, 1);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(7, 8);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 7;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(971, 112);
            this.tableLayoutPanel1.TabIndex = 7;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(5, 43);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 17);
            this.label7.TabIndex = 13;
            this.label7.Text = "RM Type";
            // 
            // cmbRmtype
            // 
            this.cmbRmtype.Enabled = false;
            this.cmbRmtype.FormattingEnabled = true;
            this.cmbRmtype.Items.AddRange(new object[] {
            "Nos",
            "Kgs",
            "MT",
            "Mtrs",
            "Packs"});
            this.cmbRmtype.Location = new System.Drawing.Point(96, 48);
            this.cmbRmtype.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.cmbRmtype.Name = "cmbRmtype";
            this.cmbRmtype.Size = new System.Drawing.Size(100, 23);
            this.cmbRmtype.TabIndex = 8;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.label34.Location = new System.Drawing.Point(386, 43);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(52, 17);
            this.label34.TabIndex = 46;
            this.label34.Text = "PTS No";
            // 
            // cmbptsno
            // 
            this.cmbptsno.FormattingEnabled = true;
            this.cmbptsno.Location = new System.Drawing.Point(480, 46);
            this.cmbptsno.Name = "cmbptsno";
            this.cmbptsno.Size = new System.Drawing.Size(174, 23);
            this.cmbptsno.TabIndex = 19;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(96, 83);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(282, 24);
            this.textBox2.TabIndex = 23;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.label35.Location = new System.Drawing.Point(5, 80);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(66, 17);
            this.label35.TabIndex = 22;
            this.label35.Text = "Spl Notes";
            // 
            // txtMMitem
            // 
            this.txtMMitem.Enabled = false;
            this.txtMMitem.Location = new System.Drawing.Point(873, 83);
            this.txtMMitem.Name = "txtMMitem";
            this.txtMMitem.Size = new System.Drawing.Size(117, 23);
            this.txtMMitem.TabIndex = 27;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(779, 80);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(86, 15);
            this.label24.TabIndex = 26;
            this.label24.Text = "MM Item Code";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(386, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(76, 17);
            this.label3.TabIndex = 12;
            this.label3.Text = "Description";
            // 
            // txtdescription
            // 
            this.txtdescription.Location = new System.Drawing.Point(480, 85);
            this.txtdescription.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.txtdescription.Multiline = true;
            this.txtdescription.Name = "txtdescription";
            this.txtdescription.Size = new System.Drawing.Size(291, 20);
            this.txtdescription.TabIndex = 13;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(5, 4);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(83, 17);
            this.label5.TabIndex = 6;
            this.label5.Text = "Specification";
            // 
            // cmbSpecification
            // 
            this.cmbSpecification.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbSpecification.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbSpecification.DisplayMember = "Material_Grade";
            this.cmbSpecification.FormattingEnabled = true;
            this.cmbSpecification.Location = new System.Drawing.Point(96, 9);
            this.cmbSpecification.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.cmbSpecification.Name = "cmbSpecification";
            this.cmbSpecification.Size = new System.Drawing.Size(174, 23);
            this.cmbSpecification.TabIndex = 16;
            this.cmbSpecification.ValueMember = "Material_Grade";
            this.cmbSpecification.Leave += new System.EventHandler(this.comboBox2_Leave);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(386, 4);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 15);
            this.label8.TabIndex = 17;
            this.label8.Text = "Thick / Sch No";
            // 
            // cmbThickNo
            // 
            this.cmbThickNo.FormattingEnabled = true;
            this.cmbThickNo.Location = new System.Drawing.Point(480, 7);
            this.cmbThickNo.Name = "cmbThickNo";
            this.cmbThickNo.Size = new System.Drawing.Size(83, 23);
            this.cmbThickNo.TabIndex = 18;
            this.cmbThickNo.Leave += new System.EventHandler(this.comboBox5_Leave);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(779, 4);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(47, 15);
            this.label23.TabIndex = 20;
            this.label23.Text = "Density";
            // 
            // txtDensity
            // 
            this.txtDensity.Enabled = false;
            this.txtDensity.Location = new System.Drawing.Point(873, 7);
            this.txtDensity.Name = "txtDensity";
            this.txtDensity.Size = new System.Drawing.Size(79, 23);
            this.txtDensity.TabIndex = 21;
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Location = new System.Drawing.Point(4, 24);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(971, 286);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Stock Availbility";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // groupBox5
            // 
            this.groupBox5.BackColor = System.Drawing.Color.Linen;
            this.groupBox5.Controls.Add(this.dataGridView3);
            this.groupBox5.Location = new System.Drawing.Point(-9, 8);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(974, 395);
            this.groupBox5.TabIndex = 14;
            this.groupBox5.TabStop = false;
            // 
            // dataGridView3
            // 
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.Column9});
            this.dataGridView3.Location = new System.Drawing.Point(15, 12);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.Size = new System.Drawing.Size(853, 260);
            this.dataGridView3.TabIndex = 0;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "Avaiable Size";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.HeaderText = "UOM";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.HeaderText = "Qty Available";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.HeaderText = "MTC Cert";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.HeaderText = "IBR Cert";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.HeaderText = "EN Cert";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // Column9
            // 
            this.Column9.HeaderText = "Reserve Stock";
            this.Column9.Name = "Column9";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Location = new System.Drawing.Point(4, 24);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(971, 286);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Version History";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.BackColor = System.Drawing.Color.Linen;
            this.groupBox3.Controls.Add(this.dataGridView1);
            this.groupBox3.Location = new System.Drawing.Point(3, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(962, 395);
            this.groupBox3.TabIndex = 12;
            this.groupBox3.TabStop = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Version_No,
            this.Version_Date,
            this.DocumentNo,
            this.Version_Change,
            this.Creted_By,
            this.Modified_By,
            this.Reviewd_By});
            this.dataGridView1.Location = new System.Drawing.Point(7, 22);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(853, 366);
            this.dataGridView1.TabIndex = 0;
            // 
            // Version_No
            // 
            this.Version_No.DataPropertyName = "Version_No";
            this.Version_No.HeaderText = "Ver No";
            this.Version_No.Name = "Version_No";
            // 
            // Version_Date
            // 
            this.Version_Date.DataPropertyName = "Version_Date";
            this.Version_Date.HeaderText = "Ver Date";
            this.Version_Date.Name = "Version_Date";
            // 
            // DocumentNo
            // 
            this.DocumentNo.DataPropertyName = "DocumentNo";
            this.DocumentNo.HeaderText = "DCN No";
            this.DocumentNo.Name = "DocumentNo";
            // 
            // Version_Change
            // 
            this.Version_Change.DataPropertyName = "Version_Change";
            this.Version_Change.HeaderText = "Changes Made";
            this.Version_Change.Name = "Version_Change";
            // 
            // Creted_By
            // 
            this.Creted_By.DataPropertyName = "Creted_By";
            this.Creted_By.HeaderText = "Created By";
            this.Creted_By.Name = "Creted_By";
            // 
            // Modified_By
            // 
            this.Modified_By.DataPropertyName = "Modified_By";
            this.Modified_By.HeaderText = "Reviewed By";
            this.Modified_By.Name = "Modified_By";
            // 
            // Reviewd_By
            // 
            this.Reviewd_By.DataPropertyName = "Reviewd_By";
            this.Reviewd_By.HeaderText = "Approved By";
            this.Reviewd_By.Name = "Reviewd_By";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(544, 78);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(72, 27);
            this.button2.TabIndex = 10;
            this.button2.Text = "New";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click_1);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Location = new System.Drawing.Point(269, 542);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(60, 15);
            this.linkLabel2.TabIndex = 18;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "linkLabel2";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(160, 542);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(95, 15);
            this.label26.TabIndex = 17;
            this.label26.Text = "Last Modified By";
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Location = new System.Drawing.Point(85, 542);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(60, 15);
            this.linkLabel1.TabIndex = 16;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "linkLabel1";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(15, 542);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(64, 15);
            this.label25.TabIndex = 15;
            this.label25.Text = "Created By";
            // 
            // txtEqpName
            // 
            this.txtEqpName.Location = new System.Drawing.Point(443, 8);
            this.txtEqpName.Name = "txtEqpName";
            this.txtEqpName.Size = new System.Drawing.Size(187, 23);
            this.txtEqpName.TabIndex = 13;
            this.txtEqpName.Visible = false;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(328, 11);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(100, 15);
            this.label31.TabIndex = 14;
            this.label31.Text = "Equipment Name";
            this.label31.Visible = false;
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.Desktop;
            this.button8.ForeColor = System.Drawing.Color.Cornsilk;
            this.button8.Location = new System.Drawing.Point(924, 536);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 28);
            this.button8.TabIndex = 17;
            this.button8.Text = "Close";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.Desktop;
            this.button7.ForeColor = System.Drawing.Color.Cornsilk;
            this.button7.Location = new System.Drawing.Point(841, 536);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 28);
            this.button7.TabIndex = 15;
            this.button7.Text = "Submit";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.Desktop;
            this.button6.ForeColor = System.Drawing.Color.Cornsilk;
            this.button6.Location = new System.Drawing.Point(760, 536);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 28);
            this.button6.TabIndex = 16;
            this.button6.Text = "Reset";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // materialGradesBindingSource
            // 
            this.materialGradesBindingSource.DataMember = "Material_Grades";
            this.materialGradesBindingSource.DataSource = this.thermal_PMSDataSet;
            // 
            // thermal_PMSDataSet
            // 
            this.thermal_PMSDataSet.DataSetName = "Thermal_PMSDataSet";
            this.thermal_PMSDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // material_GradesTableAdapter
            // 
            this.material_GradesTableAdapter.ClearBeforeFill = true;
            // 
            // materialGradesBindingSource1
            // 
            this.materialGradesBindingSource1.DataMember = "Material_Grades";
            this.materialGradesBindingSource1.DataSource = this.thermal_PMSDataSet;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button2);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Controls.Add(this.cmbUom);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.txtQty);
            this.groupBox2.Controls.Add(this.button1);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.cmbvariant);
            this.groupBox2.Controls.Add(this.txtdrawingno);
            this.groupBox2.Controls.Add(this.label29);
            this.groupBox2.Controls.Add(this.txtmaindrawingno);
            this.groupBox2.Controls.Add(this.label37);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.comboBox1);
            this.groupBox2.Controls.Add(this.label20);
            this.groupBox2.Controls.Add(this.cmbPartGroup);
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.cmbPartname);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.txtpartno);
            this.groupBox2.Location = new System.Drawing.Point(14, 83);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(985, 109);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "groupBox2";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(316, 79);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 17);
            this.label6.TabIndex = 34;
            this.label6.Text = "UOM";
            // 
            // cmbUom
            // 
            this.cmbUom.FormattingEnabled = true;
            this.cmbUom.Location = new System.Drawing.Point(368, 78);
            this.cmbUom.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.cmbUom.Name = "cmbUom";
            this.cmbUom.Size = new System.Drawing.Size(72, 23);
            this.cmbUom.TabIndex = 33;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold);
            this.label30.Location = new System.Drawing.Point(22, 70);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(26, 15);
            this.label30.TabIndex = 32;
            this.label30.Text = "Qty";
            // 
            // txtQty
            // 
            this.txtQty.Location = new System.Drawing.Point(113, 73);
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(100, 23);
            this.txtQty.TabIndex = 31;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Desktop;
            this.button1.ForeColor = System.Drawing.Color.Coral;
            this.button1.Location = new System.Drawing.Point(221, 20);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(62, 27);
            this.button1.TabIndex = 30;
            this.button1.Text = "Copy Part Data";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(636, 23);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 17);
            this.label4.TabIndex = 28;
            this.label4.Text = "Type";
            // 
            // cmbvariant
            // 
            this.cmbvariant.FormattingEnabled = true;
            this.cmbvariant.Location = new System.Drawing.Point(671, 24);
            this.cmbvariant.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.cmbvariant.Name = "cmbvariant";
            this.cmbvariant.Size = new System.Drawing.Size(134, 23);
            this.cmbvariant.TabIndex = 29;
            // 
            // txtdrawingno
            // 
            this.txtdrawingno.Location = new System.Drawing.Point(671, 48);
            this.txtdrawingno.Name = "txtdrawingno";
            this.txtdrawingno.Size = new System.Drawing.Size(176, 23);
            this.txtdrawingno.TabIndex = 27;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.label29.Location = new System.Drawing.Point(520, 45);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(150, 17);
            this.label29.TabIndex = 26;
            this.label29.Text = "Shop Floor Drawing No";
            // 
            // txtmaindrawingno
            // 
            this.txtmaindrawingno.Location = new System.Drawing.Point(368, 47);
            this.txtmaindrawingno.Name = "txtmaindrawingno";
            this.txtmaindrawingno.Size = new System.Drawing.Size(156, 23);
            this.txtmaindrawingno.TabIndex = 18;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.label37.Location = new System.Drawing.Point(250, 48);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(114, 17);
            this.label37.TabIndex = 17;
            this.label37.Text = "Main Drawing No";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.label32.Location = new System.Drawing.Point(7, 44);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(100, 17);
            this.label32.TabIndex = 15;
            this.label32.Text = "Main Assembly";
            // 
            // comboBox1
            // 
            this.comboBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.comboBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(113, 44);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(131, 23);
            this.comboBox1.TabIndex = 16;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.label20.Location = new System.Drawing.Point(774, 21);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(75, 17);
            this.label20.TabIndex = 13;
            this.label20.Text = "Part Group";
            // 
            // cmbPartGroup
            // 
            this.cmbPartGroup.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbPartGroup.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPartGroup.FormattingEnabled = true;
            this.cmbPartGroup.Items.AddRange(new object[] {
            "Main Assembly",
            "Sub Assembly",
            "Brought Out Component"});
            this.cmbPartGroup.Location = new System.Drawing.Point(858, 21);
            this.cmbPartGroup.Name = "cmbPartGroup";
            this.cmbPartGroup.Size = new System.Drawing.Size(121, 23);
            this.cmbPartGroup.TabIndex = 14;
            this.cmbPartGroup.SelectedIndexChanged += new System.EventHandler(this.comboBox6_Leave);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(572, 20);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(41, 23);
            this.button3.TabIndex = 12;
            this.button3.Text = "New";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(289, 19);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 17);
            this.label2.TabIndex = 10;
            this.label2.Text = "Part Name";
            // 
            // cmbPartname
            // 
            this.cmbPartname.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbPartname.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPartname.FormattingEnabled = true;
            this.cmbPartname.Location = new System.Drawing.Point(368, 19);
            this.cmbPartname.Name = "cmbPartname";
            this.cmbPartname.Size = new System.Drawing.Size(198, 23);
            this.cmbPartname.TabIndex = 11;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(46, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(55, 17);
            this.label1.TabIndex = 8;
            this.label1.Text = "Part No";
            // 
            // txtpartno
            // 
            this.txtpartno.Location = new System.Drawing.Point(113, 20);
            this.txtpartno.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.txtpartno.Name = "txtpartno";
            this.txtpartno.Size = new System.Drawing.Size(102, 23);
            this.txtpartno.TabIndex = 9;
            // 
            // frmAddPart
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1011, 566);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.linkLabel2);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.txtEqpName);
            this.Controls.Add(this.linkLabel1);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label10);
            this.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmAddPart";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "frmAddPart";
            this.Load += new System.EventHandler(this.frmAddPart_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel2.PerformLayout();
            this.tableLayoutPanel4.ResumeLayout(false);
            this.tableLayoutPanel4.PerformLayout();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialGradesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.thermal_PMSDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialGradesBindingSource1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtmarkerno;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txtprojectcode;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtplno;
        private System.Windows.Forms.Label label19;
        private Thermal_PMSDataSet thermal_PMSDataSet;
        private System.Windows.Forms.BindingSource materialGradesBindingSource;
        private Thermal_PMSDataSetTableAdapters.Material_GradesTableAdapter material_GradesTableAdapter;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.DateTimePicker dpdate;
        private System.Windows.Forms.TextBox txtverno;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtdescription;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.ComboBox cmbRmtype;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox cmbSpecification;
        private System.Windows.Forms.ComboBox cmbThickNo;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtDensity;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtMMitem;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column9;
        private System.Windows.Forms.TextBox txtApgname;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtapgno;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.BindingSource materialGradesBindingSource1;
        private System.Windows.Forms.TextBox txtEqpName;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.DataGridViewTextBoxColumn Version_No;
        private System.Windows.Forms.DataGridViewTextBoxColumn Version_Date;
        private System.Windows.Forms.DataGridViewTextBoxColumn DocumentNo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Version_Change;
        private System.Windows.Forms.DataGridViewTextBoxColumn Creted_By;
        private System.Windows.Forms.DataGridViewTextBoxColumn Modified_By;
        private System.Windows.Forms.DataGridViewTextBoxColumn Reviewd_By;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.ComboBox cmbptsno;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtRevStatus;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cmbvariant;
        private System.Windows.Forms.TextBox txtdrawingno;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtmaindrawingno;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ComboBox cmbPartGroup;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbPartname;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtpartno;
        private System.Windows.Forms.CheckBox chkIbr;
        private System.Windows.Forms.CheckBox chkEn;
        private System.Windows.Forms.CheckBox chkMtc;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox txtDwt;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtDia;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtW2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtThickness;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtlength;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox txtod;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox txtrmwt;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel4;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox txtfgwt;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox cmbUom;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtQty;
    }
}