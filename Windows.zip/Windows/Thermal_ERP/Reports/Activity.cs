﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;

namespace Thermal_ERP.Reports
{
    
    public partial class Activity : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Thermal_ERP.Properties.Settings.Thermal_PMSConnectionString"].ConnectionString);
        private DataTable dataTable = new DataTable();

        public Activity()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }
        public void BindProjectCode()
        {
            try
            {
                var data2 = db.Project_Masters.Select(c => c.Project_Code).Distinct().ToArray();
                AutoCompleteStringCollection instcol = new AutoCompleteStringCollection();
                instcol.AddRange(data2);
                txtprojectcode.AutoCompleteCustomSource = instcol;
               
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public void BindWorkcenter()
        {
            var sa = (from k in db.WorkCenters where k.CompID == "0001" select new { k.Work_Center_id, k.Work_Center }).Distinct().ToList();
            if (sa.Count > 0)
            {
                cmbWorkCenter.DataSource = sa;
                cmbWorkCenter.DisplayMember = "Work_Center";
                cmbWorkCenter.ValueMember = "Work_Center_id";
                if (cmbWorkCenter.Items.Count > 0)
                {
                    cmbWorkCenter.SelectedIndex = -1;
                }
                else
                {
                    cmbWorkCenter.SelectedIndex = -1;
                }
            }
        }
        private void Activity_Load(object sender, EventArgs e)
        {
            BindProjectCode();
          ///  BindWorkcenter();
        }

        private void txtprojectcode_Leave(object sender, EventArgs e)
        {
            try
            {
                if (txtprojectcode.Text == "")
                {

                }
                else
                {
                    SqlCommand cmd2 = new SqlCommand("Bind_Activity_Report_Data", con);
                    cmd2.CommandType = CommandType.StoredProcedure;
                    cmd2.Parameters.AddWithValue("@Company", "0001");
                    cmd2.Parameters.AddWithValue("@ProjectCode", txtprojectcode.Text.Trim());
                    cmd2.Parameters.AddWithValue("@PartNo", "");
                    cmd2.Parameters.AddWithValue("@Parameter", 1);
                    cmd2.Parameters.AddWithValue("@Part_Sl_No", "");
                    SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
                    DataSet ds2 = new DataSet();
                    da2.Fill(ds2, "x");
                    if (ds2.Tables["x"].Rows.Count > 0)
                    {
                        dgActivity.DataSource = ds2.Tables[0];
                        for (int i = 0; i < dgActivity.Rows.Count - 1; i++)
                        {
                            string STATUS = (dgActivity.Rows[i].Cells["Status"].Value == "" || dgActivity.Rows[i].Cells["Status"].Value == null) ? "" : dgActivity.Rows[i].Cells["Status"].Value.ToString();
                            if (("Open" == STATUS))
                            {

                            }
                            if (("InProcess" == STATUS))
                            {
                                dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;
                            }
                            if (("Closed" == STATUS))
                            {
                                dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Yellow;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Record Not found");
                    }

                    string query = "select distinct(Activity_Part_No) from Project_ActivityChart where CompID='"+"0001"+"' and Activity_Part_No like '%'+'"+txtprojectcode.Text.Trim()+"'+'%'";                 
               
                    SqlCommand cmd = new SqlCommand(query, con);
                    con.Open();
                    // create data adapter
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable DTR = new DataTable();
                    // this will query your database and return the result to your datatable
                    da.Fill(DTR);
                    cmbPartNo.DataSource = DTR;
                    cmbPartNo.DisplayMember = "Activity_Part_No";
                    cmbPartNo.ValueMember = "Activity_Part_No";
                    if(cmbPartNo.Items.Count>0)
                    {
                        cmbPartNo.SelectedIndex = -1;
                    }
                    else
                    {
                        cmbPartNo.SelectedIndex = -1;
                    }
                    con.Close();
                    da.Dispose();
                    // var table = new DataTable();
                    //    using (var da = new SqlDataAdapter("select distinct(Activity_Part_No) from Project_ActivityChart where CompID='" + "0001" + "' and Activity_Part_No Like '%'" + txtprojectcode.Text.Trim() + "' ", con)
                    //    {
                    //        da.Fill(table);
                    //}
                }
           
       
              

            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void cmbPartNo_Leave(object sender, EventArgs e)
        {
            try
            {
                if(cmbPartNo.Text=="")
                {

                }
                else
                {
                    SqlCommand cmd2 = new SqlCommand("Bind_Activity_Report_Data", con);
                    cmd2.CommandType = CommandType.StoredProcedure;
                    cmd2.Parameters.AddWithValue("@Company", "0001");
                    cmd2.Parameters.AddWithValue("@ProjectCode", txtprojectcode.Text.Trim());
                    cmd2.Parameters.AddWithValue("@PartNo", cmbPartNo.Text.Trim());
                    cmd2.Parameters.AddWithValue("@Parameter", 2);
                    cmd2.Parameters.AddWithValue("@Part_Sl_No", "");
                    SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
                    DataSet ds2 = new DataSet();
                    da2.Fill(ds2, "x");
                    if (ds2.Tables["x"].Rows.Count > 0)
                    {
                        dgActivity.DataSource = ds2.Tables[0];
                        for (int i = 0; i < dgActivity.Rows.Count - 1; i++)
                        {
                            string STATUS = (dgActivity.Rows[i].Cells["Status"].Value == "" || dgActivity.Rows[i].Cells["Status"].Value == null) ? "" : dgActivity.Rows[i].Cells["Status"].Value.ToString();
                            if (("Open" == STATUS))
                            {

                            }
                            if (("InProcess" == STATUS))
                            {
                                dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;
                            }
                            if (("Closed" == STATUS))
                            {
                                dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Yellow;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Record Not found");
                    }
                    var sa = (from k in db.Project_ActivityCharts where k.CompID == "0001" && k.Activity_Part_No == cmbPartNo.Text.Trim() select new { k.Part_Sl_No }).Distinct().ToList();
                    if(sa.Count>0)
                    {
                        cmbWorkCenter.DataSource = sa;
                        cmbWorkCenter.DisplayMember = "Part_Sl_No";
                        cmbWorkCenter.ValueMember = "Part_Sl_No";
                        if(cmbWorkCenter.Items.Count>0)
                        {
                            cmbWorkCenter.SelectedIndex = -1;
                        }
                        else
                        {
                            cmbWorkCenter.SelectedIndex = -1;
                        }
                    }
                }
               
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtprojectcode.Text = "";
            cmbPartNo.Text = "";
            if (dgActivity.Rows.Count > 0)
            {
                for (int i = 0; i < dgActivity.Rows.Count - 1; i++)
                {
                    dgActivity.Rows.RemoveAt(i);
                    i--;
                    while (dgActivity.Rows.Count == 0)
                        continue;
                }
            }
        }

        private void dgActivity_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void cmbWorkCenter_Leave(object sender, EventArgs e)
        {
            try
            {
                if (cmbWorkCenter.Text == "")
                {

                }
                else
                {
                    SqlCommand cmd2 = new SqlCommand("Bind_Activity_Report_Data", con);
                    cmd2.CommandType = CommandType.StoredProcedure;
                    cmd2.Parameters.AddWithValue("@Company", "0001");
                    cmd2.Parameters.AddWithValue("@ProjectCode", txtprojectcode.Text.Trim());
                    cmd2.Parameters.AddWithValue("@PartNo", cmbPartNo.Text.Trim());
                    cmd2.Parameters.AddWithValue("@Parameter", 3);
                    cmd2.Parameters.AddWithValue("@Part_Sl_No", cmbWorkCenter.Text.Trim());
                    SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
                    DataSet ds2 = new DataSet();
                    da2.Fill(ds2, "x");
                    if (ds2.Tables["x"].Rows.Count > 0)
                    {
                        dgActivity.DataSource = ds2.Tables[0];
                        for (int i = 0; i < dgActivity.Rows.Count - 1; i++)
                        {
                            string STATUS = (dgActivity.Rows[i].Cells["Status"].Value == "" || dgActivity.Rows[i].Cells["Status"].Value == null) ? "" : dgActivity.Rows[i].Cells["Status"].Value.ToString();
                            if (("Open" == STATUS))
                            {

                            }
                            if (("InProcess" == STATUS))
                            {
                                dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;
                            }
                            if (("Closed" == STATUS))
                            {
                                dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Yellow;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Record Not found");
                    }

                    ////string query = "select distinct(Activity_Part_No) from Project_ActivityChart where CompID='" + "0001" + "' and Activity_Part_No like '%'+'" + txtprojectcode.Text.Trim() + "'+'%'";

                    ////SqlCommand cmd = new SqlCommand(query, con);
                    ////con.Open();
                    ////// create data adapter
                    ////SqlDataAdapter da = new SqlDataAdapter(cmd);
                    ////// this will query your database and return the result to your datatable
                    ////da.Fill(dataTable);
                    ////cmbPartNo.DataSource = dataTable;
                    ////cmbPartNo.DisplayMember = "Activity_Part_No";
                    ////cmbPartNo.ValueMember = "Activity_Part_No";
                    ////if (cmbPartNo.Items.Count > 0)
                    ////{
                    ////    cmbPartNo.SelectedIndex = -1;
                    ////}
                    ////else
                    ////{
                    ////    cmbPartNo.SelectedIndex = -1;
                    ////}
                    ////con.Close();
                    ////da.Dispose();
                    // var table = new DataTable();
                    //    using (var da = new SqlDataAdapter("select distinct(Activity_Part_No) from Project_ActivityChart where CompID='" + "0001" + "' and Activity_Part_No Like '%'" + txtprojectcode.Text.Trim() + "' ", con)
                    //    {
                    //        da.Fill(table);
                    //}
                }




            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
