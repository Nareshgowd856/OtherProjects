﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Thermal_ERP.Masters
{
    public partial class Variant : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        public Variant()
        {
            InitializeComponent();
        }

        public void BindAsembly()
        {
            try
            {
                var sa = (from k in db.SubAssembly_Masters where k.CompID == "0001" select new { k.Sub_Assembly_Name, k.Sub_Assembly_ID }).Distinct().ToList();
                if (sa.Count > 0)
                {
                    cmbassembly.DataSource = sa;
                    cmbassembly.DisplayMember = "Sub_Assembly_Name";
                    cmbassembly.ValueMember = "Sub_Assembly_ID";
                    if (cmbassembly.Items.Count > 0)
                    {
                        cmbassembly.SelectedIndex = -1;
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
           
        }
        public void BindGrid()
        {
            var sa = (from k in db.Variant_Masters where k.CompID == "0001" select new { k.Variant_ID, k.Variant_Name, k.Sub_Assembly_Name }).ToList();
            if(sa.Count>0)
            {
                dguommaster.DataSource = sa;
            }
        }
        public void Clear()
        {
            txtUOMid.Text = "";
            txtUOMName.Text = "";
            cmbassembly.Text = "";
        }
        private void Variant_Load(object sender, EventArgs e)
        {
            try
            {
                BindAsembly();
                BindGrid();
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtUOMid.Text == "")
                {
                    MessageBox.Show("Please Enter Variant Id");
                    txtUOMid.Focus();
                    return;
                }
                else if(cmbassembly.Text=="")
                {
                    MessageBox.Show("Please Select SubAssembly Name...");
                    cmbassembly.Focus();
                    return;
                }
                else if(txtUOMName.Text=="")
                {
                    MessageBox.Show("Please Enter variant Name..");
                    txtUOMName.Focus();
                    return;
                }
                else
                {
                    if ((from k in db.Variant_Masters where k.CompID == "0001" && k.Variant_ID == txtUOMid.Text select k).Count() > 0)
                    {
                        db.Sp_Delete_Variant_Master("0001", txtUOMid.Text);
                        Variant_Master v = new Variant_Master();
                        v.Variant_ID = txtUOMid.Text;
                        v.Variant_Name = (txtUOMName.Text == "") ? "" : txtUOMName.Text;
                        v.Sub_Assembly_Name = (cmbassembly.Text == "") ? "" : cmbassembly.Text;
                        v.CompID = "0001";                       
                        v.Modified_By = "";
                        v.Modifed_On = DateTime.Now;
                        db.Variant_Masters.InsertOnSubmit(v);
                        db.SubmitChanges();
                        BindGrid();
                        Clear();
                        MessageBox.Show("Recoerd Updated Successfully");
                        return;
                    }
                    else
                    {
                        Variant_Master v = new Variant_Master();
                       
                        v.Variant_Name = (txtUOMName.Text == "") ? "" : txtUOMName.Text;
                        v.Sub_Assembly_Name = (cmbassembly.Text == "") ? "" : cmbassembly.Text;
                        v.CompID = "0001";
                        v.Modified_By = "";
                        v.Modifed_On = DateTime.Now;
                        //var sa = (db.Sp_autoincrement_Variant_Master("0001"));
                        //v.Variant_ID = sa.FirstOrDefault().Variant_ID;
                        v.Variant_ID = txtUOMid.Text;
                        db.Variant_Masters.InsertOnSubmit(v);
                        db.SubmitChanges();
                        BindGrid();
                        Clear();
                        MessageBox.Show("Recoerd Saved Successfully");
                        return;
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dguommaster_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if(e.RowIndex>=0)
                {
                    string varintid = (dguommaster.Rows[e.RowIndex].Cells["Variant_ID"].Value.ToString());
                    var sa = (from k in db.Variant_Masters where k.Variant_ID == varintid select new { k.Variant_ID, k.Variant_Name, k.Sub_Assembly_Name }).ToList();
                    if(sa.Count>0)
                    {
                        txtUOMid.Text = sa[0].Variant_ID;
                        txtUOMName.Text = sa[0].Variant_Name;
                        cmbassembly.Text = sa[0].Sub_Assembly_Name;
                    }
                }


            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void txtUOMid_Leave(object sender, EventArgs e)
        {
            try
            {
                var sa = (from k in db.Variant_Masters where k.CompID == "0001" && k.Variant_ID == txtUOMid.Text select k).ToList();
                if(sa.Count>0)
                {
                    MessageBox.Show("This Id is Already Existing.. Please try Another id..");
                    txtUOMid.Text = "";
                    txtUOMid.Focus();
                    return;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
