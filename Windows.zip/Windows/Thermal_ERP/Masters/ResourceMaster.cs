﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Thermal_ERP.Masters
{
    public partial class ResourceMaster : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        public ResourceMaster()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        public void BindGrid()
        {
            var sa = (from k in db.Resource_Masters where k.CompID == "0001" select new { k.Resource_Id, k.Resource_Name, k.Skill_Set }).ToList();
            if(sa.Count>0)
            {
                dguommaster.DataSource = sa;
            }
        }
        public void Clear()
        {
            txtUOMid.Text = "";
            txtUOMName.Text = "";
            cmbskillset.Text = "";
            BindGrid();
        }
        private void btnReset_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void ResourceMaster_Load(object sender, EventArgs e)
        {
            Clear();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if(txtUOMName.Text==""||txtUOMName.Text==null)
                {
                    MessageBox.Show("Please Enter Resource Name");
                    txtUOMName.Focus();
                    return;
                }
               else if (cmbskillset.Text == "" || cmbskillset.Text == null)
                {
                    MessageBox.Show("Please Enter Skill Set");
                    cmbskillset.Focus();
                    return;
                }
                else
                {
                    if((from k in db.Resource_Masters where k.CompID=="0001"&& k.Resource_Id==txtUOMid.Text.Trim() select k).Count()>0)
                    {
                        db.Sp_Delete_ResourceMaster("0001", txtUOMid.Text.Trim());
                        Resource_Master r = new Resource_Master();
                        r.Resource_Id = txtUOMid.Text;
                        r.Resource_Name = txtUOMName.Text;
                        r.Skill_Set = cmbskillset.Text;
                        r.CompID = "0001";
                        r.Modified_By = "";
                        r.Modified_On = DateTime.Now;
                        db.Resource_Masters.InsertOnSubmit(r);
                        db.SubmitChanges();
                        MessageBox.Show("Recored Updated Succesfully");
                        Clear();
                        return;
                    }
                    else
                    {
                        Resource_Master r = new Resource_Master();
                       /// r.Resource_Id = txtUOMid.Text;
                        r.Resource_Name = txtUOMName.Text;
                        r.Skill_Set = cmbskillset.Text;
                        r.CompID = "0001";
                        r.Modified_By = "";
                        r.Modified_On = DateTime.Now;
                        var sa = db.Sp_autoincrement_ResourceMaster("0001").FirstOrDefault();
                        r.Resource_Id = sa.Resource_Id;
                        db.Resource_Masters.InsertOnSubmit(r);
                        db.SubmitChanges();
                        MessageBox.Show("Recored Saved Succesfully");
                        Clear();
                        return;
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void dguommaster_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if(e.RowIndex>=0)
                {
                    string id = (dguommaster.Rows[e.RowIndex].Cells["Resource_Id"].Value.ToString());
                    var sa = (from k in db.Resource_Masters where k.CompID == "0001" && k.Resource_Id == id select new { k.Resource_Id, k.Resource_Name, k.Skill_Set }).ToList();
                    if(sa.Count>0)
                    {
                        txtUOMid.Text = sa[0].Resource_Id;
                        txtUOMName.Text = sa[0].Resource_Name;
                        cmbskillset.Text = sa[0].Skill_Set;
                    }
                    else
                    {
                        MessageBox.Show("recored Not Found");
                        return;
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
