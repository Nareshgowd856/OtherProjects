﻿namespace Thermal_ERP.Masters
{
    partial class ReportForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.cmbPartNo = new System.Windows.Forms.ComboBox();
            this.cmbWorkCenter = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.txtDate = new System.Windows.Forms.MaskedTextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtReportNo = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.dgActivity = new System.Windows.Forms.DataGridView();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.label38 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.Activity_Code = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Activity_Description = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Work_Center = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Person_Rep = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Planned_StartDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Planned_CompletionDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Planned_Duration = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Actual_StartDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Actual_Completiondate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Actual_Duration = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Activity_Part_No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Ref_Doc_No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Resion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Remarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Part_Sl_No = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Status = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tableLayoutPanel1.SuspendLayout();
            this.tableLayoutPanel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgActivity)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbPartNo
            // 
            this.cmbPartNo.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbPartNo.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPartNo.BackColor = System.Drawing.SystemColors.Info;
            this.cmbPartNo.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPartNo.FormattingEnabled = true;
            this.cmbPartNo.Location = new System.Drawing.Point(382, 32);
            this.cmbPartNo.Name = "cmbPartNo";
            this.cmbPartNo.Size = new System.Drawing.Size(470, 23);
            this.cmbPartNo.TabIndex = 2;
            this.cmbPartNo.Leave += new System.EventHandler(this.cmbPartNo_Leave);
            // 
            // cmbWorkCenter
            // 
            this.cmbWorkCenter.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest;
            this.cmbWorkCenter.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbWorkCenter.BackColor = System.Drawing.SystemColors.Info;
            this.cmbWorkCenter.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbWorkCenter.FormattingEnabled = true;
            this.cmbWorkCenter.Location = new System.Drawing.Point(94, 32);
            this.cmbWorkCenter.Name = "cmbWorkCenter";
            this.cmbWorkCenter.Size = new System.Drawing.Size(221, 23);
            this.cmbWorkCenter.TabIndex = 1;
            this.cmbWorkCenter.Leave += new System.EventHandler(this.cmbWorkCenter_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Red;
            this.label2.Location = new System.Drawing.Point(864, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(149, 25);
            this.label2.TabIndex = 5;
            this.label2.Text = "Activity Report ";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(321, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 17);
            this.label5.TabIndex = 8;
            this.label5.Text = "Part No";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(3, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(85, 17);
            this.label7.TabIndex = 10;
            this.label7.Text = "Work Center";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 6;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle());
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Controls.Add(this.txtDate, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.label7, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.label9, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtReportNo, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.cmbWorkCenter, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.label8, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.label5, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.cmbPartNo, 3, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(29, 42);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 4;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(964, 69);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // txtDate
            // 
            this.txtDate.BackColor = System.Drawing.SystemColors.Info;
            this.txtDate.ForeColor = System.Drawing.Color.Black;
            this.txtDate.Location = new System.Drawing.Point(382, 3);
            this.txtDate.Mask = "0000-00-00 90:00";
            this.txtDate.Name = "txtDate";
            this.txtDate.ReadOnly = true;
            this.txtDate.Size = new System.Drawing.Size(120, 20);
            this.txtDate.TabIndex = 0;
            this.txtDate.ValidatingType = typeof(System.DateTime);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(3, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(71, 17);
            this.label9.TabIndex = 2;
            this.label9.Text = "Report No";
            // 
            // txtReportNo
            // 
            this.txtReportNo.Font = new System.Drawing.Font("Segoe UI Semibold", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtReportNo.Location = new System.Drawing.Point(94, 3);
            this.txtReportNo.Name = "txtReportNo";
            this.txtReportNo.ReadOnly = true;
            this.txtReportNo.Size = new System.Drawing.Size(100, 23);
            this.txtReportNo.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold);
            this.label8.Location = new System.Drawing.Point(321, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 17);
            this.label8.TabIndex = 6;
            this.label8.Text = "Date";
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 1;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Controls.Add(this.dgActivity, 0, 0);
            this.tableLayoutPanel2.Location = new System.Drawing.Point(29, 139);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(970, 382);
            this.tableLayoutPanel2.TabIndex = 12;
            // 
            // dgActivity
            // 
            this.dgActivity.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgActivity.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Activity_Code,
            this.Activity_Description,
            this.Work_Center,
            this.Person_Rep,
            this.Planned_StartDate,
            this.Planned_CompletionDate,
            this.Planned_Duration,
            this.Actual_StartDate,
            this.Actual_Completiondate,
            this.Actual_Duration,
            this.Activity_Part_No,
            this.Ref_Doc_No,
            this.Resion,
            this.Remarks,
            this.Part_Sl_No,
            this.Status});
            this.dgActivity.Location = new System.Drawing.Point(3, 3);
            this.dgActivity.Name = "dgActivity";
            this.dgActivity.Size = new System.Drawing.Size(961, 376);
            this.dgActivity.TabIndex = 0;
            this.dgActivity.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgActivity_CellContentClick);
            this.dgActivity.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgActivity_CellEndEdit);
            // 
            // btnClose
            // 
            this.btnClose.BackColor = System.Drawing.Color.White;
            this.btnClose.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ForeColor = System.Drawing.Color.Red;
            this.btnClose.Location = new System.Drawing.Point(924, 527);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 28);
            this.btnClose.TabIndex = 3;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = false;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnSubmit
            // 
            this.btnSubmit.BackColor = System.Drawing.Color.White;
            this.btnSubmit.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSubmit.ForeColor = System.Drawing.Color.Red;
            this.btnSubmit.Location = new System.Drawing.Point(843, 527);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 28);
            this.btnSubmit.TabIndex = 1;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = false;
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.White;
            this.btnReset.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.ForeColor = System.Drawing.Color.Red;
            this.btnReset.Location = new System.Drawing.Point(762, 527);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(75, 28);
            this.btnReset.TabIndex = 2;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.OrangeRed;
            this.label38.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.White;
            this.label38.Location = new System.Drawing.Point(410, 119);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(337, 17);
            this.label38.TabIndex = 13;
            this.label38.Text = "Please Enter Dates yyyy-MM-dd HH:mm Format Only";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.ForeColor = System.Drawing.Color.Red;
            this.button2.Location = new System.Drawing.Point(28, 113);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 28);
            this.button2.TabIndex = 16;
            this.button2.Text = "Search";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // Activity_Code
            // 
            this.Activity_Code.DataPropertyName = "Activity_Code";
            this.Activity_Code.HeaderText = "Activity Code";
            this.Activity_Code.Name = "Activity_Code";
            this.Activity_Code.ReadOnly = true;
            // 
            // Activity_Description
            // 
            this.Activity_Description.DataPropertyName = "Activity_Description";
            this.Activity_Description.HeaderText = "Activity Name";
            this.Activity_Description.Name = "Activity_Description";
            this.Activity_Description.ReadOnly = true;
            // 
            // Work_Center
            // 
            this.Work_Center.DataPropertyName = "Work_Center";
            this.Work_Center.HeaderText = "Work Center";
            this.Work_Center.Name = "Work_Center";
            this.Work_Center.ReadOnly = true;
            // 
            // Person_Rep
            // 
            this.Person_Rep.DataPropertyName = "Person_Rep";
            this.Person_Rep.HeaderText = "Person Resp";
            this.Person_Rep.Name = "Person_Rep";
            this.Person_Rep.ReadOnly = true;
            // 
            // Planned_StartDate
            // 
            this.Planned_StartDate.DataPropertyName = "Planned_StartDate";
            dataGridViewCellStyle1.Format = "G";
            dataGridViewCellStyle1.NullValue = null;
            this.Planned_StartDate.DefaultCellStyle = dataGridViewCellStyle1;
            this.Planned_StartDate.HeaderText = "Planned Start Date";
            this.Planned_StartDate.Name = "Planned_StartDate";
            this.Planned_StartDate.ReadOnly = true;
            // 
            // Planned_CompletionDate
            // 
            this.Planned_CompletionDate.DataPropertyName = "Planned_CompletionDate";
            dataGridViewCellStyle2.Format = "G";
            this.Planned_CompletionDate.DefaultCellStyle = dataGridViewCellStyle2;
            this.Planned_CompletionDate.HeaderText = "Planned Completion Date";
            this.Planned_CompletionDate.Name = "Planned_CompletionDate";
            this.Planned_CompletionDate.ReadOnly = true;
            // 
            // Planned_Duration
            // 
            this.Planned_Duration.DataPropertyName = "Planned_Duration";
            this.Planned_Duration.HeaderText = "Planed Duration";
            this.Planned_Duration.Name = "Planned_Duration";
            this.Planned_Duration.ReadOnly = true;
            // 
            // Actual_StartDate
            // 
            this.Actual_StartDate.DataPropertyName = "Actual_StartDate";
            this.Actual_StartDate.HeaderText = "Actual Start Date";
            this.Actual_StartDate.Name = "Actual_StartDate";
            // 
            // Actual_Completiondate
            // 
            this.Actual_Completiondate.DataPropertyName = "Actual_Completiondate";
            this.Actual_Completiondate.HeaderText = "Actual Completion Date";
            this.Actual_Completiondate.Name = "Actual_Completiondate";
            // 
            // Actual_Duration
            // 
            this.Actual_Duration.DataPropertyName = "Actual_Duration";
            this.Actual_Duration.HeaderText = "Actual Duration";
            this.Actual_Duration.Name = "Actual_Duration";
            this.Actual_Duration.ReadOnly = true;
            // 
            // Activity_Part_No
            // 
            this.Activity_Part_No.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Activity_Part_No.DataPropertyName = "Activity_Part_No";
            this.Activity_Part_No.HeaderText = "Part No";
            this.Activity_Part_No.Name = "Activity_Part_No";
            this.Activity_Part_No.Width = 200;
            // 
            // Ref_Doc_No
            // 
            this.Ref_Doc_No.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Ref_Doc_No.DataPropertyName = "Ref_Doc_No";
            this.Ref_Doc_No.HeaderText = "Ref Doc No";
            this.Ref_Doc_No.Name = "Ref_Doc_No";
            this.Ref_Doc_No.Width = 150;
            // 
            // Resion
            // 
            this.Resion.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Resion.DataPropertyName = "Resion";
            this.Resion.HeaderText = "Resion";
            this.Resion.Name = "Resion";
            this.Resion.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Resion.Width = 150;
            // 
            // Remarks
            // 
            this.Remarks.DataPropertyName = "Remarks";
            this.Remarks.HeaderText = "Remarks";
            this.Remarks.Name = "Remarks";
            // 
            // Part_Sl_No
            // 
            this.Part_Sl_No.DataPropertyName = "Part_Sl_No";
            this.Part_Sl_No.HeaderText = "PartNo";
            this.Part_Sl_No.Name = "Part_Sl_No";
            this.Part_Sl_No.Visible = false;
            // 
            // Status
            // 
            this.Status.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Status.DataPropertyName = "Status";
            this.Status.HeaderText = "Status";
            this.Status.Name = "Status";
            this.Status.ReadOnly = true;
            // 
            // ReportForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1011, 566);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnSubmit);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.tableLayoutPanel2);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.label2);
            this.Name = "ReportForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ReportForm";
            this.Load += new System.EventHandler(this.ReportForm_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.tableLayoutPanel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgActivity)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox cmbPartNo;
        private System.Windows.Forms.ComboBox cmbWorkCenter;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtReportNo;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.DataGridView dgActivity;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.MaskedTextBox txtDate;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Activity_Code;
        private System.Windows.Forms.DataGridViewTextBoxColumn Activity_Description;
        private System.Windows.Forms.DataGridViewTextBoxColumn Work_Center;
        private System.Windows.Forms.DataGridViewTextBoxColumn Person_Rep;
        private System.Windows.Forms.DataGridViewTextBoxColumn Planned_StartDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Planned_CompletionDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Planned_Duration;
        private System.Windows.Forms.DataGridViewTextBoxColumn Actual_StartDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Actual_Completiondate;
        private System.Windows.Forms.DataGridViewTextBoxColumn Actual_Duration;
        private System.Windows.Forms.DataGridViewTextBoxColumn Activity_Part_No;
        private System.Windows.Forms.DataGridViewTextBoxColumn Ref_Doc_No;
        private System.Windows.Forms.DataGridViewTextBoxColumn Resion;
        private System.Windows.Forms.DataGridViewTextBoxColumn Remarks;
        private System.Windows.Forms.DataGridViewTextBoxColumn Part_Sl_No;
        private System.Windows.Forms.DataGridViewTextBoxColumn Status;
    }
}