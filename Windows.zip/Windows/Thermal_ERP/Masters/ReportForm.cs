﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.Sql;
namespace Thermal_ERP.Masters
{

    public partial class ReportForm : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        //private DataTable BatteryInformationTests;
        //dgActivity.DataSource = BatteryInformationTests;
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Thermal_ERP.Properties.Settings.Thermal_PMSConnectionString"].ConnectionString);
        public ReportForm()
        {
            InitializeComponent();
        }

       
        private void ReportForm_Load(object sender, EventArgs e)
        {
            txtDate.Text = Convert.ToString(DateTime.Now);
            var sa = (from k in db.WorkCenters where k.CompID == "0001" select new { k.Work_Center_id,k.Work_Center }).Distinct().ToList();
            if(sa.Count>0)
            {
                cmbWorkCenter.DataSource = sa;
                cmbWorkCenter.DisplayMember = "Work_Center";
                cmbWorkCenter.ValueMember = "Work_Center_id";
                if(cmbWorkCenter.Items.Count>0)
                {
                    cmbWorkCenter.SelectedIndex = -1;
                }
                else
                {
                    cmbWorkCenter.SelectedIndex = -1;
                }
            }
            DataGridViewComboBoxColumn combo = (DataGridViewComboBoxColumn)dgActivity.Columns["Resion"];
            combo.DataSource = "";
            //DataTable dt = new DataTable();
            //DataColumn dc1 = new DataColumn("Resion");        
            //dt.Columns.Add(dc1);      
            //dt.Rows.Add(1, "Resion");
            //dt.Rows.Add(2, "Resion");
            //dt.Rows.Add(3, "Resion");
            //DataGridViewComboBoxColumn c1 = new DataGridViewComboBoxColumn();
            //c1.DataSource = dt;
            //c1.DisplayMember = "Resion";
            //c1.ValueMember = "Resion";
            //for (int i = 0; i < dt.Rows.Count; i++)
            //{
            //    if (dt.Rows[i]["Resion"].ToString() == "4")//set the default value based on value member ID
            //    {
            //        c1.DefaultCellStyle.NullValue = dt.Rows[i]["Resion"];
            //    }
            //}
            //dgActivity.Columns.Add(c1);
        }

       

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                int countdrid = 0;
                for(int i=0;i<dgActivity.Rows.Count-1;i++)
                {
                    string revison = (dgActivity.Rows[i].Cells["Resion"].Value == "" || dgActivity.Rows[i].Cells["Resion"].Value == null) ? "" : dgActivity.Rows[i].Cells["Resion"].Value.ToString();
                    string planstartdate = (dgActivity.Rows[i].Cells["Planned_StartDate"].Value == "" || dgActivity.Rows[i].Cells["Planned_StartDate"].Value == null) ? "" : dgActivity.Rows[i].Cells["Planned_StartDate"].Value.ToString();
                    string actualstartdates = (dgActivity.Rows[i].Cells["Actual_StartDate"].Value == "" || dgActivity.Rows[i].Cells["Actual_StartDate"].Value == null) ? "" : dgActivity.Rows[i].Cells["Actual_StartDate"].Value.ToString();
                    if ((""==actualstartdates)||(null==actualstartdates) && revison == "")
                    {
                        dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;
                        countdrid++;
                      
                    }
                    else if (Convert.ToDateTime(planstartdate)<Convert.ToDateTime(actualstartdates)&&revison=="")
                    {                       
                        dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;
                        countdrid++;
                    }
                    else if (Convert.ToDateTime(planstartdate) > Convert.ToDateTime(actualstartdates) && revison == "")
                    {
                        dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;
                        countdrid++;
                    }
                    else if (Convert.ToDateTime(planstartdate) == Convert.ToDateTime(actualstartdates))
                    {
                        dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Yellow;
                    }
                    
                }
                if (countdrid >= 1)
                {
                    MessageBox.Show("Please Enter Revision...");
                    return;
                }
                else
                {

                    if ((from k in db.Activity_Reports where k.CompID == "0001" && k.Report_No == txtReportNo.Text.Trim() select k).Count() > 0)
                    {
                        db.Sp_Delete_Activity_Report("0001", txtReportNo.Text.Trim());
                        for (int i = 0; i < dgActivity.Rows.Count - 1; i++)
                        {
                            Activity_Report a = new Activity_Report();
                            a.Report_No = txtReportNo.Text;
                            a.Date = txtDate.Text;
                            a.Main_Work_Center = cmbWorkCenter.Text;
                            a.PartList_No = cmbPartNo.Text;
                            a.Activity_Code = (dgActivity.Rows[i].Cells["Activity_Code"].Value == "" || dgActivity.Rows[i].Cells["Activity_Code"].Value == null) ? "" : dgActivity.Rows[i].Cells["Activity_Code"].Value.ToString();
                            a.Activity_Description = (dgActivity.Rows[i].Cells["Activity_Description"].Value == "" || dgActivity.Rows[i].Cells["Activity_Description"].Value == null) ? "" : dgActivity.Rows[i].Cells["Activity_Description"].Value.ToString();
                            a.Work_Center = (dgActivity.Rows[i].Cells["Work_Center"].Value == "" || dgActivity.Rows[i].Cells["Work_Center"].Value == null) ? "" : dgActivity.Rows[i].Cells["Work_Center"].Value.ToString();
                            a.Person_Rep = (dgActivity.Rows[i].Cells["Person_Rep"].Value == "" || dgActivity.Rows[i].Cells["Person_Rep"].Value == null) ? "" : dgActivity.Rows[i].Cells["Person_Rep"].Value.ToString();
                            a.Planned_StartDate = (dgActivity.Rows[i].Cells["Planned_StartDate"].Value == "" || dgActivity.Rows[i].Cells["Planned_StartDate"].Value == null) ? "" : dgActivity.Rows[i].Cells["Planned_StartDate"].Value.ToString();
                            a.Planned_CompletionDate = (dgActivity.Rows[i].Cells["Planned_CompletionDate"].Value == "" || dgActivity.Rows[i].Cells["Planned_CompletionDate"].Value == null) ? "" : dgActivity.Rows[i].Cells["Planned_CompletionDate"].Value.ToString();
                            a.Actual_StartDate = (dgActivity.Rows[i].Cells["Actual_StartDate"].Value == "" || dgActivity.Rows[i].Cells["Actual_StartDate"].Value == null) ? "" : dgActivity.Rows[i].Cells["Actual_StartDate"].Value.ToString();
                            a.Actual_Completiondate = (dgActivity.Rows[i].Cells["Actual_Completiondate"].Value == "" || dgActivity.Rows[i].Cells["Actual_Completiondate"].Value == null) ? "" : dgActivity.Rows[i].Cells["Actual_Completiondate"].Value.ToString();
                            a.Planned_Duration = (dgActivity.Rows[i].Cells["Planned_Duration"].Value == "" || dgActivity.Rows[i].Cells["Planned_Duration"].Value == null) ? "" : dgActivity.Rows[i].Cells["Planned_Duration"].Value.ToString();
                            a.Actual_Duration = (dgActivity.Rows[i].Cells["Actual_Duration"].Value == "" || dgActivity.Rows[i].Cells["Actual_Duration"].Value == null) ? "" : dgActivity.Rows[i].Cells["Actual_Duration"].Value.ToString();
                            a.Resion = (dgActivity.Rows[i].Cells["Resion"].Value == "" || dgActivity.Rows[i].Cells["Resion"].Value == null) ? "" : dgActivity.Rows[i].Cells["Resion"].Value.ToString();
                            a.Remarks = (dgActivity.Rows[i].Cells["Remarks"].Value == "" || dgActivity.Rows[i].Cells["Remarks"].Value == null) ? "" : dgActivity.Rows[i].Cells["Remarks"].Value.ToString();
                            a.Ref_Doc_No = (dgActivity.Rows[i].Cells["Ref_Doc_No"].Value == "" || dgActivity.Rows[i].Cells["Ref_Doc_No"].Value == null) ? "" : dgActivity.Rows[i].Cells["Ref_Doc_No"].Value.ToString();
                            a.Activity_Part_No = (dgActivity.Rows[i].Cells["Activity_Part_No"].Value == "" || dgActivity.Rows[i].Cells["Activity_Part_No"].Value == null) ? "" : dgActivity.Rows[i].Cells["Activity_Part_No"].Value.ToString();
                            a.Part_Sl_No = (dgActivity.Rows[i].Cells["Part_Sl_No"].Value == "" || dgActivity.Rows[i].Cells["Part_Sl_No"].Value == null) ? "" : dgActivity.Rows[i].Cells["Part_Sl_No"].Value.ToString();
                            a.Status = (dgActivity.Rows[i].Cells["Status"].Value == "" || dgActivity.Rows[i].Cells["Status"].Value == null) ? "" : dgActivity.Rows[i].Cells["Status"].Value.ToString();
                            a.CompID = "0001";
                            a.Modified_By = "";
                            a.Modified_On = DateTime.Now;
                            db.Activity_Reports.InsertOnSubmit(a);

                        }
                        db.SubmitChanges();
                        MessageBox.Show("Recored Updated Succesfully");
                        Clear();
                        return;
                    }
                    else
                    {
                        for (int i = 0; i < dgActivity.Rows.Count - 1; i++)
                        {
                            Activity_Report a = new Activity_Report();

                            a.Date = txtDate.Text;
                            a.Main_Work_Center = cmbWorkCenter.Text;
                            a.PartList_No = cmbPartNo.Text;
                            a.Activity_Code = (dgActivity.Rows[i].Cells["Activity_Code"].Value == "" || dgActivity.Rows[i].Cells["Activity_Code"].Value == null) ? "" : dgActivity.Rows[i].Cells["Activity_Code"].Value.ToString();
                            a.Activity_Description = (dgActivity.Rows[i].Cells["Activity_Description"].Value == "" || dgActivity.Rows[i].Cells["Activity_Description"].Value == null) ? "" : dgActivity.Rows[i].Cells["Activity_Description"].Value.ToString();
                            a.Work_Center = (dgActivity.Rows[i].Cells["Work_Center"].Value == "" || dgActivity.Rows[i].Cells["Work_Center"].Value == null) ? "" : dgActivity.Rows[i].Cells["Work_Center"].Value.ToString();
                            a.Person_Rep = (dgActivity.Rows[i].Cells["Person_Rep"].Value == "" || dgActivity.Rows[i].Cells["Person_Rep"].Value == null) ? "" : dgActivity.Rows[i].Cells["Person_Rep"].Value.ToString();
                            a.Planned_StartDate = (dgActivity.Rows[i].Cells["Planned_StartDate"].Value == "" || dgActivity.Rows[i].Cells["Planned_StartDate"].Value == null) ? "" : dgActivity.Rows[i].Cells["Planned_StartDate"].Value.ToString();
                            a.Planned_CompletionDate = (dgActivity.Rows[i].Cells["Planned_CompletionDate"].Value == "" || dgActivity.Rows[i].Cells["Planned_CompletionDate"].Value == null) ? "" : dgActivity.Rows[i].Cells["Planned_CompletionDate"].Value.ToString();
                            a.Actual_StartDate = (dgActivity.Rows[i].Cells["Actual_StartDate"].Value == "" || dgActivity.Rows[i].Cells["Actual_StartDate"].Value == null) ? "" : dgActivity.Rows[i].Cells["Actual_StartDate"].Value.ToString();
                            a.Actual_Completiondate = (dgActivity.Rows[i].Cells["Actual_Completiondate"].Value == "" || dgActivity.Rows[i].Cells["Actual_Completiondate"].Value == null) ? "" : dgActivity.Rows[i].Cells["Actual_Completiondate"].Value.ToString();
                            a.Planned_Duration = (dgActivity.Rows[i].Cells["Planned_Duration"].Value == "" || dgActivity.Rows[i].Cells["Planned_Duration"].Value == null) ? "" : dgActivity.Rows[i].Cells["Planned_Duration"].Value.ToString();
                            a.Actual_Duration = (dgActivity.Rows[i].Cells["Actual_Duration"].Value == "" || dgActivity.Rows[i].Cells["Actual_Duration"].Value == null) ? "" : dgActivity.Rows[i].Cells["Actual_Duration"].Value.ToString();
                            a.Ref_Doc_No = (dgActivity.Rows[i].Cells["Ref_Doc_No"].Value == "" || dgActivity.Rows[i].Cells["Ref_Doc_No"].Value == null) ? "" : dgActivity.Rows[i].Cells["Ref_Doc_No"].Value.ToString();
                            a.Resion = (dgActivity.Rows[i].Cells["Resion"].Value == "" || dgActivity.Rows[i].Cells["Resion"].Value == null) ? "" : dgActivity.Rows[i].Cells["Resion"].Value.ToString();
                            a.Remarks = (dgActivity.Rows[i].Cells["Remarks"].Value == "" || dgActivity.Rows[i].Cells["Remarks"].Value == null) ? "" : dgActivity.Rows[i].Cells["Remarks"].Value.ToString();
                            a.Activity_Part_No = (dgActivity.Rows[i].Cells["Activity_Part_No"].Value == "" || dgActivity.Rows[i].Cells["Activity_Part_No"].Value == null) ? "" : dgActivity.Rows[i].Cells["Activity_Part_No"].Value.ToString();
                            a.Part_Sl_No = (dgActivity.Rows[i].Cells["Part_Sl_No"].Value == "" || dgActivity.Rows[i].Cells["Part_Sl_No"].Value == null) ? "" : dgActivity.Rows[i].Cells["Part_Sl_No"].Value.ToString();
                            a.Status = (dgActivity.Rows[i].Cells["Status"].Value == "" || dgActivity.Rows[i].Cells["Status"].Value == null) ? "" : dgActivity.Rows[i].Cells["Status"].Value.ToString();
                            a.CompID = "0001";
                            a.Modified_By = "";
                            a.Modified_On = DateTime.Now;
                            var ew = db.Sp_autoincrement_Activity_Report_Master("0001").SingleOrDefault();
                            a.Report_No = ew.Report_No;
                            db.Activity_Reports.InsertOnSubmit(a);

                        }
                        db.SubmitChanges();
                        MessageBox.Show("Recored Saved Succesfully");
                        Clear();
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private void cmbWorkCenter_Leave(object sender, EventArgs e)
        {
            try
            {
                if(cmbWorkCenter.Text=="")
                {
                    MessageBox.Show("Please Select Work center Name...");
                    cmbWorkCenter.Focus();
                    return;
                }
                else
                {
                    var sa = (from k in db.Sp_Bind_WorkCenter_Name("0001", cmbWorkCenter.SelectedValue.ToString()) select new { k.Project_Code }).ToList();
                    if (sa.Count > 0)
                    {
                        cmbPartNo.DataSource = sa;
                        cmbPartNo.DisplayMember = "Project_Code";
                        cmbPartNo.ValueMember = "Project_Code";
                        if (cmbPartNo.Items.Count > 0)
                        {
                            cmbPartNo.SelectedIndex = -1;
                        }
                        else
                        {
                            cmbPartNo.SelectedIndex = -1;
                        }
                    }
                }
               
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        private void cmbPartNo_Leave(object sender, EventArgs e)
        {
            try
            {
                if(cmbPartNo.Text=="")
                {
                    SqlCommand cmd2 = new SqlCommand("Sp_Bind_ActivityChart_Dates", con);
                    cmd2.CommandType = CommandType.StoredProcedure;
                    cmd2.Parameters.AddWithValue("@Company", "0001");
                    cmd2.Parameters.AddWithValue("@Date", txtDate.Text.Trim());
                    cmd2.Parameters.AddWithValue("@Workcenter", cmbWorkCenter.SelectedValue.ToString());
                    cmd2.Parameters.AddWithValue("@PartNo", "");//@TODATE
                    cmd2.Parameters.AddWithValue("@TODATE", DateTime.Now);
                    SqlDataAdapter da = new SqlDataAdapter(cmd2);
                    DataSet ds2 = new DataSet();
                    da.Fill(ds2, "x");
                    if (ds2.Tables["x"].Rows.Count > 0)
                    {
                        dgActivity.DataSource = ds2.Tables[0];
                    }
                    else
                    {
                        MessageBox.Show("No Records Found...");
                        cmbPartNo.Focus();
                        // return;
                    }
                    for (int i = 0; i < dgActivity.Rows.Count - 1; i++)
                    {
                        string revison = (dgActivity.Rows[i].Cells["Resion"].Value == "" || dgActivity.Rows[i].Cells["Resion"].Value == null) ? "" : dgActivity.Rows[i].Cells["Resion"].Value.ToString();
                        string planstartdate = (dgActivity.Rows[i].Cells["Planned_StartDate"].Value == "" || dgActivity.Rows[i].Cells["Planned_StartDate"].Value == null) ? "" : dgActivity.Rows[i].Cells["Planned_StartDate"].Value.ToString();
                        string actualstartdates = (dgActivity.Rows[i].Cells["Actual_StartDate"].Value == "" || dgActivity.Rows[i].Cells["Actual_StartDate"].Value == null) ? "" : dgActivity.Rows[i].Cells["Actual_StartDate"].Value.ToString();
                        if (("" == actualstartdates) || (null == actualstartdates) && revison == "")
                        {
                            //dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;                      

                        }
                        else if ((("" == actualstartdates) || (null == actualstartdates) && revison != ""))
                        {
                            dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;
                        }
                        else if (Convert.ToDateTime(planstartdate) < Convert.ToDateTime(actualstartdates) && revison != "")
                        {
                            dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;

                        }
                        else if (Convert.ToDateTime(planstartdate) > Convert.ToDateTime(actualstartdates) && revison != "")
                        {
                            dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;

                        }
                        else if (Convert.ToDateTime(planstartdate) == Convert.ToDateTime(actualstartdates))
                        {

                        }

                    }
                }
                else
                {
                    SqlCommand cmd2 = new SqlCommand("Sp_Bind_ActivityChart_Dates", con);
                    cmd2.CommandType = CommandType.StoredProcedure;
                    cmd2.Parameters.AddWithValue("@Company", "0001");
                    cmd2.Parameters.AddWithValue("@Date", txtDate.Text.Trim());
                    cmd2.Parameters.AddWithValue("@Workcenter", cmbWorkCenter.SelectedValue.ToString());
                    cmd2.Parameters.AddWithValue("@PartNo", cmbPartNo.Text.Trim());//@TODATE
                    cmd2.Parameters.AddWithValue("@TODATE", DateTime.Now);
                    SqlDataAdapter da = new SqlDataAdapter(cmd2);
                    DataSet ds2 = new DataSet();
                    da.Fill(ds2, "x");
                    if (ds2.Tables["x"].Rows.Count > 0)
                    {
                        dgActivity.DataSource = ds2.Tables[0];
                    }
                    else
                    {
                        MessageBox.Show("No Records Found...");
                        cmbPartNo.Focus();
                        // return;
                    }
                    for (int i = 0; i < dgActivity.Rows.Count - 1; i++)
                    {
                        string revison = (dgActivity.Rows[i].Cells["Resion"].Value == "" || dgActivity.Rows[i].Cells["Resion"].Value == null) ? "" : dgActivity.Rows[i].Cells["Resion"].Value.ToString();
                        string planstartdate = (dgActivity.Rows[i].Cells["Planned_StartDate"].Value == "" || dgActivity.Rows[i].Cells["Planned_StartDate"].Value == null) ? "" : dgActivity.Rows[i].Cells["Planned_StartDate"].Value.ToString();
                        string actualstartdates = (dgActivity.Rows[i].Cells["Actual_StartDate"].Value == "" || dgActivity.Rows[i].Cells["Actual_StartDate"].Value == null) ? "" : dgActivity.Rows[i].Cells["Actual_StartDate"].Value.ToString();
                        if (("" == actualstartdates) || (null == actualstartdates) && revison == "")
                        {
                            //dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;                      

                        }
                        else if ((("" == actualstartdates) || (null == actualstartdates) && revison != ""))
                        {
                            dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;
                        }
                        else if (Convert.ToDateTime(planstartdate) < Convert.ToDateTime(actualstartdates) && revison != "")
                        {
                            dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;

                        }
                        else if (Convert.ToDateTime(planstartdate) > Convert.ToDateTime(actualstartdates) && revison != "")
                        {
                            dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;

                        }
                        else if (Convert.ToDateTime(planstartdate) == Convert.ToDateTime(actualstartdates))
                        {

                        }

                    }
                }
              
                //var sa=(from k in db.Sp_Bind_ActivityChart_Dates("0001",txtDate.Text.Trim(),cmbWorkCenter.Text.Trim(),cmbPartNo.Text.Trim()) select k).ToList();
                //if(sa.Count>0)
                //{
                //    dgActivity.DataSource = sa;
                //}
                //else
                //{

                //}
                //var sa = (from k in db.Project_ActivityCharts where k.Work_Center == cmbWorkCenter.Text && k.CompID == "0001" && k.Activity_Part_No == cmbPartNo.Text.Trim() select new { k.Activity_Code, k.Activity_Description, k.Work_Center, k.Person_Rep, k.Planned_StartDate, k.Planned_CompletionDate, k.Planned_Duration, k.Actual_StartDate, k.Actual_Completiondate, k.Actual_Duration }).ToList();
                //if(sa.Count>0)
                //{
                //    dgActivity.DataSource = sa;
                //}
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public void Clear()
        {
            try
            {
                txtDate.Text = "";
                txtReportNo.Text = "";
                cmbPartNo.Text = "";
                cmbWorkCenter.Text = "";
                if (dgActivity.Rows.Count > 0)
                {
                    for (int i = 0; i < dgActivity.Rows.Count - 1; i++)
                    {
                        dgActivity.Rows.RemoveAt(i);
                        i--;
                        while (dgActivity.Rows.Count == 0)
                            continue;
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
           
        }
        private void btnReset_Click(object sender, EventArgs e)
        {
            Clear();
        }
        public string mainhh, mainmm;
        public int hours, TotalMM;
        public DateTime dt, dt1;

        private void button2_Click(object sender, EventArgs e)
        {
            Masters.ReportSearch obj = new Masters.ReportSearch();
            if (obj.ShowDialog() == DialogResult.OK)
            {
                txtReportNo.Text=Masters.ReportSearch.reportno;
                var sa = (from k in db.Activity_Reports where k.CompID == "0001" && k.Report_No == txtReportNo.Text.Trim() select new { k.Report_No, k.Date, k.Main_Work_Center, k.PartList_No }).ToList();
                if(sa.Count>0)
                {
                    txtReportNo.Text = sa[0].Report_No;
                    txtDate.Text = sa[0].Date;
                    cmbPartNo.Text = sa[0].PartList_No;
                    cmbWorkCenter.Text = sa[0].Main_Work_Center;
                }
                else
                {

                }
               // DataGridViewRow R = dgActivity.Rows[dgActivity.CurrentRow.Index];
                var sa1 = (from k in db.Activity_Reports where k.CompID == "0001" && k.Report_No == txtReportNo.Text.Trim() select new { k.Activity_Code, k.Activity_Description, k.Work_Center, k.Person_Rep,k.Planned_StartDate,k.Planned_CompletionDate,k.Planned_Duration,k.Actual_StartDate,k.Actual_Completiondate,k.Actual_Duration,k.Activity_Part_No,k.Ref_Doc_No,k.Resion,k.Remarks,k.Part_Sl_No,k.Status });
                SqlCommand cmd2 = (SqlCommand)db.GetCommand(sa1);
                SqlDataAdapter da2 = new SqlDataAdapter(cmd2);
                DataTable dtr = new DataTable();
                da2.Fill(dtr);
                if (dtr.Rows.Count >= 0)
                    dgActivity.DataSource = dtr;
                for (int i = 0; i < dgActivity.Rows.Count - 1; i++)
                {
                    string STATUS = (dgActivity.Rows[i].Cells["Status"].Value == "" || dgActivity.Rows[i].Cells["Status"].Value == null) ? "" : dgActivity.Rows[i].Cells["Status"].Value.ToString();
                    string revison = (dgActivity.Rows[i].Cells["Resion"].Value == "" || dgActivity.Rows[i].Cells["Resion"].Value == null) ? "" : dgActivity.Rows[i].Cells["Resion"].Value.ToString();
                    string planstartdate = (dgActivity.Rows[i].Cells["Planned_StartDate"].Value == "" || dgActivity.Rows[i].Cells["Planned_StartDate"].Value == null) ? "" : dgActivity.Rows[i].Cells["Planned_StartDate"].Value.ToString();
                    string actualstartdates = (dgActivity.Rows[i].Cells["Actual_StartDate"].Value == "" || dgActivity.Rows[i].Cells["Actual_StartDate"].Value == null) ? "" : dgActivity.Rows[i].Cells["Actual_StartDate"].Value.ToString();
                    if (("Open" == STATUS))
                    {
               
                    }
                    if (("InProcess" == STATUS))
                    {
                        dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;
                    }
                    if (("Closed" == STATUS))
                    {
                        dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Yellow;
                    }
                    //if (("" == actualstartdates) || (null == actualstartdates) && revison == "")
                    //{
                    //    dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;                    

                    //}
                    //else if (Convert.ToDateTime(planstartdate) < Convert.ToDateTime(actualstartdates) && revison != "")
                    //{
                    //    dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;                  
                    //}
                    //else if (Convert.ToDateTime(planstartdate) > Convert.ToDateTime(actualstartdates) && revison != "")
                    //{
                    //    dgActivity.Rows[i].DefaultCellStyle.BackColor = Color.Orange;                      
                    //}
                    //else if (Convert.ToDateTime(planstartdate) == Convert.ToDateTime(actualstartdates))
                    //{

                    //}

                }

            }

            }

        private void dgActivity_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        public string Tthrs;
        private void dgActivity_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataGridViewRow R = dgActivity.Rows[dgActivity.CurrentRow.Index];
                int columnIndex = dgActivity.CurrentCell.ColumnIndex;
                string columnName = dgActivity.Columns[columnIndex].HeaderText;
                if ("Actual Start Date" == columnName)
                {

                    if (R.Cells["Actual_StartDate"].Value == "" || R.Cells["Actual_StartDate"].Value == null)
                    {
                        MessageBox.Show("Please  Enter Actual Start Date..");

                        return;

                    }
                    else
                    {
                        string Acttartdate = R.Cells["Actual_StartDate"].Value.ToString();
                        string Plstartdate = R.Cells["Actual_StartDate"].Value.ToString();
                        string workcen = R.Cells["Work_Center"].Value.ToString();
                        string prtnn = R.Cells["Activity_Part_No"].Value.ToString();
                        string planingstart= R.Cells["Planned_StartDate"].Value.ToString();
                        string Acttenddate = R.Cells["Actual_Completiondate"].Value.ToString();
                        //var sa = (db.Sp_Bind_ActivityChart_ActualComapre_Dates("0001", Acttartdate,workcen,prtnn, Acttartdate));
                        //if (sa.Count() > 0)
                        //{
                        dt = Convert.ToDateTime(R.Cells["Actual_StartDate"].Value);
                            String formated = dt.ToString("yyyy/MM/dd HH:mm");
                            R.Cells["Actual_StartDate"].Value = formated;
                            String fromdate = formated.Substring(0, 4);
                            String hh = formated.Substring(11, 2);
                            String mm = formated.Substring(14, 2);
                            string hhmm = hh + mm;
                            hours = 2400 - Convert.ToInt32(hhmm);
                            string hrs = hours.ToString();
                            mainhh = hrs.Substring(0, 2);
                            mainmm = hrs.Substring(2, 2);
                      if(""!=Acttartdate && ""==Acttenddate)
                        {
                            R.Cells["Status"].Value = "InProcess";
                        }
                       else if ("" != Acttartdate && "" != Acttenddate)
                        {
                            R.Cells["Status"].Value = "Closed";
                        }
                       else if("" == Acttartdate && "" == Acttenddate)
                        {
                            R.Cells["Status"].Value = "Open";
                        }
                        //dgActivity.CurrentCell = dgActivity.Rows[dgActivity.CurrentRow.Index].Cells["Planned_StartDate"];
                        //dgActivity.CurrentCell.Selected = true;
                        //dgActivity.BeginEdit(true);
                        return;
                            //dgActivity.Rows[dgActivity.CurrentRow.Index].Cells["Planned_StartDate"].Selected = true;
                            //return;
                        //}
                        //else
                        //{
                        //    MessageBox.Show("This Actual Date Is Greter Or Less than the Planeed Date...");
                        //    R.Cells["Actual_StartDate"].Value = "";
                        //    ///.Columns[4].DefaultCellStyle.Format = "MM/dd/yyyy HH:mm:ss";

                        //    //  String makname = value.Substring(8, maknamelen);
                        //    // String[] am = formated;
                        //    //DateTime planstartdate = Convert.ToDateTime(R.Cells["Planned_StartDate"].Value);
                        //    //string f1 = planstartdate.ToString("yyyyMMddHHmmss");
                        //    //string sss = f1;
                        //}

                    }

                }
                if ("Actual Completion Date" == columnName)
                {

                    if (R.Cells["Actual_CompletionDate"].Value == "" || R.Cells["Actual_CompletionDate"].Value == null)
                    {
                        MessageBox.Show("Please  Enter Actual Completion Date..");

                        return;

                    }
                    else
                    {
                        //string Plcomptdate = R.Cells["Actual_CompletionDate"].Value.ToString();
                        //var sa = (db.Sp_Bind_Dates("0001", R.Cells["Actual_CompletionDate"].Value.ToString(), R.Cells["Work_Center"].Value.ToString()));
                        //if (sa.Count() > 0)
                        //{
                        //    MessageBox.Show("This Actual Date Already Assign...");
                        //    R.Cells["Actual_CompletionDate"].Value = "";


                        //    return;
                        //}
                        //else
                        //{
                        string Acttartdate = R.Cells["Actual_StartDate"].Value.ToString();
                        string Acttenddate = R.Cells["Actual_Completiondate"].Value.ToString();
                        dt1 = Convert.ToDateTime(R.Cells["Actual_CompletionDate"].Value);
                        string planningstart = dt.ToString();
                        string planningenddate = dt1.ToString();
                        if (dt1 >= dt)
                        {
                            string TotalHours = dt1.Subtract(dt).TotalHours.ToString();
                            String planninstratMM = planningstart.Substring(14, 2);
                            String plannineng = planningenddate.Substring(14, 2);
                            char[] splitchar = { '.' };
                            string[] strArr = TotalHours.Split(splitchar);
                            if (1 == strArr.Length)
                            {
                                Tthrs = TotalHours;

                            }
                            else
                            {
                                for (int count = 0; count <= strArr.Length - 2; count++)
                                {
                                    Tthrs = strArr[count];
                                }
                            }
                            if ((Convert.ToInt32(plannineng) >= Convert.ToInt32(planninstratMM)))
                            {
                                TotalMM = Convert.ToInt32(plannineng) - Convert.ToInt32(planninstratMM);
                            }
                            else
                            {
                                TotalMM = 60 - Convert.ToInt32(planninstratMM) + Convert.ToInt32(plannineng);

                            }
                            string Mints = Convert.ToString(TotalMM);
                            string mins = dt1.Subtract(dt).TotalMinutes.ToString();
                            string days = dt1.Subtract(dt).TotalDays.ToString();

                            string TotalMins = dt1.Subtract(dt).TotalMinutes.ToString();
                            if ("0." == TotalHours)
                            {
                                R.Cells["Actual_Duration"].Value = 0 + ":" + TotalMM;
                            }
                            else
                            {
                                R.Cells["Actual_Duration"].Value = Tthrs + ":" + TotalMM;
                            }
                        }
                        if ("" != Acttartdate && "" == Acttenddate)
                        {
                            R.Cells["Status"].Value = "InProcess";
                        }
                        else if ("" != Acttartdate && "" != Acttenddate)
                        {
                            R.Cells["Status"].Value = "Closed";
                        }
                        else if ("" == Acttartdate && "" == Acttenddate)
                        {
                            R.Cells["Status"].Value = "Open";
                        }
                        //}

                    }
                }
                }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
