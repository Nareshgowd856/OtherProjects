﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Thermal_ERP.Masters
{
    public partial class GroupMaster : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        public static string Gradeid;
        public GroupMaster()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtGroupName.Text == "" || txtGroupName.Text == null)
                {
                    MessageBox.Show("Please Enter GroupName");
                    txtGroupName.Focus();
                    return;
                }
                else
                {
                    if ((from k in db.Group_Masters where k.CompID == "0001" && k.Group_Id == txtGroupid.Text select k).Count() > 0)
                    {
                        db.Sp_Delete_Group_Master("0001", txtGroupid.Text);
                        Group_Master gm = new Group_Master();
                        gm.Group_Name = (txtGroupName.Text == "") ? "" : txtGroupName.Text;
                        gm.Group_Id = txtGroupid.Text;
                        gm.CompID = "0001";
                        gm.Created = "";
                        gm.Created_By = DateTime.Now;
                        gm.Modified = "";
                        gm.Modified_By = DateTime.Now;
                        db.Group_Masters.InsertOnSubmit(gm);
                        db.SubmitChanges();
                        MessageBox.Show("Recored Updated Succesfully");
                        BindGrid();
                        Clear();
                    }
                    else
                    {
                        Group_Master gm = new Group_Master();
                        gm.Group_Name = (txtGroupName.Text == "") ? "" : txtGroupName.Text;
                        var sa = (db.Sp_autoincrement_Group_Master("0001")).ToList();
                        gm.Group_Id = sa.FirstOrDefault().Group_Id;
                        gm.CompID = "0001";
                        gm.Created = "";
                        gm.Created_By = DateTime.Now;
                        gm.Modified = "";
                        gm.Modified_By = DateTime.Now;
                        db.Group_Masters.InsertOnSubmit(gm);
                        db.SubmitChanges();
                        MessageBox.Show("Recored Saved Succesfully");
                        BindGrid();
                        Clear();
                    }

                }
            }
            catch (Exception ex)
            {

                throw;
            }
            
        }
        public void Clear()
        {
            try
            {
                txtGroupid.Text = "";
                txtGroupName.Text = "";
                //foreach (Control d in tableLayoutPanel1.Controls)
                //{
                //    if (d is TextBox)
                //        (d as TextBox).Clear();
                //}
            }
            catch (Exception ex)
            {

                throw;
            }
           
        }
        public void BindGrid()
        {
            try
            {
                var sa = ((from k in db.Group_Masters where k.CompID == "0001" select new { k.Group_Id,k.Group_Name})).ToList();
                if (sa.Count > 0)
                {
                    dgGrademaster.DataSource = sa;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            
        }
        private void btnReset_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void GroupMaster_Load(object sender, EventArgs e)
        {
            try
            {
                BindGrid();
            }
            catch (Exception ex)
            {

                throw;
            }
           
        }

        private void dgGrademaster_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex >= 0)
                {
                    Gradeid = (dgGrademaster.Rows[e.RowIndex].Cells["Group_Id"].Value.ToString());
                    var sa = (from k in db.Group_Masters where k.CompID == "0001" && k.Group_Id == Gradeid select k).ToList();
                    if (sa.Count > 0)
                    {
                        txtGroupid.Text = sa[0].Group_Id;
                        txtGroupName.Text = sa[0].Group_Name;
                    }
                    else
                    {

                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void txtGroupid_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtGroupName_TextChanged(object sender, EventArgs e)
        {

        }

        private void tableLayoutPanel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void tableLayoutPanel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void dgGrademaster_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }
    }
}
