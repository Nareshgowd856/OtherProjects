﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Thermal_ERP.Masters
{
    public partial class UomMaster : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        public static string uomid;
        public UomMaster()
        {
            InitializeComponent();
        }

        private void dguommaster_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if(e.RowIndex>=0)
                {
                    uomid = (dguommaster.Rows[e.RowIndex].Cells["UOM_Id"].Value.ToString());
                    var sa = (from k in db.UOM_Masters where k.CompId == "0001" && k.UOM_Id == uomid select k).ToList();
                    if(sa.Count>0)
                    {
                        txtUOMid.Text = sa[0].UOM_Id;
                        txtUOMName.Text = sa[0].UOM_Name;
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public void BindGrid()
        {
            try
            {
                var sa = (from k in db.UOM_Masters where k.CompId == "0001" select new { k.UOM_Id,k.UOM_Name}).ToList();
                if (sa.Count > 0)
                {
                    dguommaster.DataSource = sa;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
            
        }
        public void Clear()
        {
            try
            {
                //foreach(Control d in tableLayoutPanel1.Controls)
                //{
                //    if (d is TextBox)
                //        (d as TextBox).Clear();
                //}
                txtUOMid.Text = "";
                txtUOMName.Text = "";
            }
            catch (Exception ex)
            {

                throw;
            }
            
        }
        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtUOMName.Text == "" || txtUOMName.Text == null)
                {
                    MessageBox.Show("Please Enter UOM Name");
                    txtUOMName.Focus();
                    return;
                }
                else
                {
                    if ((from k in db.UOM_Masters where k.CompId == "0001" && k.UOM_Id == txtUOMid.Text select k).Count() > 0)
                    {
                        db.Sp_Delete_UOM_Master("0001", txtUOMid.Text);
                        UOM_Master u = new UOM_Master();
                        u.UOM_Name = txtUOMName.Text;
                        u.CompId = "0001";
                        u.UOM_Id = txtUOMid.Text;
                        u.Created = "";
                        u.Created_By = DateTime.Now;
                        u.Modified = "";
                        u.Modified_By = DateTime.Now;
                        db.UOM_Masters.InsertOnSubmit(u);
                        db.SubmitChanges();
                        MessageBox.Show("Recored Updated Succesfully");
                        BindGrid();
                        Clear();
                    }
                    else
                    {
                        UOM_Master u = new UOM_Master();
                        u.UOM_Name = txtUOMName.Text;
                        u.CompId = "0001";
                        var sa = (db.Sp_autoincrement_UOM_Master("0001")).ToList();
                        u.UOM_Id = sa.FirstOrDefault().UOM_Id;
                        u.Created = "";
                        u.Created_By = DateTime.Now;
                        u.Modified = "";
                        u.Modified_By = DateTime.Now;
                        db.UOM_Masters.InsertOnSubmit(u);
                        db.SubmitChanges();
                        MessageBox.Show("Recored Saved Succesfully");
                        BindGrid();
                        Clear();
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void UomMaster_Load(object sender, EventArgs e)
        {
            try
            {
                BindGrid();
            }
            catch (Exception ex)
            {
                throw;
            }           
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
           
        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
