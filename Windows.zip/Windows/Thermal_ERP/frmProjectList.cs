﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Thermal_ERP
{
    public partial class frmProjectList : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        public static string projectcode, Name;
        public frmProjectList()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmCreateProject frm = new frmCreateProject();
            frm.MdiParent = this.MdiParent;
            frm.Show();
        }

        private void frmProjectList_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'thermal_PMSDataSet.Project_Master' table. You can move, or remove it, as needed.
            //   this.project_MasterTableAdapter.Fill(this.thermal_PMSDataSet.Project_Master);
            try
            {
                var sa = (from k in db.Project_Masters where k.CompID == "0001" select new { k.Project_Code, k.Project_Name, k.Project_Client, k.Project_DeliveryDate, k.CompID }).ToList();
                if (sa.Count > 0)
                {
                    dataGridView1.DataSource = sa;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if(e.RowIndex>=0)
                {
                    projectcode = dataGridView1.Rows[e.RowIndex].Cells["Project_Code"].Value.ToString();
                    frmCreateProject obj = new frmCreateProject();
                    Name = "FrmProjects";

                    if (obj.ShowDialog() == DialogResult.Cancel)
                    {
                        var sa = (from k in db.Project_Masters where k.CompID == "0001" select new { k.Project_Code, k.Project_Name, k.Project_Client, k.Project_DeliveryDate, k.CompID }).ToList();
                        if (sa.Count > 0)
                        {
                            dataGridView1.DataSource = sa;
                        }
                    }
                }
               
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
