﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Thermal_ERP
{
    public partial class Thermal_ERP_GateWay : Form
    {
        private int childFormNumber = 0;

        public Thermal_ERP_GateWay()
        {
            InitializeComponent();
        }

        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Window " + childFormNumber++;
            childForm.Show();
        }

        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmAPGMaster frm = new frmAPGMaster();
            frm.MdiParent = this;
            frm.Show();
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmActivityMaster frm = new frmActivityMaster();
            frm.MdiParent = this;
            frm.Show();
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void StatusBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPartList frm = new frmPartList();
            frm.MdiParent = this;
            frm.Show();
        }

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmProjectList frm = new frmProjectList();
            frm.MdiParent = this;
            frm.Show();
        }

        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMakers frm = new frmMakers();
            frm.MdiParent = this;
            frm.Show();

        }

        private void toolBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
          //  ProjectStructure frm = new ProjectStructure();
            ProjectStructureCreation frm = new ProjectStructureCreation();
            frm.MdiParent = this;
            frm.Show();
        }

        private void Thermal_ERP_GateWay_Load(object sender, EventArgs e)
        {

        }

        private void itemMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmPartMaster frm = new frmPartMaster();
            frm.MdiParent = this;
            frm.Show();
        }

        private void materialGradesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmMaterialGrades frm = new frmMaterialGrades();
            frm.MdiParent = this;
            frm.Show();
        }

        private void newCustomersToolStripMenuItem_Click(object sender, EventArgs e)
        {
           Masters.CustomerInfo frm = new Masters.CustomerInfo();
            frm.MdiParent = this;
            frm.Show();
        }

        private void newSubAssemblyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Masters.SubAssembly frm = new Masters.SubAssembly();
            frm.MdiParent = this;
            frm.Show();
        }

        private void newVariantToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Masters.Variant frm = new Masters.Variant();
            frm.MdiParent = this;
            frm.Show();
        }

        private void newPartListToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Masters.PTMaster frm = new Masters.PTMaster();
            frm.MdiParent = this;
            frm.Show();
        }

        private void workCenterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            WorkCenterMaster frm = new WorkCenterMaster();
            frm.MdiParent = this;
            frm.Show();
        }

        private void resourceMasterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Masters.ResourceMaster frm = new Masters.ResourceMaster();
            frm.MdiParent = this;
            frm.Show();
        }

        private void activityReportToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Masters.ReportForm frm = new Masters.ReportForm();
            frm.MdiParent = this;
            frm.Show();
        }

        private void activityReportToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Reports.Activity frm = new Reports.Activity();
            frm.MdiParent = this;
            frm.Show();
        }

        private void testToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void activityPlanToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmITD frm = new frmITD();
            frm.MdiParent = this;
            frm.Show();
        }
    }
}
