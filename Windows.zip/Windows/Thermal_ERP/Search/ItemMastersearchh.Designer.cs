﻿namespace Thermal_ERP.Search
{
    partial class ItemMastersearchh
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.Item_Spec = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Item_Group = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Item_Type = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Item_Spec,
            this.Item_Group,
            this.Item_Type});
            this.dataGridView1.Location = new System.Drawing.Point(12, 62);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(516, 250);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellDoubleClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semibold", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(318, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(210, 25);
            this.label1.TabIndex = 1;
            this.label1.Text = "ITEM MASTER SEARCH";
            // 
            // Item_Spec
            // 
            this.Item_Spec.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Item_Spec.DataPropertyName = "Item_Spec";
            this.Item_Spec.HeaderText = "Item Spec";
            this.Item_Spec.Name = "Item_Spec";
            this.Item_Spec.Width = 200;
            // 
            // Item_Group
            // 
            this.Item_Group.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.None;
            this.Item_Group.DataPropertyName = "Item_Group";
            this.Item_Group.HeaderText = "ItemGroup";
            this.Item_Group.Name = "Item_Group";
            this.Item_Group.Width = 150;
            // 
            // Item_Type
            // 
            this.Item_Type.DataPropertyName = "Item_Type";
            this.Item_Type.HeaderText = "ItemType";
            this.Item_Type.Name = "Item_Type";
            // 
            // MaterialGradesearchh
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(540, 334);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "MaterialGradesearchh";
            this.Text = "ItemMastersearchh";
            this.Load += new System.EventHandler(this.MaterialGradesearchh_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Item_Spec;
        private System.Windows.Forms.DataGridViewTextBoxColumn Item_Group;
        private System.Windows.Forms.DataGridViewTextBoxColumn Item_Type;
    }
}