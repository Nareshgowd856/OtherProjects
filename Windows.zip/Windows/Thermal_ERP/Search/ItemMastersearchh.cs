﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Thermal_ERP.Search
{
    public partial class ItemMastersearchh : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        public static string Specno;
        public ItemMastersearchh()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
if(e.RowIndex>=0)
                {
                    Specno = dataGridView1.Rows[e.RowIndex].Cells["Item_Spec"].Value.ToString();
                    this.Close();
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void MaterialGradesearchh_Load(object sender, EventArgs e)
        {
            try
            {
                var sa = (db.Sp_Bind_Items("0001")).ToList();
                if(sa.Count>0)
                {
                    dataGridView1.DataSource = sa;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
