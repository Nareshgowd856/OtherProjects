﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Thermal_ERP
{
    public partial class frmMakers : Form
    {
        LinqtosqlDataContext db = new LinqtosqlDataContext();
        public static string mackno;
        public frmMakers()
        {
            InitializeComponent();
        }
        public void BindGrid()
        {
            var sa = (from k in db.Maker_Masters where k.CompID == "0001" select new { k.Maker_No, k.Maker_Description }).ToList();
            if(sa.Count>0)
            {
                dataGridView1.DataSource = sa;
            }
        }
        public void Clear()
        {
            txtdesc.Text = "";
            txtmacid.Text = "";
        }
        private void frmMakers_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'thermal_PMSDataSet.Maker_Master' table. You can move, or remove it, as needed.
            //  this.maker_MasterTableAdapter.Fill(this.thermal_PMSDataSet.Maker_Master);
            BindGrid();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //maker_MasterTableAdapter.DeleteMaker(txtmacid.Text);
            //maker_MasterTableAdapter.InsertMaker(txtmacid.Text, txtdesc.Text, "0001");
            //dataGridView1.Refresh();
            try
            {
                if(txtmacid.Text==""||txtmacid.Text==null)
                {
                    MessageBox.Show("Please Enter Maker No");
                    txtmacid.Focus();
                    return;
                }
                else
                {
                    if ((from k in db.Maker_Masters where k.Maker_No == txtmacid.Text && k.CompID == "0001" select k).Count() > 0)
                    {
                        db.Sp_Delete_Maker_Master("0001", txtmacid.Text);
                        Maker_Master m = new Maker_Master();
                        m.Maker_No = txtmacid.Text;
                        m.Maker_Description = (txtdesc.Text == "") ? "" : txtdesc.Text;
                        m.CompID = "0001";
                        db.Maker_Masters.InsertOnSubmit(m);
                        db.SubmitChanges();
                        MessageBox.Show("Recoerd Updated Successfully");
                        Clear();
                        BindGrid();                        
                        return;

                    }
                    else
                    {
                        Maker_Master m = new Maker_Master();
                        m.Maker_No = txtmacid.Text;
                        m.Maker_Description = (txtdesc.Text == "") ? "" : txtdesc.Text;
                        m.CompID = "0001";
                        db.Maker_Masters.InsertOnSubmit(m);
                        db.SubmitChanges();
                        MessageBox.Show("Recoerd Saved Successfully");
                        Clear();
                        BindGrid();
                        return;
                    }
                }
            
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView2_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            try
            {
                try
                {
                    if (dataGridView2.Rows.Count > 0)
                    {

                        int columnIndex = dataGridView2.CurrentCell.ColumnIndex;
                        string columnName = dataGridView2.Columns[columnIndex].HeaderText;

                        if (e.Control is ComboBox)
                        {
                            ComboBox box = e.Control as ComboBox;
                            box.DropDownStyle = ComboBoxStyle.DropDown;
                            box.AutoCompleteSource = AutoCompleteSource.ListItems;
                            box.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                        }

                        TextBox tb = e.Control as TextBox; ///Product Group
                        if ((tb != null && columnName == "Sub Assembly Name") )//|| (tb != null && columnName == "Product/Acc Group"))
                        {
                            tb.AutoCompleteMode = AutoCompleteMode.Suggest;
                            tb.AutoCompleteSource = AutoCompleteSource.CustomSource;
                            AutoCompleteStringCollection DataColl = new AutoCompleteStringCollection();
                            addItems(DataColl);
                            tb.AutoCompleteCustomSource = DataColl;
                        }
                      else  if ((tb != null && columnName == "Variant"))//|| (tb != null && columnName == "Product/Acc Group"))
                        {
                            tb.AutoCompleteMode = AutoCompleteMode.Suggest;
                            tb.AutoCompleteSource = AutoCompleteSource.CustomSource;
                            AutoCompleteStringCollection DataColl = new AutoCompleteStringCollection();
                            addItems(DataColl);
                            tb.AutoCompleteCustomSource = DataColl;
                        }
                        else
                        {
                            tb.AutoCompleteMode = AutoCompleteMode.None;
                        }

                        //e.Control.KeyPress -= new KeyPressEventHandler(Column4_KeyPress);
                        //TextBox tb1 = e.Control as TextBox;
                        //if (tb1 != null && columnName == "Qty")
                        //{
                        //    tb1.KeyPress += new KeyPressEventHandler(Column4_KeyPress);
                        //}
                        //if (tb1 != null && columnName == "Price")
                        //{
                        //    tb1.KeyPress += new KeyPressEventHandler(Column4_KeyPress);
                        //}
                    }

                }
                catch (Exception ex)
                {
                }

            }
            catch (Exception ex)
            {

                throw;
            }
        }
        public void addItems(AutoCompleteStringCollection coll)
        {
            try
            {
                int columnIndex = dataGridView2.CurrentCell.ColumnIndex;
                string columnName = dataGridView2.Columns[columnIndex].HeaderText;

                DataGridViewRow R1 = dataGridView2.Rows[dataGridView2.CurrentRow.Index];
                if (columnName == "Sub Assembly Name")
                {

                    var d = (from c in db.SubAssembly_Masters where c.CompID == "0001" select new { c.Sub_Assembly_Name }).ToList();

                    DataTable dt = new DataTable();
                    dt.Columns.Add("d");
                    foreach (var item in d)
                    {
                        dt.Rows.Add(item.Sub_Assembly_Name);
                    }
                    for (int i = 0; i < dt.Rows.Count; i++)
                    {
                        coll.Add(dt.Rows[i][0].ToString());
                    }

                }
                if (columnName == "Variant")
                {
                    if (R1.Cells["Sub_Assembly_Name"].Value != null && R1.Cells["Sub_Assembly_Name"].Value != DBNull.Value)
                    {
                        var d = (from c in db.Variant_Masters where c.CompID == "0001" && c.Sub_Assembly_Name == R1.Cells["Sub_Assembly_Name"].Value.ToString().Trim() select new { c.Variant_Name }).ToList();

                        DataTable dt = new DataTable();
                        dt.Columns.Add("d");
                        foreach (var item in d)

                        {
                            dt.Rows.Add(item.Variant_Name);
                        }
                        for (int i = 0; i < dt.Rows.Count; i++)
                        {
                            coll.Add(dt.Rows[i][0].ToString());
                        }


                    }
                }
            }
            catch (Exception ex)
            {
            }
        }

        private void dataGridView2_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            try
            {



                DataGridViewRow R = dataGridView2.Rows[dataGridView2.CurrentRow.Index];
                int columnIndex = dataGridView2.CurrentCell.ColumnIndex;
                string columnName = dataGridView2.Columns[columnIndex].Name;
                if (columnName == "Sub_Assembly_Name")
                {

                    if ((from u in db.SubAssembly_Masters where u.Sub_Assembly_Name == Convert.ToString(R.Cells["Sub_Assembly_Name"].Value) && u.CompID == "0001" select u).Count() == 0)
                    {
                        MessageBox.Show("Please Select Valid  Sub Assembly Name");
                        R.Cells["Sub_Assembly_Name"].Value = "";
                        return;
                    }
                    else
                    {
                        
                    }
                }
                if (columnName == "Variant_Name")
                {
                    //var sas=(from u in db.Variant_Masters where u.Sub_Assembly_Name == R.Cells["Sub_Assembly_Name"].Value.ToString() && u.CompID=="0001" anselect new { })
                    if ((from u in db.Variant_Masters where u.Sub_Assembly_Name == Convert.ToString(R.Cells["Sub_Assembly_Name"].Value) && u.CompID == "0001"
                         && u.Variant_Name == Convert.ToString(R.Cells["Variant_Name"].Value)select u).Count() > 0)
                    {
                        //MessageBox.Show("Please Select Valid  Variant Name");
                        //R.Cells["Variant_Name"].Value = "";
                        //return;
                    }
                    else
                    {
                        MessageBox.Show("Please Select Valid  Variant Name");
                        R.Cells["Variant_Name"].Value = "";
                        
                        return;
                    }
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if(e.RowIndex>=0)
                {
                    mackno = dataGridView1.Rows[e.RowIndex].Cells["Maker_No"].Value.ToString();
                    var sa = (from k in db.Maker_Masters where k.Maker_No == mackno && k.CompID == "0001" select new { k.Maker_No, k.Maker_Description }).ToList();
                    if(sa.Count>0)
                    {
                        txtmacid.Text = sa[0].Maker_No;
                        txtdesc.Text = sa[0].Maker_Description;
                    }

                }
               
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                var result = MessageBox.Show("Are You Sure Want to Delete this Record ", this.Text, MessageBoxButtons.YesNo, MessageBoxIcon.Information);
                if (result == DialogResult.Yes)
                {
                    db.Sp_Delete_Maker_Master("0001", txtmacid.Text);
                    MessageBox.Show("Recored Deleted Successfully");
                    BindGrid();
                    return;
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }
    }
}
