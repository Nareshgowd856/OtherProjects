﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
   
        public class CreationProjectController : Controller
        {
            private Thermal_PMSEntities db = new Thermal_PMSEntities();
            // GET: CreationProject
            public ActionResult Index()
            {
                return View();
            }
            public ActionResult GetEmployees()
            {
                var employees = db.Project_Master.OrderBy(a => a.id).ToList();
                return Json(new { data = employees }, JsonRequestBehavior.AllowGet);
            }
       
              [HttpGet]
            public ActionResult Save(int id)
            {

                var v = db.Project_Master.Where(a => a.id == id).FirstOrDefault();
                return View(v);

            }
            [HttpGet]
            public ActionResult Edit(int id)
            {
                var v = db.Project_Master.Where(a => a.id == id).FirstOrDefault();
                return View(v);
            }

            public ActionResult Create()
            {
                return View("Partial_Create");
            }


            [HttpPost]
            public ActionResult Save(Project_Master emp)
            {
                bool status = false;
                if (ModelState.IsValid)
                {

                    if (emp.id > 0)
                    {
                        //Edit 
                        var v = db.Project_Master.Where(a => a.id == emp.id).FirstOrDefault();
                        if (v != null)
                        {
                            v.Project_Code = emp.Project_Code;
                            v.Project_Name = emp.Project_Name;
                            v.Project_Client = emp.Project_Client;
                            v.Project_DeliveryDate = emp.Project_DeliveryDate;
                            v.CompID = emp.CompID;
                    }
                    }
                    else
                    {
                        //Save
                        db.Project_Master.Add(emp);
                    }
                    db.SaveChanges();
                    status = true;

                }
                return RedirectToAction("Index", "CreationProject");
            }
            [HttpGet]
            public ActionResult Delete(int id)
            {

                var v = db.Project_Master.Where(a => a.id == id).FirstOrDefault();
                if (v != null)
                {
                    return View(v);
                }
                else
                {
                    return HttpNotFound();
                }

            }
        [HttpGet]
        public ActionResult Partial_Create()
        {
            return PartialView();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Partial_Create([Bind(Include = "id,Project_Code,Project_equip_Name,CompID,Project_Name,Project_Client,Project_DeliveryDate,Project_Description" )] Project_Master Project_Master)
        {
            if (ModelState.IsValid)
            {
                db.Project_Master.Add(Project_Master);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id = new SelectList(db.Project_Master, "Id", "Project_Code", Project_Master);
            return PartialView(Project_Master);
        }
        [HttpPost]
            [ActionName("Delete")]
            public ActionResult DeleteEmployee(int id)
            {
                bool status = false;

                var v = db.Project_Master.Where(a => a.id == id).FirstOrDefault();
                if (v != null)
                {
                    db.Project_Master.Remove(v);
                    db.SaveChanges();
                    status = true;
                }

                return RedirectToAction("Index");
            }
                }
            }