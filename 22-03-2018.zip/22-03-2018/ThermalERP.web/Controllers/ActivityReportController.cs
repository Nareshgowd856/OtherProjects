﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
   
    public class ActivityReportController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();
        // GET: Demo
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetEmployees()
        {
           
                var employees = db.Activity_Report.OrderBy(a => a.Activity_Code).ToList();
                return Json(new { data = employees }, JsonRequestBehavior.AllowGet);
          
        }
        [HttpGet]
        public ActionResult Save(int id)
        {
            
                var v = db.Activity_Report.Where(a => a.id == id).FirstOrDefault();
                return View(v);
            
        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var v = db.Activity_Report.Where(a => a.id == id).FirstOrDefault();
            return View(v);
        }

        public ActionResult Edit(Activity_Report activity_Report)
        {

            if (ModelState.IsValid)
            {
                db.Entry(activity_Report).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(activity_Report);
        }

        public ActionResult Create()
        {
            return View("Partial_Create");
        }

        [HttpPost]
        public ActionResult Save(Activity_Report emp)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
              
                    if (emp.id > 0)
                    {
                        //Edit 
                        var v = db.Activity_Report.Where(a => a.id == emp.id).FirstOrDefault();
                        if (v != null)
                        {
                            v.Activity_Code = emp.Activity_Code;
                            v.Activity_Description = emp.Activity_Description;

                        }
                    }
                    else
                    {
                        //Save
                        db.Activity_Report.Add(emp);
                    }
                    db.SaveChanges();
                    status = true;
                
            }
            return RedirectToAction("Index" , "ActivityReport");
        }
        public ActionResult Partial_Create()
        {
            return PartialView();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Partial_Create([Bind(Include = "Id,Report_No,Date, Main_Work_Center,PartList_No,Project_Code,Activity_Code,Activity_Description,Work_Center,Person_Rep,Planned-StartDate,Planned_CompletionDate,Actual_StartDate,Actual_CompletionDate,Planned_Duration,Actual_Duration,CompID,Created_By,Created_On,Modified_By,Modified_On,Resion,Remarks,Part_SI_No,Activity_Part_No,Status,Ref_Doc_No")] Activity_Report activity_Report)
        {
            if (ModelState.IsValid)
            {
                db.Activity_Report.Add(activity_Report);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id = new SelectList(db.APG_Master, "Id", "APG NO", activity_Report.Activity_Code);
            return PartialView(activity_Report);
        }


        [HttpGet]
        public ActionResult Delete(int id)
        {
           
                var v = db.Activity_Report.Where(a => a.id == id).FirstOrDefault();
                if (v != null)
                {
                    return View(v);
                }
                else
                {
                    return HttpNotFound();
                }
            
        }
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteEmployee(int id)
        {
            bool status = false;
           
                var v = db.Activity_Report.Where(a => a.id == id).FirstOrDefault();
                if (v != null)
                {
                    db.Activity_Report.Remove(v);
                    db.SaveChanges();
                    status = true;
                }
            
            return RedirectToAction("Index");
        }
    }
}