﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ThermalERP.Entities.Models;

namespace ThermalERP.web.Controllers
{
    public class Part_List_ItemController : Controller
    {
        private Thermal_PMSEntities1 db = new Thermal_PMSEntities1();

        // GET: Part_List_Item
        public ActionResult Index()
        {
            return View(db.Part_List_Item.ToList());
        }

        // GET: Part_List_Item/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Part_List_Item part_List_Item = db.Part_List_Item.Find(id);
            if (part_List_Item == null)
            {
                return HttpNotFound();
            }
            return View(part_List_Item);
        }

        // GET: Part_List_Item/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Part_List_Item/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "id,Project_Code,Maker_No,Apg_No,Apg_Name,Partlist_No,Part_Group,Part_Sl_No,Part_Name,Part_Desription,Part_variant,Part_UOM,Part_Spec_Id,Part_Rm_Type,Part_Rm_WThick,Part_Rm_Density,Part_Mtc_Cert,Part_IBR_Cert,Part_EN_Cert,Part_RM_Code,Part_Dia,Part_Wt,Part_Length,Part_W2,Part_Fg_wt,Part_Rm_Wt,Part_D_Wt,Part_Engg_Code,CompId,Version_No,Version_Date,Version_Change,Created,Creted_By,Modified,Modified_By,Qty,OD,Part_Equipment_Name,Status,Drawing_NO,PTS_NO,Main_Drwaing_No,Activity_Part_No")] Part_List_Item part_List_Item)
        {
            if (ModelState.IsValid)
            {
                db.Part_List_Item.Add(part_List_Item);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(part_List_Item);
        }

        // GET: Part_List_Item/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Part_List_Item part_List_Item = db.Part_List_Item.Find(id);
            if (part_List_Item == null)
            {
                return HttpNotFound();
            }
            return View(part_List_Item);
        }

        // POST: Part_List_Item/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,Project_Code,Maker_No,Apg_No,Apg_Name,Partlist_No,Part_Group,Part_Sl_No,Part_Name,Part_Desription,Part_variant,Part_UOM,Part_Spec_Id,Part_Rm_Type,Part_Rm_WThick,Part_Rm_Density,Part_Mtc_Cert,Part_IBR_Cert,Part_EN_Cert,Part_RM_Code,Part_Dia,Part_Wt,Part_Length,Part_W2,Part_Fg_wt,Part_Rm_Wt,Part_D_Wt,Part_Engg_Code,CompId,Version_No,Version_Date,Version_Change,Created,Creted_By,Modified,Modified_By,Qty,OD,Part_Equipment_Name,Status,Drawing_NO,PTS_NO,Main_Drwaing_No,Activity_Part_No")] Part_List_Item part_List_Item)
        {
            if (ModelState.IsValid)
            {
                db.Entry(part_List_Item).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(part_List_Item);
        }

        // GET: Part_List_Item/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Part_List_Item part_List_Item = db.Part_List_Item.Find(id);
            if (part_List_Item == null)
            {
                return HttpNotFound();
            }
            return View(part_List_Item);
        }

        // POST: Part_List_Item/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Part_List_Item part_List_Item = db.Part_List_Item.Find(id);
            db.Part_List_Item.Remove(part_List_Item);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
