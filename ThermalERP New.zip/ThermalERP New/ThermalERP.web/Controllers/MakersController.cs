﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ThermalERP.web.Controllers
{
    public class MakersController : Controller
    {
        // GET: Makers
        public ActionResult Index()
        {
            return View();
        }
    }
}