﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ThermalERP.Entities.Models;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
    public class SubAssemblyController : Controller
    {
        private Thermal_PMSEntities1 _dbContext;
        #region Constructor
        public SubAssemblyController()
        {
            _dbContext = new Thermal_PMSEntities1();
        }
        // GET: SubAssembly
        public ActionResult Index()
        {
            var SAMasterData = _dbContext.SubAssembly_Master.ToList();
            var data = new List<SubAssembly_MasterViewModel>();
            //foreach (var item in SAMasterData)
            //{

            //    data.Add(item);
            //}
        
            return View(data);
        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(SubAssembly_MasterViewModel model)
        {
            if(ModelState.IsValid)
            {
                SubAssembly_Master data = new SubAssembly_Master();
                data.Sub_Assembly_Name = model.Sub_Assembly_Name;
                data.Sub_Assembly_Name = model.CompID;
                data.Created_By = model.Created_By;
                data.Created_On = DateTime.Now;
                data.Modified_By = model.Modified_By;
                data.Modified_On = DateTime.Now;
                data.id = model.id;
                data.GroupName = model.GroupName;
                _dbContext.SubAssembly_Master.Add(data);
                _dbContext.SaveChanges();
                return RedirectToAction("Index");
               
            }
            return View();
        }
        //[HttpGet]
        //public ActionResult Edit(int? id)
        //{
        //    http
        //}

       
    }
}
#endregion