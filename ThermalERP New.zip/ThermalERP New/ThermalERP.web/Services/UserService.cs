﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ThermalERP.Entities;
using ThermalERP.Entities.Models;
//using ThermalERP.Entities.Entities;


namespace ThermalERP.web.Services
{
    public class UserService : IDisposable
    {
        private readonly Thermal_PMSEntities1 _dbContext;

        public UserService(Thermal_PMSEntities1 dbContext)
        {
            _dbContext = dbContext;
        }

        public tbl_User GetUser(string userEmail)
        {
            tbl_User user = _dbContext.tbl_User.Where(x => x.Email.ToLower().ToString() == userEmail.ToLower().ToString()).FirstOrDefault();
           // tbl_User user = _dbContext.tbl_User.Where(x => x.Email.ToLower().ToString() == userEmail.Email.ToLower().ToString().ToString() && x.Password == userEmail.Password).FirstOrDefault();
            return user;
        }
       


        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}