﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ThermalERP.web.Models
{
    public class ActivityMasterViewModel
    {
        public Activity_Master activity { get; set; }
        public List<Child_Activity> childActivityList { get; set; }
    }
}