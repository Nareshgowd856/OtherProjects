﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{

    public class PurchaseTechSpecController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();
        // GET: Demo
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetEmployees()
        {

            var employees = db.Part_List.OrderBy(a => a.Part_List_No).ToList();
            return Json(new { data = employees }, JsonRequestBehavior.AllowGet);

        }
        [HttpGet]
        public ActionResult Save(int id)
        {

            var v = db.Part_List.Where(a => a.id == id).FirstOrDefault();
            return View(v);

        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var v = db.Part_List.Where(a => a.id == id).FirstOrDefault();
            return View(v);
        }
        public ActionResult Edit(Part_List part_List)
        {
            if (ModelState.IsValid)
            {
                db.Entry(part_List).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(part_List);
        }

        public ActionResult Create()
        {
            return View();
        }
        public ActionResult Partial_Create()
        {
            return PartialView();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Partial_Create([Bind(Include = "id,Part_List_No,Part_List_Name,CompID,Created_By,Created_On,Modified_By,Mpdified_On")] Part_List part_List)
        {
            if (ModelState.IsValid)
            {
                db.Part_List.Add(part_List);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id = new SelectList(db.Part_List, "Id", "Part_List_No", part_List.Part_List_No);
            return PartialView(part_List);
        }
        [HttpPost]
        public ActionResult Save(Part_List emp)
        {
            bool status = false;
            if (ModelState.IsValid)
            {

                if (emp.id > 0)
                {
                    //Edit 
                    var v = db.Part_List.Where(a => a.id == emp.id).FirstOrDefault();
                    if (v != null)
                    {
                        v.Part_List_No = emp.Part_List_No;
                        v.Part_List_Name = emp.Part_List_Name;

                    }
                }
                else
                {
                    //Save
                    db.Part_List.Add(emp);
                }
                db.SaveChanges();
                status = true;

            }
            return RedirectToAction("Index", "PurchaseTechSpec");
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {

            var v = db.Part_List.Where(a => a.id == id).FirstOrDefault();
            if (v != null)
            {
                return View(v);
            }
            else
            {
                return HttpNotFound();
            }

        }
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteEmployee(int id)
        {
            bool status = false;

            var v = db.Part_List.Where(a => a.id == id).FirstOrDefault();
            if (v != null)
            {
                db.Part_List.Remove(v);
                db.SaveChanges();
                status = true;
            }

            return RedirectToAction("Index");
        }
    }
}