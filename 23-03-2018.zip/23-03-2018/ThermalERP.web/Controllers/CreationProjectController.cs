﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
   
        public class CreationProjectController : Controller
        {
            private Thermal_PMSEntities db = new Thermal_PMSEntities();
            // GET: CreationProject
            public ActionResult Index()
            {
                return View();
            }
            public ActionResult GetEmployees()
            {
                var employees = db.Project_Master.OrderBy(a => a.id).ToList();
                return Json(new { data = employees }, JsonRequestBehavior.AllowGet);
            }
       
              [HttpGet]
            public ActionResult Save(int id)
            {

                var v = db.Project_Master.Where(a => a.id == id).FirstOrDefault();
                return View(v);

            }
            [HttpGet]
            public ActionResult Edit(int id)
            {
                var v = db.Project_Master.Where(a => a.id == id).FirstOrDefault();
                return View(v);
            }

            public ActionResult Create()
            {
                return View("Partial_Create");
            }


            [HttpPost]
            public ActionResult Save(Project_Master emp)
            {
                bool status = false;
                if (ModelState.IsValid)
                {

                    if (emp.id > 0)
                    {
                        //Edit 
                        var v = db.Project_Master.Where(a => a.id == emp.id).FirstOrDefault();
                        if (v != null)
                        {
                            v.Project_Code = emp.Project_Code;
                            v.Project_Name = emp.Project_Name;
                            v.Project_Client = emp.Project_Client;
                            v.Project_DeliveryDate = emp.Project_DeliveryDate;
                            v.CompID = emp.CompID;
                    }
                    }
                    else
                    {
                        //Save
                        db.Project_Master.Add(emp);
                    }
                    db.SaveChanges();
                    status = true;

                }
                return RedirectToAction("Index", "CreationProject");
            }
            [HttpGet]
            public ActionResult Delete(int id)
            {

                var v = db.Project_Master.Where(a => a.id == id).FirstOrDefault();
                if (v != null)
                {
                    return View(v);
                }
                else
                {
                    return HttpNotFound();
                }

            }
        [HttpGet]
        public ActionResult Partial_Create()                  
        {

            return PartialView();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Partial_Create([Bind(Include = "id,Project_Code,Project_equip_Name,CompID,Project_Name,Project_Client,Project_DeliveryDate,Project_Description" )] Project_Master Project_Master)
        {
            if (ModelState.IsValid)
            {
                db.Project_Master.Add(Project_Master);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id = new SelectList(db.Project_Master, "Id", "Project_Code", Project_Master);
            return PartialView(Project_Master);
        }

        public ActionResult Technical_Data()
        {
            return PartialView("Technical_Data"); 
        }
        public ActionResult Technical_Data([Bind(Include= "id,Project_Code,Special_Mtrl_Requ_Chk,Special_Mtrl_Requ,Warranty_Period,CE_Marking,Insp_TPIA,ASME_Code,National_Board_reg,InspectionBy_CIB,Comp_With_Loc_Reg,Comp_With_Doc_To_Gost,QAP_Approve,Insp_by_Auth_Insp,Insp_by_Accep_Client,Concession_Requeist_Client,CompID,Created_by,Created_On,Modified_By,Modified_On,ProjectCodeConstruction")] Project_Technical_Data project_Technical_Data )

        {
            if(ModelState.IsValid)
            {
                db.Project_Technical_Data.Add(project_Technical_Data);
                db.SaveChanges();
                return RedirectToAction("Partial_Create");
            }
            ViewBag.Id = new SelectList(db.Project_Technical_Data, "Id", "Project_Code", project_Technical_Data);
            return PartialView(project_Technical_Data);
        }
        public ActionResult Commercial_Data()
        {
            return PartialView("Commercial_Data");
        }
        public ActionResult Commercial_Data([Bind(Include = "id,Project-Code,Project_Clasification,Project-Sector,Project_Currency,LDfor_Delyed_Deliveryfor_Equip,LDfor_Delayed_Deliveryfor_Draw,Mile_Stone,Per_payments,TriggeringPoint,CompID.Created_By,Created_On,Modified_By,Modified_On")] Project_Commercial_Data project_Commercial_Data)

        {
            if (ModelState.IsValid)
            {
                db.Project_Commercial_Data.Add(project_Commercial_Data);
                db.SaveChanges();
                return RedirectToAction("Partial_Create");
            }
            ViewBag.Id = new SelectList(db.Project_Commercial_Data, "Id", "Project_Code", project_Commercial_Data);
            return PartialView(project_Commercial_Data);
        }

        [HttpPost]
            [ActionName("Delete")]
            public ActionResult DeleteEmployee(int id)
            {
                bool status = false;

                var v = db.Project_Master.Where(a => a.id == id).FirstOrDefault();
                if (v != null)
                {
                    db.Project_Master.Remove(v);
                    db.SaveChanges();
                    status = true;
                }

                return RedirectToAction("Index");
            }
                }
            }