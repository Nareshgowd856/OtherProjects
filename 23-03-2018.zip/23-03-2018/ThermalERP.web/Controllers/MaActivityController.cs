﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
    public class MaActivityController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();

        // GET: MaActivity
        public ActionResult Index()
        {
            return View(db.Master_Activity.ToList());
        }

        // GET: MaActivity/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Master_Activity master_Activity = db.Master_Activity.Find(id);
            if (master_Activity == null)
            {
                return HttpNotFound();
            }
            return View(master_Activity);
        }

        // GET: MaActivity/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: MaActivity/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Id,Activity_Code,Activity_Description,Activity_Group,Activity_Document,Activity_Type,Activity_Predessor,Activity_Exe_Time,CompID,Created_By,Created_On,Modified_By,Modified_on,Activity_Level,Time_Unit,Resp_Dept,Applicable_Equipments")] Master_Activity master_Activity)
        {
            if (ModelState.IsValid)
            {
                db.Master_Activity.Add(master_Activity);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(master_Activity);
        }

        // GET: MaActivity/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Master_Activity master_Activity = db.Master_Activity.Find(id);
            if (master_Activity == null)
            {
                return HttpNotFound();
            }
            return View(master_Activity);
        }

        // POST: MaActivity/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Id,Activity_Code,Activity_Description,Activity_Group,Activity_Document,Activity_Type,Activity_Predessor,Activity_Exe_Time,CompID,Created_By,Created_On,Modified_By,Modified_on,Activity_Level,Time_Unit,Resp_Dept,Applicable_Equipments")] Master_Activity master_Activity)
        {
            if (ModelState.IsValid)
            {
                db.Entry(master_Activity).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(master_Activity);
        }

        // GET: MaActivity/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Master_Activity master_Activity = db.Master_Activity.Find(id);
            if (master_Activity == null)
            {
                return HttpNotFound();
            }
            return View(master_Activity);
        }

        // POST: MaActivity/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Master_Activity master_Activity = db.Master_Activity.Find(id);
            db.Master_Activity.Remove(master_Activity);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
