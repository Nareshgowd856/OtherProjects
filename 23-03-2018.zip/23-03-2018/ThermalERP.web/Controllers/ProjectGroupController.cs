﻿//using System;
//using System.Collections.Generic;
//using System.Data;
//using System.Data.Entity;
//using System.Linq;
//using System.Net;
//using System.Web;
//using System.Web.Mvc;
//using ThermalERP.web.Models;
//using System.Linq.Dynamic;

//namespace ThermalERP.web.Controllers
//{
//    public class ProjectGroupController : Controller
//    {
//        private Thermal_PMSEntities db = new Thermal_PMSEntities();

//        // GET: ProjectGroup
//        public ActionResult Index()
//        {
//            return View(db.APG_Master.ToList());
//        }
//        [HttpGet]
//        public ActionResult Index(int page = 1, string sort = "APG_No", string sortdir = "asc", string search = "")
//        {
//            int pagesize = 10;
//            int totalRecord = 0;
//            if (page < 1) page = 1;
//            int skip = (page * pagesize) - pagesize;
//            var data = GetList(search, sort, sortdir, skip, pagesize, out totalRecord);
//            ViewBag.TotalRows = totalRecord;
//            return View(data);
//        }
//        public List<APG_Master> GetList(string Search, string sort, string sortdir, int skip, int pageSize, out int TotalRecord)
//        {
//            using (Thermal_PMSEntities db = new Thermal_PMSEntities())
//            {
//                var v = (from a in db.APG_Master
//                         where
//                         a.APG_No.Contains(Search) ||
//                         a.APG_Description.Contains(Search)
//                         select a
//                         );
//                TotalRecord = v.Count();
//                v = v.OrderBy(sort + " " + sortdir);
//                if (pageSize > 0)
//                {
//                    v = v.Skip(skip).Take(pageSize);
//                }
//                return v.ToList();
//            }
//        }

//        //[HttpGet]
//        //public ActionResult CheckList()
//        //{
//        //    var list = new List<APG_Master>
//        //    {
//        //         new APG_Master{id = 1, APG_ApplicableTo = "Engineering", Checked = false},
//        //         new APG_Master{id = 2, APG_ApplicableTo = "CMD", Checked = false},
//        //         new APG_Master{id = 3, APG_ApplicableTo = "Proposal", Checked = false},
//        //         new APG_Master{id = 4, APG_ApplicableTo = "Manufacturing", Checked = false},

//        //    };
//        //    return View(list);
//        //}

//        // GET: ProjectGroup/Details/5
//        public ActionResult Details(int? id)
//        {
//            if (id == null)
//            {
//                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
//            }
//            APG_Master aPG_Master = db.APG_Master.Find(id);
//            if (aPG_Master == null)
//            {
//                return HttpNotFound();
//            }
//            return View(aPG_Master);
//        }

//        // GET: ProjectGroup/Create
//        public ActionResult Create()
//        {
//            ViewBag.Id = new SelectList(db.APG_Master, "Id" , "APG NO");
//            return PartialView("Partial_Create");
//        }


//        //[ValidateAntiForgeryToken]
//        //public ActionResult Create([Bind(Include = "APG_No,APG_Description,APG_ApplicableTo,CompID,id,Created_By,Created_On,Modified_By,Modified_On")] APG_Master aPG_Master)
//        //{
//        //    if (ModelState.IsValid)
//        //    {
//        //        db.APG_Master.Add(aPG_Master);
//        //        db.SaveChanges();
//        //        return RedirectToAction("Index");
//        //    }
//        //    ViewBag.Id = new SelectList(db.APG_Master, "Id", "APG NO", aPG_Master.APG_No);
//        //    return View(aPG_Master);
//        //}

//        // GET: ProjectGroup/Edit/5

//        [HttpGet]
//        public ActionResult Edit()
//        {             ViewBag.Id = new SelectList(db.APG_Master, "Id", "APG NO");
//                      return PartialView("Partial_Edit");
//            //APG_Master data = db.APG_Master.Where(x => x.APG_No == APG_No.ToString()).FirstOrDefault();
//            //Apg_Masters obj = new Apg_Masters();
//            //obj.APG_No = data.APG_No;
//            //obj.APG_Description = data.APG_Description;
//            //obj.APG_ApplicableTo = data.APG_ApplicableTo;
//            //return View();
//        }
//        //public ActionResult Edit(APG_Master project)
//        //{
//        //    try
//        //    {
//        //        if (project.id == 0)
//        //        {
//        //            project.Created_By = Convert.ToString(Session["UserId"].ToString());
//        //            project.Created_On = DateTime.Now;
//        //            project.Created_By = Session["UserName"].ToString();
//        //            db.APG_Master.Add(project);
//        //            db.SaveChanges();
//        //            return Json(new { success = true, message = "saved successfully" }, JsonRequestBehavior.AllowGet);
//        //        }
//        //        else
//        //        {
//        //            project.Modified_By = Convert.ToString(Session["UserId"]);
//        //            project.Modified_On = DateTime.Now;
//        //            project.Created_By = Session["Username"].ToString();
//        //            db.Entry(project).State = System.Data.Entity.EntityState.Modified;
//        //            db.SaveChanges();
//        //            return Json(new { success = true, message = "Updated Successfully" }, JsonRequestBehavior.AllowGet);
//        //        }
//        //    }
//        //    catch (Exception ex)
//        //    {
//        //        throw ex;
//        //    }
//        //}
//       // [HttpPost]
//       //public JsonResult Editdata(ThermalERP.web.Models.APG_Master product)
//       //{
//       //     APG_Master tblprod = db.APG_Master.Where(x => x.APG_No == product.APG_No.ToString()).FirstOrDefault();
//       //     tblprod.APG_Description = product.APG_Description;
//       //     tblprod.APG_ApplicableTo = product.APG_ApplicableTo;
//       //     db.SaveChanges();

//       //     return Json(tblprod, JsonRequestBehavior.AllowGet);

//       // }

//        //public ActionResult Edit(int? id)

//        //{
//        //    if (id == null)
//        //    {
//        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
//        //    }
//        //    APG_Master aPG_Master = db.APG_Master.Find(id);
//        //    if (aPG_Master == null)
//        //    {
//        //        return HttpNotFound();
//        //    }
//        //    return View(aPG_Master);

//        //}


//        //[HttpPost]
//        //[ValidateAntiForgeryToken]
//        //public ActionResult Edit(APG_Master project)
//        //{
//        //    try
//        //    {
//        //        if (project.id == 0)
//        //        {
//        //            project.Created_By = Convert.ToString(Session["UserId"].ToString());
//        //            project.Created_On = DateTime.Now;
//        //            project.Created_By = Session["UserName"].ToString();
//        //            db.APG_Master.Add(project);
//        //            db.SaveChanges();
//        //            return Json(new { success = true, message = "saved successfully" }, JsonRequestBehavior.AllowGet);
//        //        }
//        //        else
//        //        {
//        //            project.Modified_By = Convert.ToString(Session["UserId"]);
//        //            project.Modified_On = DateTime.Now;
//        //            project.Created_By = Session["Username"].ToString();
//        //            db.Entry(project).State = System.Data.Entity.EntityState.Modified;
//        //            db.SaveChanges();
//        //            return Json(new { success = true, message = "Updated Successfully" }, JsonRequestBehavior.AllowGet);
//        //        }
//        //    }
//        //    catch (Exception ex)
//        //    {
//        //        throw ex;
//        //    }
//        //}
//        public JsonResult Change(APG_Master model)
//        {
//            string message = "success";
//            return Json(message, JsonRequestBehavior.AllowGet);
//        }
//        //public ActionResult Edit([Bind(Include = "APG_No,APG_Description,APG_ApplicableTo,CompID,id,Created_By,Created_On,Modified_By,Modified_On")] APG_Master aPG_Master)
//        //{
//        //    if (!ModelState.IsValid)
//        //    {
//        //        db.Entry(aPG_Master).State = System.Data.Entity.EntityState.Modified;
//        //        db.SaveChanges();
//        //        return RedirectToAction("Index");
//        //    }
//        //    ViewBag.Id = new SelectList(db.APG_Master, "Id", "APG NO", aPG_Master.APG_No);
//        //    return View(aPG_Master);
//        //}

//        // GET: ProjectGroup/Delete/5
//        public ActionResult Delete(int? id)
//        {                                             

//            if (id == null)
//            {
//                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
//            }
//            APG_Master aPG_Master = db.APG_Master.Find(id);
//            if (aPG_Master == null)
//            {
//                return HttpNotFound();
//            }
//            return View(aPG_Master);
//        }

//        public ActionResult Partial_Create()
//        {
//            return PartialView();
//        }
//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public ActionResult Partial_Create([Bind(Include = "APG_No,APG_Description,APG_ApplicableTo,CompID,id,Created_By,Created_On,Modified_By,Modified_On")] APG_Master aPG_Master)
//        {
//            if (ModelState.IsValid)
//            {
//                db.APG_Master.Add(aPG_Master);
//                db.SaveChanges();
//                return RedirectToAction("Index");
//            }
//            ViewBag.Id = new SelectList(db.APG_Master, "Id", "APG NO", aPG_Master.APG_No);
//            return PartialView(aPG_Master);
//        }


//        [HttpGet]

//        public ActionResult Partial_Edit()
//      {
//           return PartialView();
//        }


//        [HttpPost]
//        [ValidateAntiForgeryToken]
//        public ActionResult Partial_Edit([Bind(Include = "APG_No,APG_Description,APG_ApplicableTo,CompID,id,Created_By,Created_On,Modified_By,Modified_On")] APG_Master aPG_Master)
//        {
//            if (ModelState.IsValid)
//            {
//                db.APG_Master.Add(aPG_Master);
//                db.SaveChanges();
//                return RedirectToAction("Index");
//            }
//            ViewBag.Id = new SelectList(db.APG_Master, "Id", "APG NO", aPG_Master.APG_No);
//            return PartialView(aPG_Master);
//        }


//        // POST: ProjectGroup/Delete/5
//        [HttpPost, ActionName("Delete")]
//        [ValidateAntiForgeryToken]
//        public ActionResult DeleteConfirmed(int id)
//        {


//            //APG_Master project = db.APG_Master.Where(x => x.id == id).FirstOrDefault<APG_Master>();
//            //db.APG_Master.Remove(project);
//            //db.SaveChanges();
//            //return Json(new { success = true, message = "Deleted Successfully" }, JsonRequestBehavior.AllowGet);

//            APG_Master aPG_Master = db.APG_Master.Find(id);
//            db.APG_Master.Remove(aPG_Master);
//            db.SaveChanges();
//            return RedirectToAction("Index");
//        }

//        protected override void Dispose(bool disposing)
//        {
//            if (disposing)
//            {
//                db.Dispose();
//            }
//            base.Dispose(disposing);
//        }
//    }
//}




using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{

    public class ProjectGroupController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();
        // GET: Demo
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetEmployees()
        {

            var employees = db.APG_Master.OrderBy(a => a.id).ToList();
            return Json(new { data = employees }, JsonRequestBehavior.AllowGet);

        }
        [HttpGet]
        public ActionResult Save(int id)
        {

            var v = db.APG_Master.Where(a => a.id == id).FirstOrDefault();
            return View(v);

        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var v = db.APG_Master.Where(a => a.id == id).FirstOrDefault();
            return View(v);
        }
        public ActionResult Edit(APG_Master apgMaster)
        {
            if(ModelState.IsValid)
            {  
            db.Entry(apgMaster).State = System.Data.Entity.EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("Index");
        }
        return View(apgMaster);
    }

        public ActionResult Create()
        {
            return View("Partial_Create");
        }


        [HttpPost]
        public ActionResult Save(APG_Master emp)
        {
            bool status = false;
            if (ModelState.IsValid)
            {

                if (emp.id > 0)
                {
                    //Edit 
                    var v = db.APG_Master.Where(a => a.id == emp.id).FirstOrDefault();
                    if (v != null)
                    {
                        v.APG_No = emp.APG_No;
                        v.APG_Description = emp.APG_Description;
                        v.APG_ApplicableTo = emp.APG_ApplicableTo;
                    }
                }
                else
                {
                    //Save
                    db.APG_Master.Add(emp);
                }
                db.SaveChanges();
                status = true;

            }
            return RedirectToAction("Index", "ProjectGroup");
        }
        public ActionResult Partial_Create()
        {
            return PartialView();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Partial_Create([Bind(Include = "APG_No,APG_Description,APG_ApplicableTo,CompID,id,Created_By,Created_On,Modified_By,Modified_On")] APG_Master aPG_Master)
        {
            if (ModelState.IsValid)
            {
                db.APG_Master.Add(aPG_Master);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id = new SelectList(db.APG_Master, "Id", "APG NO", aPG_Master.APG_No);
            return PartialView(aPG_Master);
        }


        [HttpGet]
        public ActionResult Delete(int id)
        {

            var v = db.APG_Master.Where(a => a.id == id).FirstOrDefault();
            if (v != null)
            {
                return View(v);
            }
            else
            {
                return HttpNotFound();
            }

        }
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteEmployee(int id)
        {
            bool status = false;

            var v = db.APG_Master.Where(a => a.id == id).FirstOrDefault();
            if (v != null)
            {
                db.APG_Master.Remove(v);
                db.SaveChanges();
                status = true;
            }

            return RedirectToAction("Index");
        }
    }
}