﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Entity;
using System.Data.SqlClient;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;
using System.Linq.Dynamic;



namespace ThermalERP.web.Controllers
{
    public class ActMasterController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();

      
        public ActionResult Index()
        {
            List<ActivityMasterViewModel> activityList = new List<ActivityMasterViewModel>();
            using (Thermal_PMSEntities db = new Thermal_PMSEntities())
            {
                var o = db.Activity_Master.OrderBy(a => a.Activity_Code);
                foreach (var i in o)
                {

                    var childActivityData = db.Child_Activity.Where(a => a.Activity_Master_Id.Equals(i.Activity_Code)).ToList();
                    activityList.Add(new ActivityMasterViewModel { activity = i, childActivityList = childActivityData });
                }
            }
            return View(activityList);
            //List<ActivityMasterViewModel> activityList = new List<ActivityMasterViewModel>();
            //var activityMasterdata = db.Activity_Master.OrderBy(x => x.id).ToList();
            //foreach (var item in activityMasterdata)
            //{
            //    var id = item.Activity_Code;
            //    var childActivityData = db.Child_Activity.Where(y => y.Activity_Master_Id.Equals(id)).ToList();
            //    activityList.Add(new ActivityMasterViewModel { activity = item, childActivityList = childActivityData });
            //}
            //return View(activityList);
        }
        [HttpGet]
        public ActionResult Editdata(int Aid)
        {
            //    using (Thermal_PMSEntities db = new Thermal_PMSEntities())
            //    {
            //        if (id == 0)
            //            return View(new Activity_Master());
            //        else
            //        {
            //            var Act = db.Activity_Master.Where(x => x.Activity_Code == id.ToString()).FirstOrDefault<Activity_Master>();
            //            return PartialView("Editdata", Act);
            //        }
            //    }
            //}
            Activity_Master actmaster = db.Activity_Master.Where(x => x.Activity_Code == Aid.ToString()).FirstOrDefault();
            Activity_Master obj = new Activity_Master();
            obj.Activity_Description = actmaster.Activity_Description;
            obj.Activity_Document = actmaster.Activity_Document;
            obj.Activity_Group = actmaster.Activity_Group;
            return PartialView(obj);
           
        }
        [HttpPost]
        //public ActionResult Editdata(Activity_Master Act)
        //{
            //using (Thermal_PMSEntities db = new Thermal_PMSEntities())
            //{
            //    try
            //    {
            //        if (Act.Activity_Code == 0.ToString())
            //        {
            //            Act.Activity_Description = Act.Activity_Description;
            //               Act.Activity_Document = Act.Activity_Document;
            //            Act.Activity_Group = Act.Activity_Group;
            //            db.Activity_Master.Add(Act);
            //            db.SaveChanges();
            //            return Json( new { success = true, message = "saved Successfully" }, JsonRequestBehavior.AllowGet);
            //        }
            //        else
            //        {
            //            Act.Activity_Description = Act.Activity_Description;
            //            Act.Activity_Document = Act.Activity_Document;
            //            Act.Activity_Group = Act.Activity_Group;
            //            db.Entry(Act).State = System.Data.Entity.EntityState.Modified;
            //            db.SaveChanges();
            //            return Json(new { success = true, message = "Updated Successfully" }, JsonRequestBehavior.AllowGet);
            //        }
            //    }
            //    catch(Exception ex)
            //    {
            //        throw ex;
            //    }
            //}

            public JsonResult changeUser(Activity_Master model)
        {
            string message = "success";
            return Json(message, JsonRequestBehavior.AllowGet);
      }


            //public JsonResult Editdata(Activity_Master product)
            //{
            //    Activity_Master tblProd = db.Activity_Master.Where(x => x.Activity_Code == product.Activity_Code)
            //                        .FirstOrDefault();

            //    tblProd.Activity_Description = product.Activity_Description;
            //    tblProd.Activity_Document = product.Activity_Document;
            //    tblProd.Activity_Group = product.Activity_Group;

            //    db.SaveChanges();

            //    return Json(tblProd, JsonRequestBehavior.AllowGet);
            //    }

                public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Material_Grades material_Grades = db.Material_Grades.Find(id);
            if (material_Grades == null)
            {
                return HttpNotFound();
            }
            return View(material_Grades);
        }


        //    ViewBag.childActivityList = db.Child_Activity.ToList();
        //    return View(db.Activity_Master.ToList());
        //}

        public ActionResult Add()
        {
            return View(db.Child_Activity.ToList());
        }

        public ActionResult Created()
        {
            //ViewBag.Id = new SelectList(db.Child_Activity, "Id", "ActivityCode");
            ViewBag.Id = new SelectList(db.Child_Activity, "Id", "ActivityCode");
            return View("Partial_Add");
        }
        //public ActionResult SubActivity()
        //{
        //    ViewBag.Id = new SelectList(db.Resource_Master, "Id", "ActivityCode");
        //    return PartialView("Partial_Add");

        //}
        [HttpGet]
        public ActionResult Partial_Add()
        {
            return PartialView();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Partial_Add([Bind(Include = "Id,ActivityCode,Description,Execution_Duration_Date,Execution_Duration_Time,Applicable_No,CompID,Created_By,Created_On,Modified_On,Modified_By,Activity_Master_Id")] Child_Activity child_Activity)
        {
          
            if (ModelState.IsValid)
            {
                db.Child_Activity.Add(child_Activity);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Id = new SelectList(db.Child_Activity, "Id", "ActivityCode", child_Activity);
            return PartialView(child_Activity);
        }

        // GET: ActMaster/Details/5
        //public ActionResult Details(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    Activity_Master activity_Master = db.Activity_Master.Find(id);
        //    if (activity_Master == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(activity_Master);
        //}

        // GET: ActMaster/Create
        public ActionResult Create()
        {
            var MA_list = db.Activity_Master.Select(s => new SelectListItem() { Text = s.Activity_Description, Value = s.Activity_Code }).ToList();
            ViewBag.MasterActivityList = new SelectList(MA_list, "Value", "text");
            var data = db.Activity_Master.ToList();
            ViewBag.MasterActivity = data;
            return View();

        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Activity_Code,Activity_Description,Activity_Group,Activity_Document,Activity_Type,Activity_Predessor,Activity_Exe_Time,CompID,Created_By,Created_On,Modified_By,Modified_on,id,Activity_Level,Time_Unit,Resp_Dept,Applicable_Equipments")] Activity_Master activity_Master)
        {
            if (ModelState.IsValid)
            {
                db.Activity_Master.Add(activity_Master);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(activity_Master);
        }


        // POST: ChildActivity/Create
       
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Created([Bind(Include = "Id,ActivityCode,Description,Execution_Duration_Date,Execution_Duration_Time,Applicable_No,CompID,Created_By,Created_On,Modified_On,Modified_By")] Child_Activity child_Activity)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Child_Activity.Add(child_Activity);
        //        db.SaveChanges();
        //        return RedirectToAction("Add");
        //    }

        //    return View(child_Activity);
        //}



        public ActionResult Edited(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Child_Activity child_Activity = db.Child_Activity.Find(id);
            if (child_Activity == null)
            {
                return HttpNotFound();
            }
            return View(child_Activity);
        }

        // POST: ChildActivity/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edited([Bind(Include = "Id,ActivityCode,Description,Execution_Duration_Date,Execution_Duration_Time,Applicable_No,CompID,Created_By,Created_On,Modified_On,Modified_By,Activity_Master_Id")] Child_Activity child_Activity)
        {
            if (ModelState.IsValid)
            {
                db.Entry(child_Activity).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Add");
            }
            return View(child_Activity);
        }
        // GET: ActMaster/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Activity_Master activity_Master = db.Activity_Master.Find(id);
            if (activity_Master == null)
            {
                return HttpNotFound();
            }
            return View(activity_Master);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Activity_Code,Activity_Description,Activity_Group,Activity_Document,Activity_Type,Activity_Predessor,Activity_Exe_Time,CompID,Created_By,Created_On,Modified_By,Modified_on,id,Activity_Level,Time_Unit,Resp_Dept,Applicable_Equipments")] Activity_Master activity_Master)
        {
            if (ModelState.IsValid)
            {
                db.Entry(activity_Master).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(activity_Master);
        }

        // GET: ActMaster/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Activity_Master activity_Master = db.Activity_Master.Find(id);
            if (activity_Master == null)
            {
                return HttpNotFound();
            }
            return View(activity_Master);
        }

       

        // POST: ActMaster/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Activity_Master activity_Master = db.Activity_Master.Find(id);
            db.Activity_Master.Remove(activity_Master);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

    //    [HttpGet]
    //    public ActionResult CheckList()
    //    {
    //        List<SelectListItem> items = new List<SelectListItem>();
    //        string constr = ConfigurationManager.ConnectionStrings["Constring"].ConnectionString;
    //        using (SqlConnection con = new SqlConnection(constr))
    //        {
    //            string query = " SELECT Id, Applicable Equipments  FROM Activity_Check";
    //            using (SqlCommand cmd = new SqlCommand(query))
    //            {
    //                cmd.Connection = con;
    //                con.Open();
    //                using (SqlDataReader sdr = cmd.ExecuteReader())
    //                {
    //                    while (sdr.Read())
    //                    {
    //                        items.Add(new SelectListItem
    //                        {
    //                            Text = sdr["Applicable Equipments"].ToString(),
    //                            Value = sdr["Id"].ToString()
    //                        });
    //                    }
    //                }
    //                con.Close();
    //            }
    //        }

    //        return View(items);
    //    }
      
    //    [HttpPost]
    //    public ActionResult CheckList(List<SelectListItem> items)
    //    {
    //        ViewBag.Message = "Selected Items:\\n";
    //        foreach (SelectListItem item in items)
    //        {
    //            if (item.Selected)
    //            {
    //                ViewBag.Message += string.Format("{0}\\n", item.Text);
    //            }
    //        }
    //        return View(items);
    //    }
    //}
  

    protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
