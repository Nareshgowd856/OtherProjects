﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
    public class DemoController : Controller
    {
        // GET: Demo
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetEmployees()
        {
            using (Thermal_PMSEntities dc = new Thermal_PMSEntities())
            {
                var employees = dc.Activity_Report.OrderBy(a => a.Activity_Code).ToList();
                return Json(new { data = employees }, JsonRequestBehavior.AllowGet);
            }
        }
        [HttpGet]
        public ActionResult Save(int id)
        {
            using (Thermal_PMSEntities dc = new Thermal_PMSEntities())
            {
                var v = dc.Activity_Report.Where(a => a.id == id).FirstOrDefault();
                return View(v);
            }
        }
        [HttpPost]
        public ActionResult Save(Activity_Report emp)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
                using (Thermal_PMSEntities dc = new Thermal_PMSEntities())
                {
                    if (emp.id > 0)
                    {
                        //Edit 
                        var v = dc.Activity_Report.Where(a => a.id == emp.id).FirstOrDefault();
                        if (v != null)
                        {
                            v.Activity_Code = emp.Activity_Code;
                            v.Activity_Description = emp.Activity_Description;

                        }
                    }
                    else
                    {
                        //Save
                        dc.Activity_Report.Add(emp);
                    }
                    dc.SaveChanges();
                    status = true;
                }
            }
            return new JsonResult { Data = new { status = status } };
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {
            using (Thermal_PMSEntities dc = new Thermal_PMSEntities())
            {
                var v = dc.Activity_Report.Where(a => a.id == id).FirstOrDefault();
                if (v != null)
                {
                    return View(v);
                }
                else
                {
                    return HttpNotFound();
                }
            }
        }
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteEmployee(int id)
        {
            bool status = false;
            using (Thermal_PMSEntities dc = new Thermal_PMSEntities())
            {
                var v = dc.Activity_Report.Where(a => a.id == id).FirstOrDefault();
                if (v != null)
                {
                    dc.Activity_Report.Remove(v);
                    dc.SaveChanges();
                    status = true;
                }
            }
            return new JsonResult { Data = new { status = status } };
        }
    }
}