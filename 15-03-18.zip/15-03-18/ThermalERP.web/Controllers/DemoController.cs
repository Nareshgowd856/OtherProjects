﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
    public class DemoController : Controller
    {
        // GET: Demo
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetEmployees()
        {
            using (Thermal_PMSEntities dc = new Thermal_PMSEntities())
            {
                var employees = dc.SubAssembly_Master.OrderBy(a => a.Sub_Assembly_ID).ToList();
                return Json(new { data = employees }, JsonRequestBehavior.AllowGet);
            }
        }
        [HttpGet]
        public ActionResult Save(int id)
        {
            using (Thermal_PMSEntities dc = new Thermal_PMSEntities())
            {
                var v = dc.SubAssembly_Master.Where(a => a.id == id).FirstOrDefault();
                return View(v);
            }
        }
        [HttpPost]
        public ActionResult Save(SubAssembly_Master emp)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
                using (Thermal_PMSEntities dc = new Thermal_PMSEntities())
                {
                    if (emp.id > 0)
                    {
                        //Edit 
                        var v = dc.SubAssembly_Master.Where(a => a.id == emp.id).FirstOrDefault();
                        if (v != null)
                        {
                            v.Sub_Assembly_ID = emp.Sub_Assembly_ID;
                            v.Sub_Assembly_Name = emp.Sub_Assembly_Name;
                           
                        }
                    }
                    else
                    {
                        //Save
                        dc.SubAssembly_Master.Add(emp);
                    }
                    dc.SaveChanges();
                    status = true;
                }
            }
            return new JsonResult { Data = new { status = status } };
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {
            using (Thermal_PMSEntities dc = new Thermal_PMSEntities())
            {
                var v = dc.SubAssembly_Master.Where(a => a.id == id).FirstOrDefault();
                if (v != null)
                {
                    return View(v);
                }
                else
                {
                    return HttpNotFound();
                }
            }
        }
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteEmployee(int id)
        {
            bool status = false;
            using (Thermal_PMSEntities dc = new Thermal_PMSEntities())
            {
                var v = dc.SubAssembly_Master.Where(a => a.id == id).FirstOrDefault();
                if (v != null)
                {
                    dc.SubAssembly_Master.Remove(v);
                    dc.SaveChanges();
                    status = true;
                }
            }
            return new JsonResult { Data = new { status = status } };
        }
    }
}