﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{

    public class WorkCentersController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();
        // GET: CreationProject
        public ActionResult Index()
        {
            return View();
        }
        public ActionResult GetEmployees()
        {
            var employees = db.WorkCenters.OrderBy(a => a.id).ToList();
            return Json(new { data = employees }, JsonRequestBehavior.AllowGet);
        }

        [HttpGet]
        public ActionResult Save(int id)
        {

            var v = db.WorkCenters.Where(a => a.id == id).FirstOrDefault();
            return View(v);

        }
        [HttpGet]
        public ActionResult Edit(int id)
        {
            var v = db.WorkCenters.Where(a => a.id == id).FirstOrDefault();
            return View(v);
        }

        public ActionResult Create()
        {
            return View("Partial_Create");
        }


        [HttpPost]
        public ActionResult Save(WorkCenter emp)
        {
            bool status = false;
            if (ModelState.IsValid)
            {

                if (emp.id > 0)
                {
                    //Edit 
                    var v = db.WorkCenters.Where(a => a.id == emp.id).FirstOrDefault();
                    if (v != null)
                    {
                        v.Work_Center_id = emp.Work_Center_id;
                        v.Work_Center = emp.Work_Center;
                       
                    }
                }
                else
                {
                    //Save
                    db.WorkCenters.Add(emp);
                }
                db.SaveChanges();
                status = true;

            }
            return RedirectToAction("Index", "WorkCenters");
        }
        [HttpGet]
        public ActionResult Delete(int id)
        {

            var v = db.WorkCenters.Where(a => a.id == id).FirstOrDefault();
            if (v != null)
            {
                return View(v);
            }
            else
            {
                return HttpNotFound();
            }

        }
        [HttpPost]
        [ActionName("Delete")]
        public ActionResult DeleteEmployee(int id)
        {
            bool status = false;

            var v = db.WorkCenters.Where(a => a.id == id).FirstOrDefault();
            if (v != null)
            {
                db.WorkCenters.Remove(v);
                db.SaveChanges();
                status = true;
            }

            return RedirectToAction("Index");
        }
    }
}