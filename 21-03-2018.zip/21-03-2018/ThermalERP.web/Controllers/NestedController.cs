﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
    public class NestedController : Controller
    {
       
        // GET: Nested
        public ActionResult Index()
        {

            List GetList = new List();
            // Gets the data from database and pass it to View
            //using strongly typed view concept.
            using (Thermal_PMSEntities db = new Thermal_PMSEntities())
            {
                var Codes = db.Activity_Master.OrderByDescending(a => a.Activity_Code);
                foreach (var i in Codes)
                {
                    var list = db.Child_Activity.Where(a => a.ActivityCode.Equals(i.Activity_Code)).ToList();
                    GetList.Add(new Add { Code = i, GetList = list });
                }
            }
            return View(GetList);
        }

        private class List
        {
            internal void Add(Add add)
            {
                //throw new NotImplementedException();
            }
        }
    }
}
            