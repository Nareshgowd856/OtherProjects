﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;

namespace ThermalERP.web.Controllers
{
    public class MasterActivityController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();

        // GET: MasterActivity
        public ActionResult Index()
        {
            return View(db.Activity_Master.ToList());
        }

        // GET: MasterActivity/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Activity_Master activity_Master = db.Activity_Master.Find(id);
            if (activity_Master == null)
            {
                return HttpNotFound();
            }
            return View(activity_Master);
        }

        // GET: MasterActivity/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: MasterActivity/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "Activity_Code,Activity_Description,Activity_Group,Activity_Document,Activity_Type,Activity_Predessor,Activity_Exe_Time,CompID,Created_By,Created_On,Modified_By,Modified_on,id")] Activity_Master activity_Master)
        {
            if (ModelState.IsValid)
            {
                db.Activity_Master.Add(activity_Master);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(activity_Master);
        }

        // GET: MasterActivity/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Activity_Master activity_Master = db.Activity_Master.Find(id);
            if (activity_Master == null)
            {
                return HttpNotFound();
            }
            return View(activity_Master);
        }

        // POST: MasterActivity/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Activity_Code,Activity_Description,Activity_Group,Activity_Document,Activity_Type,Activity_Predessor,Activity_Exe_Time,CompID,Created_By,Created_On,Modified_By,Modified_on,id")] Activity_Master activity_Master)
        {
            if (ModelState.IsValid)
            {
                db.Entry(activity_Master).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(activity_Master);
        }

        // GET: MasterActivity/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Activity_Master activity_Master = db.Activity_Master.Find(id);
            if (activity_Master == null)
            {
                return HttpNotFound();
            }
            return View(activity_Master);
        }

        // POST: MasterActivity/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Activity_Master activity_Master = db.Activity_Master.Find(id);
            db.Activity_Master.Remove(activity_Master);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult LoadingDept()

        {
            List<SelectListItem> li = new List<SelectListItem>();
            li.Add(new SelectListItem { Text = "Select", Value = "0" });
            li.Add(new SelectListItem { Text = "CMD", Value = "1" });
            li.Add(new SelectListItem { Text = "ENGINEERING", Value = "2" });
            li.Add(new SelectListItem { Text = "PPD", Value = "3" });
            li.Add(new SelectListItem { Text = "PROCUREMENT", Value = "4" });
            li.Add(new SelectListItem { Text = "PRODUCTION", Value = "5" });
            li.Add(new SelectListItem { Text = "STORES", Value = "6" });
            ViewData["Departments"] = li;
            return View();
        }
        public JsonResult GetDept(string id)
        {
            List<SelectListItem> Activity = new List<SelectListItem>();
            switch (id)
            {
                case "1":
                    Activity.Add(new SelectListItem { Text = "Select", Value = "0" });
                    Activity.Add(new SelectListItem { Text = "CHECK LIST", Value = "1" });
                    Activity.Add(new SelectListItem { Text = "PO Acceptance", Value = "2" });
                    Activity.Add(new SelectListItem { Text = "WORN", Value = "3" });
                    Activity.Add(new SelectListItem { Text = "Project Mgr. Nomination Letter", Value = "4" });
                    Activity.Add(new SelectListItem { Text = "Budgets", Value = "5" });
                    Activity.Add(new SelectListItem { Text = "Internal KOM", Value = "6" });
                    Activity.Add(new SelectListItem { Text = "External KOM", Value = "7" });
                    Activity.Add(new SelectListItem { Text = "L3 Sch.", Value = "8" });
                    Activity.Add(new SelectListItem { Text = "BBU	", Value = "9" });
                    Activity.Add(new SelectListItem { Text = "Drawings sub/apprl", Value = "10" });
                    Activity.Add(new SelectListItem { Text = "VDRL", Value = "11" });
                    Activity.Add(new SelectListItem { Text = "Key Raw mtrl status", Value = "12" });
                    Activity.Add(new SelectListItem { Text = "QAP	", Value = "13" });
                    Activity.Add(new SelectListItem { Text = "ABG	", Value = "14" });
                    Activity.Add(new SelectListItem { Text = "PBG	", Value = "15" });
                    Activity.Add(new SelectListItem { Text = "Advance	", Value = "16" });
                    Activity.Add(new SelectListItem { Text = "Milestone	", Value = "17" });
                    Activity.Add(new SelectListItem { Text = "Progress Report	", Value = "18" });
                    Activity.Add(new SelectListItem { Text = "Despatch Clearance - Int", Value = "19" });
                    Activity.Add(new SelectListItem { Text = "Despatch Clearance - Client	", Value = "20" });
                    Activity.Add(new SelectListItem { Text = "Comm.Invoices", Value = "21" });
                    Activity.Add(new SelectListItem { Text = "Retention	", Value = "22" });
                    Activity.Add(new SelectListItem { Text = "Road Permits	", Value = "23" });
                    Activity.Add(new SelectListItem { Text = "Final Documentation	", Value = "24" });
                    Activity.Add(new SelectListItem { Text = "Erection Billing", Value = "25" });
                    Activity.Add(new SelectListItem { Text = "TDS Certificate	", Value = "26" });
                    Activity.Add(new SelectListItem { Text = "PG test certificate	", Value = "27" });
                    Activity.Add(new SelectListItem { Text = "Contract Closure Report	", Value = "28" });

                    break;
                case "CMD":
                    break;

            }
            return Json(new SelectList(Activity, "Value", "Text"));
        }
        public JsonResult GetLink(string id)
        {
            List<SelectListItem> Links = new List<SelectListItem>();
            switch (id)
            {
                case "20":
                    Links.Add(new SelectListItem { Text = "Select", Value = "0" });
                    Links.Add(new SelectListItem { Text = "Attachment 1", Value = "1" });
                    Links.Add(new SelectListItem { Text = "Attachment 2", Value = "2" });
                    Links.Add(new SelectListItem { Text = "Attachment 3", Value = "3" });
                    Links.Add(new SelectListItem { Text = "Attachment 4", Value = "4" });
                    Links.Add(new SelectListItem { Text = "Attachment 5", Value = "5" });
                    Links.Add(new SelectListItem { Text = "Attachment 6", Value = "6" });
                    break;
            }

            return Json(new SelectList(Links, "Value", "Text"));
        }

    

protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
