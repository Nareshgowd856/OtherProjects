﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;
using System.Linq.Dynamic;

namespace ThermalERP.web.Controllers
{
    public class ItemMasterController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();

        // GET: ItemMaster
        public ActionResult Index()
        {
            return View(db.Item_RM_Master.ToList());
        }
        [HttpGet]
        public ActionResult Index(int page = 1, string sort = "Item_Type", string sortdir = "asc", string search = "")
        {
            int pagesize = 10;
            int totalRecord = 0;
            if (page < 1) page = 1;
            int skip = (page * pagesize) - pagesize;
            var data = GetList(search, sort, sortdir, skip, pagesize, out totalRecord);
            ViewBag.TotalRows = totalRecord;
            return View(data);
        }
        public List<Item_RM_Master> GetList(string Search, string sort, string sortdir, int skip, int pageSize, out int TotalRecord)
        {
            using (Thermal_PMSEntities db = new Thermal_PMSEntities())
            {
                var v = (from a in db.Item_RM_Master
                         where
                         a.Item_Type.Contains(Search) ||
                         a.Item_Group.Contains(Search) ||
                         a.Item_Pur_UOM.Contains(Search)
                         select a
                         );
                TotalRecord = v.Count();
                v = v.OrderBy(sort + " " + sortdir);
                if (pageSize > 0)
                {
                    v = v.Skip(skip).Take(pageSize);
                }
                return v.ToList();
            }
        }

        // GET: ItemMaster/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Item_RM_Master item_RM_Master = db.Item_RM_Master.Find(id);
            if (item_RM_Master == null)
            {
                return HttpNotFound();
            }
            return View(item_RM_Master);
        }

        // GET: ItemMaster/Create
        public ActionResult Create()
        {
            ViewBag.Id = new SelectList(db.Item_RM_Master, "Id", "Item_Type");
            return PartialView("Partial_Create");
        }

        // POST: ItemMaster/Create
       
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create([Bind(Include = "Item_Type,Item_Group,Item_Pur_UOM,Item_Iss_UOM,Item_Spec,Item_PTS,Item_BOM_Req,Item_Critical_Item,Item_ShelfLife,CompID,id")] Item_RM_Master item_RM_Master)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Item_RM_Master.Add(item_RM_Master);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    ViewBag.Id = new SelectList(db.Item_RM_Master, "Id", "ItemMaster", item_RM_Master.Item_Type);
        //    return View(item_RM_Master);
        //}

        // GET: ItemMaster/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Item_RM_Master item_RM_Master = db.Item_RM_Master.Find(id);
            if (item_RM_Master == null)
            {
                return HttpNotFound();
            }
            return View(item_RM_Master);
        }

        // POST: ItemMaster/Edit/5
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "Item_Type,Item_Group,Item_Pur_UOM,Item_Iss_UOM,Item_Spec,Item_PTS,Item_BOM_Req,Item_Critical_Item,Item_ShelfLife,CompID,id")] Item_RM_Master item_RM_Master)
        {
            if (ModelState.IsValid)
            {
                db.Entry(item_RM_Master).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(item_RM_Master);
        }

        // GET: ItemMaster/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Item_RM_Master item_RM_Master = db.Item_RM_Master.Find(id);
            if (item_RM_Master == null)
            {
                return HttpNotFound();
            }
            return View(item_RM_Master);
        }

        public ActionResult Partial_Create()
        {
            return PartialView();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Partial_Create([Bind(Include = "Item_Type,Item_Group,Item_Pur_UOM,Item_Iss_UOM,Item_Spec,Item_PTS,Item_BOM_Req,Item_Critical_Item,Item_ShelfLife,CompID,id")] Item_RM_Master item_RM_Master)
        {
            if (ModelState.IsValid)
            {
                db.Item_RM_Master.Add(item_RM_Master);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id = new SelectList(db.Item_RM_Master, "Id", "ItemMaster", item_RM_Master.Item_Type);
            return PartialView(item_RM_Master);
        }


        // POST: ItemMaster/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Item_RM_Master item_RM_Master = db.Item_RM_Master.Find(id);
            db.Item_RM_Master.Remove(item_RM_Master);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
