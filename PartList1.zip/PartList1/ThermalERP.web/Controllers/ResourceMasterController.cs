﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using ThermalERP.web.Models;
using System.Linq.Dynamic;

namespace ThermalERP.web.Controllers
{
    public class ResourceMasterController : Controller
    {
        private Thermal_PMSEntities db = new Thermal_PMSEntities();

       [HttpPost]
        public ActionResult Index()
        {
            return View(db.Resource_Master.ToList());
        }
        [HttpGet]
        public ActionResult Index(int page = 1, string sort = "Resource_Id", string sortdir = "asc", string search = "")
        {
            int pagesize = 10;
            int totalRecord = 0;
            if (page < 1) page = 1;
            int skip = (page * pagesize) - pagesize;
            var data = GetList(search, sort, sortdir, skip, pagesize, out totalRecord);
            ViewBag.TotalRows = totalRecord;
            return View(data);
        }
        public List<Resource_Master> GetList(string Search, string sort, string sortdir, int skip, int pageSize, out int TotalRecord)
        {
            using (Thermal_PMSEntities db = new Thermal_PMSEntities())
            {
                var v = (from a in db.Resource_Master
                         where
                         a.Resource_Id.Contains(Search) ||
                         a.Resource_Name.Contains(Search)

                         select a
                         );
                TotalRecord = v.Count();
                v = v.OrderBy(sort + " " + sortdir);
                if (pageSize > 0)
                {
                    v = v.Skip(skip).Take(pageSize);
                }
                return v.ToList();
            }
        }


        // GET: ResourceMaster/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Resource_Master resource_Master = db.Resource_Master.Find(id);
            if (resource_Master == null)
            {
                return HttpNotFound();
            }
            return View(resource_Master);
        }

        // GET: ResourceMaster/Create
        public ActionResult Create()
        {
            ViewBag.Id = new SelectList(db.Resource_Master, "Id", "Resource_Id");
            return PartialView("Partial_Create");
        }

        // POST: ResourceMaster/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        //[HttpPost]
        //[ValidateAntiForgeryToken]
        //public ActionResult Create([Bind(Include = "id,Resource_Id,Resource_Name,Skill_Set,CompID,Created_By,Created_On,Modified_By,Modified_On")] Resource_Master resource_Master)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        db.Resource_Master.Add(resource_Master);
        //        db.SaveChanges();
        //        return RedirectToAction("Index");
        //    }
        //    ViewBag.Id = new SelectList(db.Resource_Master, "Id", "Resource_Id", resource_Master.Resource_Id);
        //    return View(resource_Master);
        //}

        // GET: ResourceMaster/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Resource_Master resource_Master = db.Resource_Master.Find(id);
            if (resource_Master == null)
            {
                return HttpNotFound();
            }
            return View(resource_Master);
        }

        // POST: ResourceMaster/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "id,Resource_Id,Resource_Name,Skill_Set,CompID,Created_By,Created_On,Modified_By,Modified_On")] Resource_Master resource_Master)
        {
            if (ModelState.IsValid)
            {
                db.Entry(resource_Master).State = System.Data.Entity.EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(resource_Master);
        }

        // GET: ResourceMaster/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Resource_Master resource_Master = db.Resource_Master.Find(id);
            if (resource_Master == null)
            {
                return HttpNotFound();
            }
            return View(resource_Master);
        }
        public ActionResult Partial_Create()
        {
            return PartialView();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Partial_Create([Bind(Include = "id,Resource_Id,Resource_Name,Skill_Set,CompID,Created_By,Created_On,Modified_By,Modified_On")] Resource_Master resource_Master)
        {
            if (ModelState.IsValid)
            {
                db.Resource_Master.Add(resource_Master);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Id = new SelectList(db.Resource_Master, "Id", "Resource_Id", resource_Master.Resource_Id);
            return PartialView(resource_Master);
        }
        // POST: ResourceMaster/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            Resource_Master resource_Master = db.Resource_Master.Find(id);
            db.Resource_Master.Remove(resource_Master);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
