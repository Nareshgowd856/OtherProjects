﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ThermalERP.Entities.Models;

namespace ThermalERP.web.Services
{
    public class UserService : IDisposable
    {
        private readonly ERPDBEntities _dbContext;

        public UserService(ERPDBEntities dbContext)
        {
            _dbContext = dbContext;
        }

        public tbl_User GetUser(string userEmail)
        {
            tbl_User user = _dbContext.tbl_User.Where(x => x.Email.ToLower().ToString() == userEmail.ToLower().ToString()).FirstOrDefault();
            return user;
        }



        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}